<?php
/**
 * Test Dashboard Connection
 * This script tests if the dashboard API is working correctly
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test dashboard stats API directly
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/dashboard_api.php?action=get_dashboard_stats';
    
    $response = @file_get_contents($apiUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $apiResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['dashboard_stats_api'] = [
        'status' => $apiResult['success'] ? 'PASS' : 'FAIL',
        'message' => $apiResult['success'] ? 'Dashboard stats API working' : 'Dashboard stats API failed: ' . ($apiResult['message'] ?? 'Unknown error'),
        'api_url' => $apiUrl,
        'response' => $apiResult
    ];
    
    // Test 2: Test sales data API directly
    $salesApiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/dashboard_api.php?action=get_sales_data';
    
    $salesResponse = @file_get_contents($salesApiUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $salesApiResult = $salesResponse ? json_decode($salesResponse, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['sales_data_api'] = [
        'status' => $salesApiResult['success'] ? 'PASS' : 'FAIL',
        'message' => $salesApiResult['success'] ? 'Sales data API working' : 'Sales data API failed: ' . ($salesApiResult['message'] ?? 'Unknown error'),
        'api_url' => $salesApiUrl,
        'response' => $salesApiResult
    ];
    
    // Test 3: Direct database queries to verify data
    $directStats = [];
    
    // Total Users
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE roles = 'customer' AND status = 'Active'");
    $stmt->execute();
    $directStats['total_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    // Total Orders
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders");
    $stmt->execute();
    $directStats['total_orders'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    // Total Revenue
    $stmt = $conn->prepare("SELECT SUM(amount) as total FROM transactions");
    $stmt->execute();
    $directStats['total_revenue'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    
    $testResults['tests']['direct_database_queries'] = [
        'status' => 'PASS',
        'message' => 'Direct database queries successful',
        'data' => $directStats
    ];
    
    // Test 4: Compare API vs Direct queries
    $apiData = $apiResult['success'] ? $apiResult['data'] : [];
    $comparison = [];
    
    foreach ($directStats as $key => $directValue) {
        $apiValue = $apiData[$key] ?? null;
        $comparison[$key] = [
            'direct_query' => $directValue,
            'api_response' => $apiValue,
            'match' => $directValue == $apiValue
        ];
    }
    
    $allMatch = array_reduce($comparison, function($carry, $item) {
        return $carry && $item['match'];
    }, true);
    
    $testResults['tests']['api_vs_direct_comparison'] = [
        'status' => $allMatch ? 'PASS' : 'FAIL',
        'message' => $allMatch ? 'API and direct queries match' : 'API and direct queries do not match',
        'comparison' => $comparison
    ];
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'dashboard_connection_status' => $failCount === 0 ? 'Dashboard is properly connected to real data' : 'Dashboard connection issues found',
        'recommendations' => $failCount === 0 ? [
            '1. Dashboard API is working correctly',
            '2. Real data is being fetched from database',
            '3. Charts should display actual data',
            '4. KPIs should show real counts'
        ] : [
            '1. Check database connection',
            '2. Verify API endpoints',
            '3. Check for JavaScript errors in browser console',
            '4. Clear browser cache and test again'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'dashboard_connection_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>