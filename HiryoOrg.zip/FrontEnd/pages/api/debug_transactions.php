<?php
// Debug script to check transactions table
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

// Include database connection
$db_path = '../datab_try.php';
if (!@include_once $db_path) {
    echo json_encode(['success' => false, 'message' => 'Database connection file not found']);
    exit;
}

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Check if transactions table exists
    $checkTableStmt = $conn->prepare("SHOW TABLES LIKE 'transactions'");
    $checkTableStmt->execute();
    $tableExists = $checkTableStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$tableExists) {
        echo json_encode([
            'success' => false,
            'message' => 'Transactions table does not exist',
            'table_exists' => false
        ]);
        exit;
    }
    
    // Get table structure
    $describeStmt = $conn->prepare("DESCRIBE transactions");
    $describeStmt->execute();
    $columns = $describeStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Count records
    $countStmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $countStmt->execute();
    $count = $countStmt->fetch(PDO::FETCH_ASSOC);
    
    // Get all records
    $allStmt = $conn->prepare("SELECT * FROM transactions ORDER BY order_id DESC LIMIT 5");
    $allStmt->execute();
    $allRecords = $allStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'message' => 'Transactions table debug info',
        'data' => [
            'table_exists' => true,
            'table_structure' => $columns,
            'record_count' => $count['count'],
            'recent_records' => $allRecords
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
