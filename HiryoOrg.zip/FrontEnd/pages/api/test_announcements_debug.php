<?php
/**
 * Debug Announcements Issue
 * This script tests the announcements API to identify the problem
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check if announcements table exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'announcements'");
    $stmt->execute();
    $tableExists = $stmt->rowCount() > 0;
    
    $testResults['tests']['announcements_table_exists'] = [
        'status' => $tableExists ? 'PASS' : 'FAIL',
        'message' => $tableExists ? 'Announcements table exists' : 'Announcements table does not exist'
    ];
    
    if ($tableExists) {
        // Test 2: Check announcements table structure
        $stmt = $conn->prepare("DESCRIBE announcements");
        $stmt->execute();
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $testResults['tests']['announcements_table_structure'] = [
            'status' => 'PASS',
            'message' => 'Announcements table structure retrieved',
            'columns' => $columns
        ];
        
        // Test 3: Check if we can insert into announcements table
        $testTitle = 'Test Announcement - ' . date('Y-m-d H:i:s');
        $testMessage = 'This is a test announcement for debugging.';
        
        try {
            $stmt = $conn->prepare("INSERT INTO announcements (title, message, created_at) VALUES (?, ?, NOW())");
            $stmt->execute([$testTitle, $testMessage]);
            $announcementId = $conn->lastInsertId();
            
            $testResults['tests']['announcements_insert_test'] = [
                'status' => 'PASS',
                'message' => 'Successfully inserted test announcement',
                'announcement_id' => $announcementId
            ];
            
            // Clean up test data
            $stmt = $conn->prepare("DELETE FROM announcements WHERE announcement_id = ?");
            $stmt->execute([$announcementId]);
            
        } catch (Exception $e) {
            $testResults['tests']['announcements_insert_test'] = [
                'status' => 'FAIL',
                'message' => 'Failed to insert into announcements table: ' . $e->getMessage()
            ];
        }
    }
    
    // Test 4: Check notifications table exists
    $stmt = $conn->prepare("SHOW TABLES LIKE 'notifications'");
    $stmt->execute();
    $notificationsTableExists = $stmt->rowCount() > 0;
    
    $testResults['tests']['notifications_table_exists'] = [
        'status' => $notificationsTableExists ? 'PASS' : 'FAIL',
        'message' => $notificationsTableExists ? 'Notifications table exists' : 'Notifications table does not exist'
    ];
    
    if ($notificationsTableExists) {
        // Test 5: Check notifications table structure
        $stmt = $conn->prepare("DESCRIBE notifications");
        $stmt->execute();
        $notificationColumns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $testResults['tests']['notifications_table_structure'] = [
            'status' => 'PASS',
            'message' => 'Notifications table structure retrieved',
            'columns' => $notificationColumns
        ];
        
        // Test 6: Check if we can insert into notifications table
        try {
            $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message, type, is_read, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([1, 'Test Notification', 'This is a test notification', 'announcement', 0]);
            $notificationId = $conn->lastInsertId();
            
            $testResults['tests']['notifications_insert_test'] = [
                'status' => 'PASS',
                'message' => 'Successfully inserted test notification',
                'notification_id' => $notificationId
            ];
            
            // Clean up test data
            $stmt = $conn->prepare("DELETE FROM notifications WHERE notification_id = ?");
            $stmt->execute([$notificationId]);
            
        } catch (Exception $e) {
            $testResults['tests']['notifications_insert_test'] = [
                'status' => 'FAIL',
                'message' => 'Failed to insert into notifications table: ' . $e->getMessage()
            ];
        }
    }
    
    // Test 7: Test notifications API directly
    $postData = http_build_query([
        'action' => 'create_announcement',
        'title' => 'Test API Announcement',
        'message' => 'Testing notifications API'
    ]);
    
    $apiResponse = @file_get_contents('http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/notifications_api.php', false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 15
        ]
    ]));
    
    $apiResult = $apiResponse ? json_decode($apiResponse, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['notifications_api_test'] = [
        'status' => $apiResult['success'] ? 'PASS' : 'FAIL',
        'message' => $apiResult['success'] ? 'Notifications API working' : 'Notifications API failed: ' . ($apiResult['message'] ?? 'Unknown error'),
        'api_response' => $apiResult
    ];
    
    // Test 8: Check users table for active users
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE roles = 'customer' AND status = 'Active'");
    $stmt->execute();
    $activeUsers = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    $testResults['tests']['active_users_check'] = [
        'status' => $activeUsers > 0 ? 'PASS' : 'WARNING',
        'message' => $activeUsers > 0 ? "Found $activeUsers active customer users" : 'No active customer users found',
        'active_users_count' => (int)$activeUsers
    ];
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    $warningCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
        if ($test['status'] === 'WARNING') $warningCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'warnings' => $warningCount,
        'status' => $failCount === 0 ? ($warningCount > 0 ? 'PASSED WITH WARNINGS ⚠️' : 'ALL TESTS PASSED ✅') : 'SOME TESTS FAILED ❌',
        'diagnosis' => $failCount > 0 ? [
            '1. Check database table existence',
            '2. Verify table structure',
            '3. Check API endpoint',
            '4. Review error messages'
        ] : [
            '1. Database tables are working',
            '2. API endpoint is functional',
            '3. Issue might be in frontend form submission',
            '4. Check browser console for errors'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'announcements_debug_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
