<?php
// Debug the transactions table issue
header('Content-Type: text/plain');

echo "=== DEBUGGING TRANSACTIONS TABLE ISSUE ===\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check if transactions table exists
    echo "=== CHECKING TRANSACTIONS TABLE ===\n";
    $check_table_stmt = $conn->prepare("SHOW TABLES LIKE 'transactions'");
    $check_table_stmt->execute();
    $table_exists = $check_table_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($table_exists) {
        echo "✅ Transactions table exists\n";
        
        // Get table structure
        $describe_stmt = $conn->prepare("DESCRIBE transactions");
        $describe_stmt->execute();
        $columns = $describe_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "📋 Table structure:\n";
        foreach ($columns as $column) {
            echo "   - {$column['Field']}: {$column['Type']}\n";
        }
        
        // Check if there are any transactions
        $count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
        $count_stmt->execute();
        $count = $count_stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "\n📊 Total transactions: $count\n";
        
    } else {
        echo "❌ Transactions table does NOT exist\n";
        echo "🔧 Creating transactions table...\n";
        
        $create_table_sql = "
            CREATE TABLE transactions (
                transaction_id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                user_id INT NOT NULL,
                customer_name VARCHAR(255),
                customer_email VARCHAR(255),
                customer_contact VARCHAR(20),
                delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
                payment_method VARCHAR(50) NOT NULL,
                shipping_address TEXT,
                subtotal DECIMAL(10,2) NOT NULL,
                delivery_fee DECIMAL(10,2) NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                created_at DATETIME NOT NULL,
                items JSON,
                INDEX idx_user_id (user_id),
                INDEX idx_created_at (created_at)
            )
        ";
        
        try {
            $conn->exec($create_table_sql);
            echo "✅ Transactions table created successfully\n";
        } catch (Exception $e) {
            echo "❌ Failed to create transactions table: " . $e->getMessage() . "\n";
        }
    }
    
    echo "\n=== TESTING SIMPLE INSERT ===\n";
    
    // Test a simple insert to see if it works
    try {
        $test_insert_stmt = $conn->prepare("
            INSERT INTO transactions (
                order_id, user_id, customer_name, customer_email, customer_contact,
                delivery_method, payment_method, shipping_address, subtotal, 
                delivery_fee, amount, created_at, items
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
        ");
        
        $test_data = [
            999, // order_id
            1,   // user_id
            'Test Customer', // customer_name
            'test@email.com', // customer_email
            '1234567890', // customer_contact
            'Delivery', // delivery_method
            'COD', // payment_method
            'Test Address', // shipping_address
            100.00, // subtotal
            15.00, // delivery_fee
            115.00, // amount
            json_encode([['product_name' => 'Test Product', 'quantity' => 1, 'price' => 100.00]]) // items
        ];
        
        $result = $test_insert_stmt->execute($test_data);
        
        if ($result) {
            echo "✅ Test insert successful\n";
            
            // Clean up test data
            $cleanup_stmt = $conn->prepare("DELETE FROM transactions WHERE order_id = 999");
            $cleanup_stmt->execute();
            echo "🧹 Test data cleaned up\n";
        } else {
            echo "❌ Test insert failed\n";
            $errorInfo = $test_insert_stmt->errorInfo();
            echo "Error: " . json_encode($errorInfo) . "\n";
        }
        
    } catch (Exception $e) {
        echo "❌ Test insert exception: " . $e->getMessage() . "\n";
    }
    
    echo "\n=== CHECKING ORDERS TABLE ===\n";
    
    // Check orders table
    $orders_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders WHERE status = 'Delivered' LIMIT 3");
    $orders_stmt->execute();
    $orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "❌ No delivered orders found\n";
    } else {
        echo "✅ Found delivered orders:\n";
        foreach ($orders as $order) {
            echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}\n";
        }
    }
    
    echo "\n=== SUMMARY ===\n";
    echo "🔍 If transactions table exists and test insert works, the issue is in the API logic\n";
    echo "🔍 If transactions table doesn't exist, that's the problem\n";
    echo "🔍 If test insert fails, there's a database permission or structure issue\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
