<?php
/**
 * Test Products Schema
 * This script checks the actual database schema for the products table
 */

header('Content-Type: application/json');

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check products table structure
    $stmt = $conn->prepare("SHOW COLUMNS FROM products");
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['products_table_structure'] = [
        'status' => 'INFO',
        'message' => 'Products table columns',
        'columns' => $columns
    ];
    
    // Test 2: Check if created_at column exists
    $hasCreatedAt = false;
    $hasOrderDate = false;
    foreach ($columns as $column) {
        if ($column['Field'] === 'created_at') {
            $hasCreatedAt = true;
        }
        if ($column['Field'] === 'order_date') {
            $hasOrderDate = true;
        }
    }
    
    $testResults['tests']['date_columns'] = [
        'status' => 'INFO',
        'message' => 'Date column check',
        'has_created_at' => $hasCreatedAt,
        'has_order_date' => $hasOrderDate
    ];
    
    // Test 3: Try the current query
    try {
        $stmt = $conn->prepare("SELECT * FROM products ORDER BY created_at DESC LIMIT 5");
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $testResults['tests']['current_query_test'] = [
            'status' => 'PASS',
            'message' => 'Current query works',
            'products_found' => count($products),
            'sample_products' => $products
        ];
    } catch (PDOException $e) {
        $testResults['tests']['current_query_test'] = [
            'status' => 'FAIL',
            'message' => 'Current query failed: ' . $e->getMessage(),
            'error_code' => $e->getCode()
        ];
    }
    
    // Test 4: Try alternative query with order_date
    if (!$hasCreatedAt && $hasOrderDate) {
        try {
            $stmt = $conn->prepare("SELECT * FROM products ORDER BY order_date DESC LIMIT 5");
            $stmt->execute();
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $testResults['tests']['alternative_query_test'] = [
                'status' => 'PASS',
                'message' => 'Alternative query with order_date works',
                'products_found' => count($products),
                'sample_products' => $products
            ];
        } catch (PDOException $e) {
            $testResults['tests']['alternative_query_test'] = [
                'status' => 'FAIL',
                'message' => 'Alternative query failed: ' . $e->getMessage()
            ];
        }
    }
    
    // Test 5: Try simple query without ORDER BY
    try {
        $stmt = $conn->prepare("SELECT * FROM products LIMIT 5");
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $testResults['tests']['simple_query_test'] = [
            'status' => 'PASS',
            'message' => 'Simple query without ORDER BY works',
            'products_found' => count($products),
            'sample_products' => $products
        ];
    } catch (PDOException $e) {
        $testResults['tests']['simple_query_test'] = [
            'status' => 'FAIL',
            'message' => 'Simple query failed: ' . $e->getMessage()
        ];
    }
    
    // Test 6: Count total products
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['total_products_count'] = [
            'status' => 'INFO',
            'message' => 'Total products in database',
            'count' => $result['count']
        ];
    } catch (PDOException $e) {
        $testResults['tests']['total_products_count'] = [
            'status' => 'FAIL',
            'message' => 'Count query failed: ' . $e->getMessage()
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'recommendation' => $hasCreatedAt ? 'Use ORDER BY created_at DESC' : 'Use ORDER BY product_id DESC or remove ORDER BY'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'products_schema',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
