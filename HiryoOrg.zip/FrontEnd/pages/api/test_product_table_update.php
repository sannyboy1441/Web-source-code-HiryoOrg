<?php
/**
 * Test Product Table Update
 * This script tests the complete flow from saving a product to updating the table
 */

header('Content-Type: application/json');

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check current products count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products WHERE status = 'Active'");
    $stmt->execute();
    $productsBefore = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    $testResults['tests']['products_before'] = [
        'status' => 'INFO',
        'message' => 'Products count before adding new product',
        'count' => $productsBefore
    ];
    
    // Test 2: Add a test product via API
    $testData = [
        'action' => 'add_product',
        'product_name' => 'Table Test Product ' . time(),
        'category' => 'Test',
        'price' => '99.99',
        'stock_quantity' => '10',
        'description' => 'Testing table update after save',
        'product_sku' => 'TABLE-TEST-' . time(),
        'weight_value' => '1.0',
        'weight_unit' => 'kg'
    ];
    
    // Simulate POST data
    $_POST = $testData;
    
    // Capture API output
    ob_start();
    include 'products_api.php';
    $output = ob_get_clean();
    $result = json_decode($output, true);
    
    $testResults['tests']['add_product_api'] = [
        'status' => $result['success'] ? 'PASS' : 'FAIL',
        'message' => $result['success'] ? 'Product added successfully via API' : 'Failed to add product via API',
        'api_response' => $result,
        'has_product_data' => isset($result['product']),
        'product_id' => $result['success'] && isset($result['product']) ? $result['product']['product_id'] : null
    ];
    
    // Test 3: Check products count after adding
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products WHERE status = 'Active'");
    $stmt->execute();
    $productsAfter = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    $testResults['tests']['products_after'] = [
        'status' => 'PASS',
        'message' => 'Products count after adding new product',
        'count' => $productsAfter,
        'increased' => $productsAfter > $productsBefore,
        'expected' => 'Count should increase by 1'
    ];
    
    // Test 4: Test get_products_for_admin API
    $productsUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_products_for_admin';
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 5
        ]
    ]);
    
    $response = @file_get_contents($productsUrl, false, $context);
    
    if ($response === false) {
        $testResults['tests']['get_products_api'] = [
            'status' => 'FAIL',
            'message' => 'Get products API request failed',
            'url' => $productsUrl
        ];
    } else {
        $data = json_decode($response, true);
        $testResults['tests']['get_products_api'] = [
            'status' => $data && isset($data['success']) && $data['success'] ? 'PASS' : 'FAIL',
            'message' => $data && isset($data['success']) && $data['success'] ? 'Get products API working' : 'Get products API error: ' . ($data['message'] ?? 'Unknown error'),
            'url' => $productsUrl,
            'products_returned' => isset($data['products']) ? count($data['products']) : 0,
            'has_new_product' => false // We'll check this below
        ];
        
        // Check if our test product is in the returned data
        if (isset($data['products']) && is_array($data['products'])) {
            $testProductName = $testData['product_name'];
            $foundTestProduct = false;
            foreach ($data['products'] as $product) {
                if ($product['product_name'] === $testProductName) {
                    $foundTestProduct = true;
                    $testResults['tests']['get_products_api']['has_new_product'] = true;
                    $testResults['tests']['get_products_api']['new_product_data'] = $product;
                    break;
                }
            }
        }
    }
    
    // Test 5: Clean up test product
    if ($result['success'] && isset($result['product']['product_id'])) {
        $productId = $result['product']['product_id'];
        $deleteStmt = $conn->prepare("DELETE FROM products WHERE product_id = ?");
        $deleteStmt->execute([$productId]);
        
        $testResults['tests']['cleanup'] = [
            'status' => 'INFO',
            'message' => 'Test product cleaned up',
            'product_id' => $productId
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'database_save_working' => isset($testResults['tests']['products_after']) && $testResults['tests']['products_after']['increased'],
        'api_returns_product_data' => isset($testResults['tests']['add_product_api']) && $testResults['tests']['add_product_api']['has_product_data'],
        'get_products_working' => isset($testResults['tests']['get_products_api']) && $testResults['tests']['get_products_api']['status'] === 'PASS',
        'table_update_issue' => 'If database saves but table doesn\'t update, the issue is in JavaScript table rendering'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'product_table_update',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
