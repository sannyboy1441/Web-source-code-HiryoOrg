<?php
/**
 * Orders API Fixed - Simple working version
 */

// Prevent multiple executions
if (defined('ORDERS_API_FIXED_EXECUTED')) {
    exit();
}
define('ORDERS_API_FIXED_EXECUTED', true);

// Set headers first
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database connection
$db_path = '../datab_try.php';
if (!@include_once $db_path) {
    echo json_encode(['success' => false, 'message' => 'Database connection file not found']);
    exit;
}

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    // Get action
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    
    switch ($action) {
        case 'get_order_details':
            handleGetOrderDetails($conn);
            break;
            
        case 'update_order_status':
            handleUpdateOrderStatus($conn);
            break;
            
        case 'get_all_orders_for_admin':
            handleGetAllOrdersForAdmin($conn);
            break;
            
        case 'place_order':
            handlePlaceOrder($conn);
            break;
            
        case 'get_user_orders':
            handleGetUserOrders($conn);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action specified']);
            break;
    }
    
    exit();
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Server error occurred: ' . $e->getMessage()
    ]);
}

function handleGetOrderDetails($conn) {
    $order_id = (int)($_GET['order_id'] ?? 0);
    
    if ($order_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid order ID is required']);
        return;
    }
    
    $stmt_order = $conn->prepare("
        SELECT 
            o.*, 
            u.firstName, 
            u.lastName, 
            u.username,
            u.email, 
            u.contact_number as contact_number,
            u.address,
            COALESCE(o.delivery_fee, 0) as delivery_fee,
            COALESCE(o.subtotal, 0) as subtotal,
            COALESCE(o.total_amount, 0) as total_amount
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_id = ?
    ");
    
    $stmt_order->execute([$order_id]);
    $order = $stmt_order->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        return;
    }
    
    $stmt_items = $conn->prepare("
        SELECT oi.*, p.product_name, p.image_url 
        FROM order_items oi 
        LEFT JOIN products p ON oi.product_id = p.product_id 
        WHERE oi.order_id = ?
    ");
    
    $stmt_items->execute([$order_id]);
    $items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
    
    $firstName = $order['firstName'] ?? '';
    $lastName = $order['lastName'] ?? '';
    $username = $order['username'] ?? '';
    
    if (!empty($firstName) && !empty($lastName)) {
        $order['customer_name'] = $firstName . ' ' . $lastName;
    } elseif (!empty($firstName)) {
        $order['customer_name'] = $firstName;
    } elseif (!empty($username)) {
        $order['customer_name'] = $username;
    } else {
        $order['customer_name'] = 'Unknown Customer';
    }
    
    $order['items'] = $items;
    
    echo json_encode(['success' => true, 'order' => $order]);
}

function handleUpdateOrderStatus($conn) {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    
    if ($order_id <= 0 || empty($status)) {
        echo json_encode(['success' => false, 'message' => 'Valid order ID and status are required']);
        return;
    }
    
    try {
        // If status is 'completed' or 'cancelled', transfer to transactions table
        if (strtolower($status) === 'completed' || strtolower($status) === 'cancelled') {
            
            // Get order details
            $order_stmt = $conn->prepare("
                SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number
                FROM orders o 
                LEFT JOIN users u ON o.user_id = u.user_id 
                WHERE o.order_id = ?
            ");
            $order_stmt->execute([$order_id]);
            $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                throw new Exception("Order #$order_id not found");
            }
            
            // Get order items
            $items_stmt = $conn->prepare("
                SELECT oi.*, p.product_name 
                FROM order_items oi 
                LEFT JOIN products p ON oi.product_id = p.product_id 
                WHERE oi.order_id = ?
            ");
            $items_stmt->execute([$order_id]);
            $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Create transactions table if it doesn't exist
            $create_table_sql = "
                CREATE TABLE IF NOT EXISTS transactions (
                    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
                    order_id INT NOT NULL,
                    user_id INT NOT NULL,
                    customer_name VARCHAR(255),
                    customer_email VARCHAR(255),
                    customer_contact VARCHAR(20),
                    delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
                    payment_method VARCHAR(50) NOT NULL,
                    shipping_address TEXT,
                    subtotal DECIMAL(10,2) NOT NULL,
                    delivery_fee DECIMAL(10,2) NOT NULL,
                    amount DECIMAL(10,2) NOT NULL,
                    created_at DATETIME NOT NULL,
                    items JSON,
                    INDEX idx_user_id (user_id),
                    INDEX idx_created_at (created_at)
                )
            ";
            $conn->exec($create_table_sql);
            
            // Insert into transactions table - SIMPLE INSERT
            $trans_stmt = $conn->prepare("
                INSERT INTO transactions (
                    order_id, user_id, customer_name, customer_email, customer_contact,
                    delivery_method, payment_method, shipping_address, subtotal, 
                    delivery_fee, amount, created_at, items
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
            ");
            
            $customer_name = trim(($order['firstName'] ?? '') . ' ' . ($order['lastName'] ?? ''));
            $items_json = json_encode($items);
            
            $trans_result = $trans_stmt->execute([
                $order_id,
                $order['user_id'],
                $customer_name,
                $order['email'],
                $order['contact_number'],
                $order['delivery_method'],
                $order['payment_method'],
                $order['shipping_address'],
                $order['subtotal'],
                $order['delivery_fee'],
                $order['total_amount'],
                $items_json
            ]);
            
            if (!$trans_result) {
                $errorInfo = $trans_stmt->errorInfo();
                throw new Exception("Failed to insert into transactions: " . json_encode($errorInfo));
            }
            
            // Delete order items
            $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $delete_items_stmt->execute([$order_id]);
            
            // Delete from orders table
            $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $delete_stmt->execute([$order_id]);
            
        } else {
            // Just update status
            $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
            $stmt->execute([$status, $order_id]);
        }
        
        echo json_encode(['success' => true, 'message' => 'Order status updated successfully']);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function handleGetAllOrdersForAdmin($conn) {
    $stmt = $conn->prepare("
        SELECT 
            o.*,
            u.firstName,
            u.lastName,
            u.username,
            u.email,
            u.contact_number,
            u.address,
            COALESCE(o.delivery_fee, 0) as delivery_fee,
            COALESCE(o.subtotal, 0) as subtotal,
            COALESCE(o.total_amount, 0) as total_amount
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        WHERE o.status NOT IN ('Completed', 'Cancelled')
        ORDER BY o.order_date DESC
    ");
    
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($orders as &$order) {
        $firstName = $order['firstName'] ?? '';
        $lastName = $order['lastName'] ?? '';
        $username = $order['username'] ?? '';
        
        if (!empty($firstName) && !empty($lastName)) {
            $order['customer_name'] = $firstName . ' ' . $lastName;
        } elseif (!empty($firstName)) {
            $order['customer_name'] = $firstName;
        } elseif (!empty($username)) {
            $order['customer_name'] = $username;
        } else {
            $order['customer_name'] = 'Unknown Customer';
        }
    }
    
    echo json_encode(['success' => true, 'orders' => $orders]);
}

function handlePlaceOrder($conn) {
    $user_id = $_POST['user_id'] ?? null;
    $delivery_method = $_POST['delivery_method'] ?? 'Delivery';
    $payment_method = $_POST['payment_method'] ?? 'Cash on Delivery';
    $shipping_address = $_POST['shipping_address'] ?? '';
    $items_json = $_POST['items'] ?? '';
    
    $items = json_decode($items_json, true);
    
    if (!$user_id || empty($items) || !is_array($items)) {
        echo json_encode(['success' => false, 'message' => 'User ID and valid items are required']);
        return;
    }
    
    try {
        $subtotal = 0;
        $delivery_fee = $delivery_method === 'Delivery' ? 115.00 : 0.00;
        
        foreach ($items as $item) {
            $item_price = floatval($item['price'] ?? 0);
            $item_quantity = intval($item['quantity'] ?? 0);
            $subtotal += $item_price * $item_quantity;
        }
        
        $total_amount = $subtotal + $delivery_fee;
        
        $stmt = $conn->prepare("
            INSERT INTO orders (user_id, delivery_method, payment_method, shipping_address, subtotal, delivery_fee, total_amount, status, order_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', NOW())
        ");
        
        $stmt->execute([
            $user_id,
            $delivery_method,
            $payment_method,
            $shipping_address,
            $subtotal,
            $delivery_fee,
            $total_amount
        ]);
        
        $order_id = $conn->lastInsertId();
        
        $stmt_items = $conn->prepare("
            INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) 
            VALUES (?, ?, ?, ?)
        ");
        
        foreach ($items as $item) {
            $stmt_items->execute([
                $order_id,
                $item['product_id'] ?? $item['id'] ?? 0,
                $item['quantity'] ?? 0,
                $item['price'] ?? $item['price_at_purchase'] ?? 0
            ]);
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Order placed successfully',
            'order_id' => $order_id,
            'total_amount' => $total_amount
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to place order: ' . $e->getMessage()]);
    }
}

function handleGetUserOrders($conn) {
    $user_id = $_GET['user_id'] ?? $_POST['user_id'] ?? null;
    
    if (!$user_id) {
        echo json_encode(['success' => false, 'message' => 'User ID is required']);
        return;
    }
    
    $stmt = $conn->prepare("
        SELECT o.*, u.firstName, u.lastName, u.email 
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        WHERE o.user_id = ? 
        ORDER BY o.order_date DESC
    ");
    
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'orders' => $orders]);
}
?>
