<?php
/**
 * FIXED Transactions API - Simplified version that handles all column variations
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../datab_try.php';

// --- Main API Router ---
try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    $action = $_REQUEST['action'] ?? '';

    switch ($action) {
        case 'get_all_transactions':
            handleGetAllTransactionsFixed($conn);
            break;
            
        case 'get_completed_order_details':
            handleGetCompletedOrderDetails($conn);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid or missing action.']);
            break;
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}

/**
 * FIXED: Get all transactions with flexible column handling
 */
function handleGetAllTransactionsFixed($conn) {
    try {
        // First check if transactions table exists
        $checkTableStmt = $conn->prepare("SHOW TABLES LIKE 'transactions'");
        $checkTableStmt->execute();
        $tableExists = $checkTableStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tableExists) {
            // Transactions table doesn't exist yet - this is normal if no orders have been completed
            echo json_encode([
                'success' => true, 
                'transactions' => [],
                'message' => 'No completed transactions yet. Transactions will appear here when orders are completed.'
            ]);
            return;
        }
        
        // Get table structure first
        $describeStmt = $conn->prepare("DESCRIBE transactions");
        $describeStmt->execute();
        $columns = $describeStmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Build query based on actual columns
        $selectFields = [
            't.transaction_id',
            't.order_id',
            't.user_id'
        ];
        
        // Add amount field based on what exists
        if (in_array('total_amount', $columns)) {
            $selectFields[] = 't.total_amount as amount';
        } elseif (in_array('amount', $columns)) {
            $selectFields[] = 't.amount';
        } else {
            $selectFields[] = '0 as amount';
        }
        
        // Add payment method
        if (in_array('payment_method', $columns)) {
            $selectFields[] = 't.payment_method';
        } else {
            $selectFields[] = "'COD' as payment_method";
        }
        
        // Add date field
        if (in_array('completion_date', $columns)) {
            $selectFields[] = 't.completion_date as created_at';
        } elseif (in_array('created_at', $columns)) {
            $selectFields[] = 't.created_at';
        } else {
            $selectFields[] = 'NOW() as created_at';
        }
        
        // Add customer fields
        if (in_array('customer_name', $columns)) {
            $selectFields[] = 't.customer_name as user_name';
        } else {
            $selectFields[] = 'COALESCE(u.firstName, u.username, "Unknown Customer") as user_name';
        }
        
        if (in_array('customer_email', $columns)) {
            $selectFields[] = 't.customer_email as user_email';
        } else {
            $selectFields[] = 'COALESCE(u.email, "unknown@email.com") as user_email';
        }
        
        // Add other fields if they exist
        if (in_array('customer_contact', $columns)) {
            $selectFields[] = 't.customer_contact';
        } else {
            $selectFields[] = 'COALESCE(u.contact_number, "") as customer_contact';
        }
        
        if (in_array('delivery_method', $columns)) {
            $selectFields[] = 't.delivery_method';
        } else {
            $selectFields[] = "'Delivery' as delivery_method";
        }
        
        if (in_array('shipping_address', $columns)) {
            $selectFields[] = 't.shipping_address';
        } else {
            $selectFields[] = "COALESCE(u.address, '') as shipping_address";
        }
        
        if (in_array('subtotal', $columns)) {
            $selectFields[] = 't.subtotal';
        } else {
            $selectFields[] = '0 as subtotal';
        }
        
        if (in_array('delivery_fee', $columns)) {
            $selectFields[] = 't.delivery_fee';
        } else {
            $selectFields[] = '0 as delivery_fee';
        }
        
        if (in_array('items', $columns)) {
            $selectFields[] = 't.items';
        } else {
            $selectFields[] = 'NULL as items';
        }
        
        // Always add status
        $selectFields[] = "'Completed' as order_status";
        
        $query = "SELECT " . implode(', ', $selectFields) . " FROM transactions t";
        
        // Add JOIN if we need user data
        if (!in_array('customer_name', $columns) || !in_array('customer_email', $columns)) {
            $query .= " LEFT JOIN users u ON t.user_id = u.user_id";
        }
        
        $query .= " ORDER BY " . (in_array('completion_date', $columns) ? 't.completion_date' : 't.created_at') . " DESC";
        
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true, 
            'transactions' => $transactions,
            'message' => count($transactions) === 0 ? 'No completed transactions found. Transactions will appear here when orders are completed.' : null
        ]);
        
    } catch (PDOException $e) {
        error_log("Transactions API Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    } catch (Exception $e) {
        error_log("Transactions API Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

/**
 * Get completed order details for modal
 */
function handleGetCompletedOrderDetails($conn) {
    $order_id = (int)($_REQUEST['order_id'] ?? 0);
    
    if ($order_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid order ID is required']);
        return;
    }
    
    try {
        // First check if transactions table exists
        $checkTableStmt = $conn->prepare("SHOW TABLES LIKE 'transactions'");
        $checkTableStmt->execute();
        $tableExists = $checkTableStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tableExists) {
            echo json_encode(['success' => false, 'message' => 'Transactions table does not exist yet']);
            return;
        }
        
        // Get table structure first
        $describeStmt = $conn->prepare("DESCRIBE transactions");
        $describeStmt->execute();
        $columns = $describeStmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Build query based on actual columns
        $selectFields = [
            't.transaction_id',
            't.order_id',
            't.user_id'
        ];
        
        // Add amount field based on what exists
        if (in_array('total_amount', $columns)) {
            $selectFields[] = 't.total_amount as amount';
        } elseif (in_array('amount', $columns)) {
            $selectFields[] = 't.amount';
        } else {
            $selectFields[] = '0 as amount';
        }
        
        // Add payment method
        if (in_array('payment_method', $columns)) {
            $selectFields[] = 't.payment_method';
        } else {
            $selectFields[] = "'COD' as payment_method";
        }
        
        // Add date field
        if (in_array('completion_date', $columns)) {
            $selectFields[] = 't.completion_date as created_at';
        } elseif (in_array('created_at', $columns)) {
            $selectFields[] = 't.created_at';
        } else {
            $selectFields[] = 'NOW() as created_at';
        }
        
        // Add customer fields
        if (in_array('customer_name', $columns)) {
            $selectFields[] = 't.customer_name as user_name';
        } else {
            $selectFields[] = 'COALESCE(u.firstName, u.username, "Unknown Customer") as user_name';
        }
        
        if (in_array('customer_email', $columns)) {
            $selectFields[] = 't.customer_email as user_email';
        } else {
            $selectFields[] = 'COALESCE(u.email, "unknown@email.com") as user_email';
        }
        
        // Add other fields if they exist
        if (in_array('customer_contact', $columns)) {
            $selectFields[] = 't.customer_contact';
        } else {
            $selectFields[] = 'COALESCE(u.contact_number, "") as customer_contact';
        }
        
        if (in_array('delivery_method', $columns)) {
            $selectFields[] = 't.delivery_method';
        } else {
            $selectFields[] = "'Delivery' as delivery_method";
        }
        
        if (in_array('shipping_address', $columns)) {
            $selectFields[] = 't.shipping_address';
        } else {
            $selectFields[] = "COALESCE(u.address, '') as shipping_address";
        }
        
        if (in_array('subtotal', $columns)) {
            $selectFields[] = 't.subtotal';
        } else {
            $selectFields[] = '0 as subtotal';
        }
        
        if (in_array('delivery_fee', $columns)) {
            $selectFields[] = 't.delivery_fee';
        } else {
            $selectFields[] = '0 as delivery_fee';
        }
        
        if (in_array('items', $columns)) {
            $selectFields[] = 't.items';
        } else {
            $selectFields[] = 'NULL as items';
        }
        
        // Always add status
        $selectFields[] = "'Completed' as order_status";
        
        $query = "SELECT " . implode(', ', $selectFields) . " FROM transactions t";
        
        // Add JOIN if we need user data
        if (!in_array('customer_name', $columns) || !in_array('customer_email', $columns)) {
            $query .= " LEFT JOIN users u ON t.user_id = u.user_id";
        }
        
        $query .= " WHERE t.order_id = ?";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$order_id]);
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$transaction) {
            echo json_encode(['success' => false, 'message' => 'Completed order not found']);
            return;
        }
        
        // Parse items JSON
        $items = [];
        if (!empty($transaction['items']) && $transaction['items'] !== 'NULL') {
            $items = json_decode($transaction['items'], true) ?: [];
        }
        
        // Add items to transaction data
        $transaction['items'] = $items;
        
        // Ensure we have customer data
        if (empty($transaction['customer_name']) || $transaction['customer_name'] === 'Unknown Customer') {
            $transaction['customer_name'] = $transaction['user_name'] ?? 'Unknown Customer';
        }
        if (empty($transaction['customer_email']) || $transaction['customer_email'] === 'unknown@email.com') {
            $transaction['customer_email'] = $transaction['user_email'] ?? 'unknown@email.com';
        }
        
        echo json_encode(['success' => true, 'order' => $transaction]);
        
    } catch (Exception $e) {
        error_log("Get completed order details error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to get order details: ' . $e->getMessage()]);
    }
}

?>
