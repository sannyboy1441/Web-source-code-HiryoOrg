<?php
// Test the new orders_api_fixed_v3.php
header('Content-Type: text/plain');

echo "=== TESTING ORDERS_API_FIXED_V3.PHP ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check for pending orders
    echo "=== CHECKING FOR PENDING ORDERS ===\n";
    $pending_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders WHERE status = 'Pending' ORDER BY order_id DESC LIMIT 1");
    $pending_stmt->execute();
    $pending_orders = $pending_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($pending_orders)) {
        echo "❌ No pending orders found!\n";
        exit;
    }
    
    $test_order_id = $pending_orders[0]['order_id'];
    echo "✅ Found Order #{$test_order_id} for testing (Amount: {$pending_orders[0]['total_amount']})\n\n";
    
    // Test the new API
    echo "=== TESTING NEW API (orders_api_fixed_v3.php) ===\n";
    
    // Simulate the API call
    $_POST['action'] = 'update_order_status';
    $_POST['order_id'] = $test_order_id;
    $_POST['status'] = 'Completed';
    
    // Capture API output
    ob_start();
    include 'orders_api_fixed_v3.php';
    $api_output = ob_get_clean();
    
    echo "API Response: " . $api_output . "\n\n";
    
    // Parse response
    $response = json_decode($api_output, true);
    
    if ($response && $response['success']) {
        echo "✅ API returned success!\n\n";
        
        // Verify the transfer
        echo "=== VERIFYING TRANSFER ===\n";
        
        // Check if order exists in orders table
        $check_order_stmt = $conn->prepare("SELECT order_id, status FROM orders WHERE order_id = ?");
        $check_order_stmt->execute([$test_order_id]);
        $order_exists = $check_order_stmt->fetch();
        
        if ($order_exists) {
            echo "❌ Order #{$test_order_id} still exists in orders table (Status: {$order_exists['status']})\n";
        } else {
            echo "✅ Order #{$test_order_id} removed from orders table\n";
        }
        
        // Check if order exists in transactions table
        $check_trans_stmt = $conn->prepare("SELECT transaction_id, order_id, amount FROM transactions WHERE order_id = ?");
        $check_trans_stmt->execute([$test_order_id]);
        $trans_exists = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($trans_exists) {
            echo "✅ Order #{$test_order_id} transferred to transactions table (Transaction ID: {$trans_exists['transaction_id']}, Amount: {$trans_exists['amount']})\n";
        } else {
            echo "❌ Order #{$test_order_id} NOT found in transactions table!\n";
        }
        
        echo "\n=== FINAL RESULT ===\n";
        if (!$order_exists && $trans_exists) {
            echo "🎉 SUCCESS: New API (orders_api_fixed_v3.php) works perfectly!\n";
        } else {
            echo "❌ FAILURE: New API still has issues\n";
        }
        
    } else {
        echo "❌ API returned failure: " . ($response['message'] ?? 'Unknown error') . "\n";
    }
    
    // Show current counts
    echo "\n=== CURRENT COUNTS ===\n";
    $orders_count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders");
    $orders_count_stmt->execute();
    $orders_count = $orders_count_stmt->fetch(PDO::FETCH_ASSOC);
    
    $trans_count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $trans_count_stmt->execute();
    $trans_count = $trans_count_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "Orders in orders table: {$orders_count['count']}\n";
    echo "Transactions in transactions table: {$trans_count['count']}\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
