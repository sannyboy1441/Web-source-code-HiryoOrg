<?php
/**
 * Test POST Method
 * This script tests if POST requests are working properly
 */

header('Content-Type: application/json');

$results = [
    'timestamp' => date('Y-m-d H:i:s'),
    'request_info' => [
        'method' => $_SERVER['REQUEST_METHOD'],
        'get_data' => $_GET,
        'post_data' => $_POST,
        'request_data' => $_REQUEST,
        'raw_post_data' => file_get_contents('php://input'),
        'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'NOT_SET',
        'http_method_override' => $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? 'NOT_SET'
    ]
];

// Test if we can handle POST data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $results['post_test'] = [
        'status' => 'SUCCESS',
        'message' => 'POST request received correctly',
        'action' => $_POST['action'] ?? 'NOT_SET',
        'test_data' => $_POST['test'] ?? 'NOT_SET'
    ];
} else {
    $results['post_test'] = [
        'status' => 'FAILED',
        'message' => 'Not a POST request',
        'actual_method' => $_SERVER['REQUEST_METHOD']
    ];
}

echo json_encode($results, JSON_PRETTY_PRINT);
?>
