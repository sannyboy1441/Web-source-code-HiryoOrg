<?php
/**
 * Test Complete Announcements Flow
 * This script tests the entire announcements flow from creation to user notifications
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check database tables exist
    $tables = ['announcements', 'notifications', 'users'];
    foreach ($tables as $table) {
        $stmt = $conn->prepare("SHOW TABLES LIKE ?");
        $stmt->execute([$table]);
        $exists = $stmt->rowCount() > 0;
        
        $testResults['tests']["table_{$table}_exists"] = [
            'status' => $exists ? 'PASS' : 'FAIL',
            'message' => $exists ? "Table $table exists" : "Table $table does not exist"
        ];
    }
    
    // Test 2: Check active users
    $stmt = $conn->prepare("SELECT user_id, username, firstName, lastName FROM users WHERE roles = 'customer' AND status = 'Active' LIMIT 5");
    $stmt->execute();
    $activeUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['active_users_check'] = [
        'status' => count($activeUsers) > 0 ? 'PASS' : 'WARNING',
        'message' => count($activeUsers) > 0 ? 'Found active customer users' : 'No active customer users found',
        'active_users' => $activeUsers,
        'count' => count($activeUsers)
    ];
    
    // Test 3: Create test announcement via API
    $testTitle = 'Test Announcement - ' . date('Y-m-d H:i:s');
    $testMessage = 'This is a test announcement to verify the complete flow works correctly.';
    
    $postData = http_build_query([
        'action' => 'create_announcement',
        'title' => $testTitle,
        'message' => $testMessage
    ]);
    
    $apiResponse = @file_get_contents('http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/notifications_api.php', false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 15
        ]
    ]));
    
    $apiResult = $apiResponse ? json_decode($apiResponse, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['create_announcement_api'] = [
        'status' => $apiResult['success'] ? 'PASS' : 'FAIL',
        'message' => $apiResult['success'] ? 'Announcement created successfully' : 'Failed to create announcement: ' . ($apiResult['message'] ?? 'Unknown error'),
        'api_response' => $apiResult
    ];
    
    if ($apiResult['success']) {
        // Test 4: Verify announcement in database
        $stmt = $conn->prepare("SELECT * FROM announcements WHERE title = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$testTitle]);
        $announcement = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['announcement_in_database'] = [
            'status' => $announcement ? 'PASS' : 'FAIL',
            'message' => $announcement ? 'Announcement stored in database' : 'Announcement not found in database',
            'announcement' => $announcement
        ];
        
        // Test 5: Check notifications sent to users
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE title = ? AND type = 'announcement'");
        $stmt->execute([$testTitle]);
        $notificationCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $testResults['tests']['notifications_sent_to_users'] = [
            'status' => $notificationCount > 0 ? 'PASS' : 'FAIL',
            'message' => $notificationCount > 0 ? "Notifications sent to $notificationCount users" : 'No notifications sent to users',
            'notification_count' => (int)$notificationCount
        ];
        
        // Test 6: Check specific user notifications
        if (count($activeUsers) > 0) {
            $testUserId = $activeUsers[0]['user_id'];
            $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? AND title = ? AND type = 'announcement'");
            $stmt->execute([$testUserId, $testTitle]);
            $userNotification = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $testResults['tests']['specific_user_notification'] = [
                'status' => $userNotification ? 'PASS' : 'FAIL',
                'message' => $userNotification ? 'Notification found for test user' : 'No notification found for test user',
                'test_user_id' => $testUserId,
                'notification' => $userNotification
            ];
        }
        
        // Test 7: Test mobile app notifications API
        if (count($activeUsers) > 0) {
            $testUserId = $activeUsers[0]['user_id'];
            $mobileApiUrl = "http://" . $_SERVER['HTTP_HOST'] . "/HiryoOrg/FrontEnd/pages/api/notifications_api.php?action=get_user_notifications&user_id=$testUserId";
            
            $mobileResponse = @file_get_contents($mobileApiUrl, false, stream_context_create([
                'http' => [
                    'method' => 'GET',
                    'header' => 'Accept: application/json',
                    'timeout' => 15
                ]
            ]));
            
            $mobileResult = $mobileResponse ? json_decode($mobileResponse, true) : ['success' => false, 'message' => 'No response from mobile API'];
            
            $hasAnnouncement = false;
            if ($mobileResult['success'] && isset($mobileResult['notifications'])) {
                foreach ($mobileResult['notifications'] as $notification) {
                    if ($notification['title'] === $testTitle && $notification['type'] === 'announcement') {
                        $hasAnnouncement = true;
                        break;
                    }
                }
            }
            
            $testResults['tests']['mobile_app_notifications'] = [
                'status' => $hasAnnouncement ? 'PASS' : 'FAIL',
                'message' => $hasAnnouncement ? 'Announcement visible in mobile app notifications' : 'Announcement not visible in mobile app notifications',
                'test_user_id' => $testUserId,
                'mobile_api_response' => $mobileResult,
                'has_announcement' => $hasAnnouncement
            ];
        }
        
        // Clean up test data
        if ($announcement) {
            $stmt = $conn->prepare("DELETE FROM announcements WHERE announcement_id = ?");
            $stmt->execute([$announcement['announcement_id']]);
        }
        
        $stmt = $conn->prepare("DELETE FROM notifications WHERE title = ? AND type = 'announcement'");
        $stmt->execute([$testTitle]);
    }
    
    // Test 8: Test web admin announcements API
    $webApiUrl = "http://" . $_SERVER['HTTP_HOST'] . "/HiryoOrg/FrontEnd/pages/api/notifications_api.php?action=get_all_announcements";
    
    $webResponse = @file_get_contents($webApiUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $webResult = $webResponse ? json_decode($webResponse, true) : ['success' => false, 'message' => 'No response from web API'];
    
    $testResults['tests']['web_admin_announcements'] = [
        'status' => $webResult['success'] ? 'PASS' : 'FAIL',
        'message' => $webResult['success'] ? 'Web admin announcements API working' : 'Web admin announcements API failed: ' . ($webResult['message'] ?? 'Unknown error'),
        'api_response' => $webResult
    ];
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    $warningCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
        if ($test['status'] === 'WARNING') $warningCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'warnings' => $warningCount,
        'status' => $failCount === 0 ? ($warningCount > 0 ? 'PASSED WITH WARNINGS ⚠️' : 'ALL TESTS PASSED ✅') : 'SOME TESTS FAILED ❌',
        'flow_status' => [
            'announcement_creation' => $apiResult['success'] ? 'Working ✅' : 'Failed ❌',
            'database_storage' => isset($announcement) && $announcement ? 'Working ✅' : 'Failed ❌',
            'user_notifications' => isset($notificationCount) && $notificationCount > 0 ? 'Working ✅' : 'Failed ❌',
            'mobile_app_visibility' => isset($hasAnnouncement) && $hasAnnouncement ? 'Working ✅' : 'Failed ❌',
            'web_admin_display' => $webResult['success'] ? 'Working ✅' : 'Failed ❌'
        ],
        'recommendations' => $failCount === 0 ? [
            '1. ✅ Complete announcements flow is working correctly',
            '2. ✅ Announcements are sent to users successfully',
            '3. ✅ Users receive notifications in mobile app',
            '4. ✅ Web admin can view announcements',
            '5. ✅ All components are integrated properly'
        ] : [
            '1. ❌ Check database table existence',
            '2. ❌ Verify API endpoint functionality',
            '3. ❌ Check user data and permissions',
            '4. ❌ Review error messages for specific issues',
            '5. ❌ Test individual components separately'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'complete_announcements_flow_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
