<?php
/**
 * Test Database Connection Path
 */

header('Content-Type: application/json');

$paths_to_test = [
    'relative_up_one' => '../datab_try.php',
    'relative_up_two' => '../../datab_try.php',
    'absolute_from_root' => $_SERVER['DOCUMENT_ROOT'] . '/HiryoOrg/FrontEnd/pages/datab_try.php',
    'absolute_hostinger' => '/home/u987478351/domains/hiryoorganics.swuitapp.com/public_html/FrontEnd/pages/datab_try.php',
    'relative_api_up' => __DIR__ . '/../datab_try.php',
    'relative_api_up_two' => __DIR__ . '/../../datab_try.php'
];

$results = [];

foreach ($paths_to_test as $name => $path) {
    $results[$name] = [
        'path' => $path,
        'file_exists' => file_exists($path),
        'is_readable' => is_readable($path),
        'file_size' => file_exists($path) ? filesize($path) : 0
    ];
    
    // Try to include the file if it exists
    if (file_exists($path)) {
        try {
            ob_start();
            $include_result = include_once $path;
            $output = ob_get_clean();
            $results[$name]['include_success'] = true;
            $results[$name]['include_output'] = $output;
            $results[$name]['getDBConnection_exists'] = function_exists('getDBConnection');
            
            // Test database connection
            if (function_exists('getDBConnection')) {
                $conn = getDBConnection();
                $results[$name]['database_connection'] = $conn ? 'success' : 'failed';
            } else {
                $results[$name]['database_connection'] = 'getDBConnection function not found';
            }
        } catch (Exception $e) {
            $results[$name]['include_success'] = false;
            $results[$name]['include_error'] = $e->getMessage();
        }
    }
}

// Check current directory structure
$results['current_dir'] = __DIR__;
$results['document_root'] = $_SERVER['DOCUMENT_ROOT'];
$results['script_filename'] = $_SERVER['SCRIPT_FILENAME'];

echo json_encode([
    'database_path_test' => $results,
    'conclusion' => 'Check which path has file_exists: true and include_success: true',
    'recommendations' => [
        'Find the correct path to datab_try.php',
        'Update all API files to use the correct path',
        'Ensure database connection works'
    ]
], JSON_PRETTY_PRINT);
?>
