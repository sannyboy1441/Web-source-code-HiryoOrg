<?php
// Debug script to test transaction handling
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

// Include database connection
$db_path = '../datab_try.php';
if (!@include_once $db_path) {
    echo json_encode(['success' => false, 'message' => 'Database connection file not found']);
    exit;
}

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Test if we can start and commit a transaction
    echo json_encode([
        'success' => true,
        'message' => 'Testing transaction handling',
        'data' => [
            'connection_type' => get_class($conn),
            'can_start_transaction' => true,
            'test_completed' => true
        ]
    ]);
    
    // Test actual transaction
    $conn->beginTransaction();
    $conn->commit();
    
    echo "\n" . json_encode([
        'success' => true,
        'message' => 'Transaction test successful'
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Transaction test failed: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'message' => $e->getMessage()
        ]
    ]);
}
?>
