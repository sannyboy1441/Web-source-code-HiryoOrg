<?php
// Check what orders are actually available
header('Content-Type: text/plain');

echo "=== CHECKING AVAILABLE ORDERS ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check orders table
    echo "=== ORDERS TABLE ===\n";
    $orders_stmt = $conn->prepare("SELECT order_id, status, total_amount, order_date FROM orders ORDER BY order_id DESC LIMIT 10");
    $orders_stmt->execute();
    $orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "❌ No orders found in orders table!\n";
    } else {
        echo "Found " . count($orders) . " orders in orders table:\n";
        foreach ($orders as $order) {
            echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}, Date: {$order['order_date']}\n";
        }
    }
    
    // Check transactions table
    echo "\n=== TRANSACTIONS TABLE ===\n";
    $trans_stmt = $conn->prepare("SELECT transaction_id, order_id, customer_name, amount, created_at FROM transactions ORDER BY transaction_id DESC LIMIT 10");
    $trans_stmt->execute();
    $transactions = $trans_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($transactions)) {
        echo "❌ No transactions found in transactions table!\n";
    } else {
        echo "Found " . count($transactions) . " transactions in transactions table:\n";
        foreach ($transactions as $trans) {
            echo "   - Transaction #{$trans['transaction_id']}: Order #{$trans['order_id']}, Customer: {$trans['customer_name']}, Amount: {$trans['amount']}, Date: {$trans['created_at']}\n";
        }
    }
    
    // Check if there are any orders that can be completed
    echo "\n=== ORDERS THAT CAN BE COMPLETED ===\n";
    $completable_stmt = $conn->prepare("SELECT order_id, status FROM orders WHERE status IN ('Delivered', 'Shipped', 'Processing', 'Pending') ORDER BY order_id DESC");
    $completable_stmt->execute();
    $completable_orders = $completable_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($completable_orders)) {
        echo "❌ No orders found that can be completed!\n";
    } else {
        echo "Found " . count($completable_orders) . " orders that can be completed:\n";
        foreach ($completable_orders as $order) {
            echo "   - Order #{$order['order_id']}: {$order['status']}\n";
        }
    }
    
    echo "\n=== SUMMARY ===\n";
    if (empty($orders)) {
        echo "⚠️ Orders table is empty - all orders may have been processed\n";
    } else {
        echo "✅ Orders table has " . count($orders) . " orders\n";
    }
    
    if (empty($completable_orders)) {
        echo "⚠️ No orders available for completion testing\n";
    } else {
        echo "✅ " . count($completable_orders) . " orders available for completion testing\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
