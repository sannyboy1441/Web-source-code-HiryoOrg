<?php
// Debug the transfer issue step by step
header('Content-Type: text/plain');

echo "Debugging Transfer Issue...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Create a test order with items
    echo "Creating test order with items...\n";
    
    // Get a user
    $user_stmt = $conn->prepare("SELECT user_id, firstName, lastName FROM users LIMIT 1");
    $user_stmt->execute();
    $user = $user_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo "❌ No users found!\n";
        exit;
    }
    
    // Create order
    $timestamp = time();
    $create_order_stmt = $conn->prepare("
        INSERT INTO orders (user_id, status, total_amount, subtotal, delivery_fee, payment_method, delivery_method, shipping_address, order_date) 
        VALUES (?, 'Pending', ?, ?, ?, 'COD', 'Delivery', ?, NOW())
    ");
    $create_order_stmt->execute([$user['user_id'], 200.00, 180.00, 20.00, "Debug Address $timestamp"]);
    $test_order_id = $conn->lastInsertId();
    
    echo "✅ Test order created with ID: $test_order_id\n";
    
    // Create order items
    $product_stmt = $conn->prepare("SELECT product_id, product_name, price FROM products LIMIT 1");
    $product_stmt->execute();
    $product = $product_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($product) {
        $create_item_stmt = $conn->prepare("
            INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) 
            VALUES (?, ?, 2, ?)
        ");
        $create_item_stmt->execute([$test_order_id, $product['product_id'], $product['price']]);
        echo "✅ Order item created: {$product['product_name']} x 2\n";
    } else {
        echo "⚠️ No products found, creating order without items\n";
    }
    
    echo "\n";
    
    // Now test the transfer logic manually
    echo "=== TESTING TRANSFER LOGIC MANUALLY ===\n";
    
    // Get order details
    $order_stmt = $conn->prepare("
        SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_id = ?
    ");
    $order_stmt->execute([$test_order_id]);
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "❌ Order not found!\n";
        exit;
    }
    
    echo "✅ Order found:\n";
    echo "- ID: {$order['order_id']}\n";
    echo "- Customer: {$order['firstName']} {$order['lastName']}\n";
    echo "- Total: {$order['total_amount']}\n";
    echo "- User ID: {$order['user_id']}\n\n";
    
    // Get order items
    $items_stmt = $conn->prepare("
        SELECT oi.*, p.product_name 
        FROM order_items oi 
        LEFT JOIN products p ON oi.product_id = p.product_id 
        WHERE oi.order_id = ?
    ");
    $items_stmt->execute([$test_order_id]);
    $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Order items found: " . count($items) . " items\n";
    foreach ($items as $item) {
        echo "- {$item['product_name']}: {$item['quantity']} x {$item['price_at_purchase']}\n";
    }
    echo "\n";
    
    // Test creating transactions table
    echo "=== TESTING TRANSACTIONS TABLE ===\n";
    $create_table_sql = "
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            user_id INT NOT NULL,
            customer_name VARCHAR(255),
            customer_email VARCHAR(255),
            customer_contact VARCHAR(20),
            delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            shipping_address TEXT,
            subtotal DECIMAL(10,2) NOT NULL,
            delivery_fee DECIMAL(10,2) NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            created_at DATETIME NOT NULL,
            items JSON,
            INDEX idx_user_id (user_id),
            INDEX idx_created_at (created_at)
        )
    ";
    
    try {
        $conn->exec($create_table_sql);
        echo "✅ Transactions table created/verified\n";
    } catch (Exception $e) {
        echo "❌ Error creating transactions table: " . $e->getMessage() . "\n";
    }
    
    // Test inserting into transactions table
    echo "\n=== TESTING INSERT INTO TRANSACTIONS ===\n";
    
    $customer_name = trim($order['firstName'] . ' ' . $order['lastName']);
    $items_json = json_encode($items);
    
    echo "Prepared data:\n";
    echo "- Customer Name: '$customer_name'\n";
    echo "- Email: {$order['email']}\n";
    echo "- Contact: {$order['contact_number']}\n";
    echo "- Delivery Method: {$order['delivery_method']}\n";
    echo "- Payment Method: {$order['payment_method']}\n";
    echo "- Shipping Address: {$order['shipping_address']}\n";
    echo "- Subtotal: {$order['subtotal']}\n";
    echo "- Delivery Fee: {$order['delivery_fee']}\n";
    echo "- Total Amount: {$order['total_amount']}\n";
    echo "- Items JSON: $items_json\n\n";
    
    $trans_stmt = $conn->prepare("
        INSERT INTO transactions (
            order_id, user_id, customer_name, customer_email, customer_contact,
            delivery_method, payment_method, shipping_address, subtotal, 
            delivery_fee, amount, created_at, items
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
    ");
    
    try {
        $trans_result = $trans_stmt->execute([
            $test_order_id,
            $order['user_id'],
            $customer_name,
            $order['email'],
            $order['contact_number'],
            $order['delivery_method'],
            $order['payment_method'],
            $order['shipping_address'],
            $order['subtotal'],
            $order['delivery_fee'],
            $order['total_amount'],
            $items_json
        ]);
        
        if ($trans_result) {
            echo "✅ Successfully inserted order #$test_order_id into transactions table\n";
            
            // Verify the insert
            $verify_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
            $verify_stmt->execute([$test_order_id]);
            $verify_transaction = $verify_stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($verify_transaction) {
                echo "✅ Verification successful - transaction found:\n";
                echo "- Transaction ID: {$verify_transaction['transaction_id']}\n";
                echo "- Customer: {$verify_transaction['customer_name']}\n";
                echo "- Amount: {$verify_transaction['amount']}\n";
            } else {
                echo "❌ Verification failed - transaction not found after insert\n";
            }
        } else {
            echo "❌ Failed to insert into transactions table\n";
            $errorInfo = $trans_stmt->errorInfo();
            echo "Error Info: " . json_encode($errorInfo) . "\n";
        }
    } catch (Exception $e) {
        echo "❌ Exception during insert: " . $e->getMessage() . "\n";
        echo "File: " . $e->getFile() . "\n";
        echo "Line: " . $e->getLine() . "\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
