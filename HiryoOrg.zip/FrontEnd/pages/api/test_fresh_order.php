<?php
// Test with a completely fresh order
header('Content-Type: text/plain');

echo "Testing with Fresh Order...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Create a completely fresh test order
    echo "Creating fresh test order...\n";
    
    // Get a user
    $user_stmt = $conn->prepare("SELECT user_id, firstName, lastName FROM users LIMIT 1");
    $user_stmt->execute();
    $user = $user_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo "❌ No users found!\n";
        exit;
    }
    
    // Create order with a unique timestamp to avoid conflicts
    $timestamp = time();
    $create_order_stmt = $conn->prepare("
        INSERT INTO orders (user_id, status, total_amount, subtotal, delivery_fee, payment_method, delivery_method, shipping_address, order_date) 
        VALUES (?, 'Pending', ?, ?, ?, 'COD', 'Delivery', ?, NOW())
    ");
    $create_order_stmt->execute([$user['user_id'], 150.00, 130.00, 20.00, "Test Address $timestamp"]);
    $test_order_id = $conn->lastInsertId();
    
    echo "✅ Fresh test order created with ID: $test_order_id\n\n";
    
    // Verify the order exists
    $verify_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $verify_stmt->execute([$test_order_id]);
    $verify_order = $verify_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($verify_order) {
        echo "✅ Order verified in orders table:\n";
        echo "- Status: {$verify_order['status']}\n";
        echo "- Total: {$verify_order['total_amount']}\n\n";
    } else {
        echo "❌ Order not found in orders table!\n";
        exit;
    }
    
    // Test the API call
    echo "=== TESTING API WITH FRESH ORDER ===\n";
    
    // Set up POST data
    $_POST = [];
    $_POST['order_id'] = $test_order_id;
    $_POST['status'] = 'Completed';
    $_GET['action'] = 'update_order_status';
    
    echo "Making API call with: order_id=$test_order_id, status=Completed\n";
    
    // Capture the API response
    ob_start();
    
    // Include the API file
    include 'orders_api_v2.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Check results
    echo "=== CHECKING RESULTS ===\n";
    
    // Check if order still exists in orders table
    $check_order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $check_order_stmt->execute([$test_order_id]);
    $order_still_exists = $check_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_still_exists) {
        echo "❌ Order still exists in orders table:\n";
        echo "- Status: {$order_still_exists['status']}\n";
        echo "- Total: {$order_still_exists['total_amount']}\n";
    } else {
        echo "✅ Order removed from orders table\n";
    }
    
    // Check if order exists in transactions table
    $check_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $check_trans_stmt->execute([$test_order_id]);
    $order_in_transactions = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_in_transactions) {
        echo "✅ Order successfully transferred to transactions table:\n";
        echo "- Transaction ID: {$order_in_transactions['transaction_id']}\n";
        echo "- Customer: {$order_in_transactions['customer_name']}\n";
        echo "- Amount: {$order_in_transactions['amount']}\n";
    } else {
        echo "❌ Order NOT found in transactions table - TRANSFER FAILED!\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if (!$order_still_exists && $order_in_transactions) {
        echo "🎉 SUCCESS: Order completion is working perfectly!\n";
        echo "✅ Order transferred to transactions table\n";
        echo "✅ Order removed from orders table\n";
        echo "✅ Web admin will show 'No orders found' (correct behavior)\n";
    } else {
        echo "❌ FAILURE: Order completion still has issues!\n";
        if ($order_still_exists) echo "- Order still in orders table\n";
        if (!$order_in_transactions) echo "- Order not in transactions table\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
