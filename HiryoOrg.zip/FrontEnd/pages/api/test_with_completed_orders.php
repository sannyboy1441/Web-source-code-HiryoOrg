<?php
// Test with completed orders to see if they're in transactions table
header('Content-Type: text/plain');

echo "=== TESTING COMPLETED ORDERS TRANSFER ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check orders table
    echo "=== ORDERS TABLE ===\n";
    $orders_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders ORDER BY order_id DESC LIMIT 5");
    $orders_stmt->execute();
    $orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "❌ No orders found in orders table!\n";
    } else {
        echo "Orders in orders table:\n";
        foreach ($orders as $order) {
            echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}\n";
        }
    }
    
    // Check transactions table
    echo "\n=== TRANSACTIONS TABLE ===\n";
    $trans_stmt = $conn->prepare("SELECT transaction_id, order_id, customer_name, amount, created_at FROM transactions ORDER BY transaction_id DESC LIMIT 5");
    $trans_stmt->execute();
    $transactions = $trans_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($transactions)) {
        echo "❌ No transactions found in transactions table!\n";
    } else {
        echo "Transactions in transactions table:\n";
        foreach ($transactions as $trans) {
            echo "   - Transaction #{$trans['transaction_id']}: Order #{$trans['order_id']}, Customer: {$trans['customer_name']}, Amount: {$trans['amount']}, Date: {$trans['created_at']}\n";
        }
    }
    
    // Check if completed orders are in transactions
    echo "\n=== CHECKING IF COMPLETED ORDERS ARE IN TRANSACTIONS ===\n";
    $completed_orders_stmt = $conn->prepare("SELECT order_id FROM orders WHERE status = 'Completed'");
    $completed_orders_stmt->execute();
    $completed_orders = $completed_orders_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($completed_orders)) {
        echo "✅ No completed orders in orders table - they were properly transferred!\n";
    } else {
        echo "❌ Found " . count($completed_orders) . " completed orders still in orders table:\n";
        foreach ($completed_orders as $order_id) {
            echo "   - Order #$order_id\n";
        }
    }
    
    // Check if any of these completed orders are in transactions
    if (!empty($completed_orders)) {
        $placeholders = str_repeat('?,', count($completed_orders) - 1) . '?';
        $check_trans_stmt = $conn->prepare("SELECT order_id FROM transactions WHERE order_id IN ($placeholders)");
        $check_trans_stmt->execute($completed_orders);
        $transferred_orders = $check_trans_stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "\nOf these completed orders, " . count($transferred_orders) . " are in transactions table:\n";
        foreach ($transferred_orders as $order_id) {
            echo "   - Order #$order_id ✅\n";
        }
        
        $not_transferred = array_diff($completed_orders, $transferred_orders);
        if (!empty($not_transferred)) {
            echo "\nOrders NOT transferred to transactions:\n";
            foreach ($not_transferred as $order_id) {
                echo "   - Order #$order_id ❌\n";
            }
        }
    }
    
    echo "\n=== SUMMARY ===\n";
    if (empty($completed_orders)) {
        echo "🎉 SUCCESS: All completed orders were properly transferred to transactions table!\n";
        echo "✅ The order completion process is working correctly!\n";
    } else {
        echo "⚠️ ISSUE: Some completed orders are still in orders table and not in transactions table.\n";
        echo "🔧 This means the transfer process is not working for some orders.\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
