<?php
// Test the API and capture error logs
header('Content-Type: text/plain');

echo "Testing API with Error Log Capture...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Create a test order with items
    echo "Creating test order with items...\n";
    
    // Get a user
    $user_stmt = $conn->prepare("SELECT user_id, firstName, lastName FROM users LIMIT 1");
    $user_stmt->execute();
    $user = $user_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo "❌ No users found!\n";
        exit;
    }
    
    // Create order
    $timestamp = time();
    $create_order_stmt = $conn->prepare("
        INSERT INTO orders (user_id, status, total_amount, subtotal, delivery_fee, payment_method, delivery_method, shipping_address, order_date) 
        VALUES (?, 'Pending', ?, ?, ?, 'COD', 'Delivery', ?, NOW())
    ");
    $create_order_stmt->execute([$user['user_id'], 250.00, 220.00, 30.00, "API Test Address $timestamp"]);
    $test_order_id = $conn->lastInsertId();
    
    echo "✅ Test order created with ID: $test_order_id\n";
    
    // Create order items
    $product_stmt = $conn->prepare("SELECT product_id, product_name, price FROM products LIMIT 1");
    $product_stmt->execute();
    $product = $product_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($product) {
        $create_item_stmt = $conn->prepare("
            INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) 
            VALUES (?, ?, 1, ?)
        ");
        $create_item_stmt->execute([$test_order_id, $product['product_id'], $product['price']]);
        echo "✅ Order item created: {$product['product_name']}\n";
    }
    
    echo "\n";
    
    // Test the API call
    echo "=== TESTING API CALL ===\n";
    
    // Set up POST data
    $_POST = [];
    $_POST['order_id'] = $test_order_id;
    $_POST['status'] = 'Completed';
    $_GET['action'] = 'update_order_status';
    
    echo "Making API call with: order_id=$test_order_id, status=Completed\n";
    
    // Capture the API response
    ob_start();
    
    // Include the API file
    include 'orders_api_v2.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Check results
    echo "=== CHECKING RESULTS ===\n";
    
    // Check if order still exists in orders table
    $check_order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $check_order_stmt->execute([$test_order_id]);
    $order_still_exists = $check_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_still_exists) {
        echo "❌ Order still exists in orders table:\n";
        echo "- Status: {$order_still_exists['status']}\n";
        echo "- Total: {$order_still_exists['total_amount']}\n";
    } else {
        echo "✅ Order removed from orders table\n";
    }
    
    // Check if order exists in transactions table
    $check_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $check_trans_stmt->execute([$test_order_id]);
    $order_in_transactions = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_in_transactions) {
        echo "✅ Order successfully transferred to transactions table:\n";
        echo "- Transaction ID: {$order_in_transactions['transaction_id']}\n";
        echo "- Customer: {$order_in_transactions['customer_name']}\n";
        echo "- Amount: {$order_in_transactions['amount']}\n";
    } else {
        echo "❌ Order NOT found in transactions table - TRANSFER FAILED!\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if (!$order_still_exists && $order_in_transactions) {
        echo "🎉 SUCCESS: API is working!\n";
    } else {
        echo "❌ FAILURE: API still has issues!\n";
        echo "Check the server error logs for detailed error messages.\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
