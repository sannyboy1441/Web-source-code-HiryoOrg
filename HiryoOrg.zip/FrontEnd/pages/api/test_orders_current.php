<?php
/**
 * Test Orders Current
 * This script tests the current orders API to see what's actually deployed
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check what's actually in the orders_api.php file
    $ordersApiPath = __DIR__ . '/orders_api.php';
    if (file_exists($ordersApiPath)) {
        $fileContent = file_get_contents($ordersApiPath);
        
        // Look for specific patterns
        $patterns = [
            'has_place_order_case' => strpos($fileContent, "case 'place_order':") !== false,
            'has_handlePlaceOrder' => strpos($fileContent, 'handlePlaceOrder') !== false,
            'has_post_check' => strpos($fileContent, '$_SERVER[\'REQUEST_METHOD\']') !== false,
            'file_size' => strlen($fileContent),
            'last_modified' => date('Y-m-d H:i:s', filemtime($ordersApiPath))
        ];
        
        $testResults['tests']['file_content_check'] = $patterns;
    }
    
    // Test 2: Test the debug orders API
    $debugUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/debug_orders_api.php?action=place_order';
    
    $response = @file_get_contents($debugUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 10
        ]
    ]));
    
    $debugResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response'];
    
    $testResults['tests']['debug_api_test'] = [
        'url' => $debugUrl,
        'response' => $debugResult
    ];
    
    // Test 3: Test debug API with POST
    $debugPostUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/debug_orders_api.php';
    $postData = http_build_query(['action' => 'place_order']);
    
    $postResponse = @file_get_contents($debugPostUrl, false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 10
        ]
    ]));
    
    $debugPostResult = $postResponse ? json_decode($postResponse, true) : ['success' => false, 'message' => 'No response'];
    
    $testResults['tests']['debug_api_post_test'] = [
        'url' => $debugPostUrl,
        'post_data' => $postData,
        'response' => $debugPostResult
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
