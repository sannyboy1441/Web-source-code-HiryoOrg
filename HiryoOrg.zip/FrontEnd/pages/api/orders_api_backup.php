<?php
/**
 * UNIFIED Orders API
 * Serves BOTH the Web Admin Panel and the Mobile App.
 * This single file replaces order_api.php and oders.php.
 */

// Start output buffering to prevent any unwanted output
ob_start();

// Suppress any warnings or notices that might interfere with JSON output
error_reporting(E_ERROR | E_PARSE);

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Clear any output that might have been generated
ob_clean();

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database connection with error handling
$db_path = '../datab_try.php';
if (!@include_once $db_path) {
    ob_clean();
    echo json_encode(['success' => false, 'message' => 'Database connection file not found at: ' . $db_path]);
    exit;
}

// --- Main API Router ---
try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    // Handle both GET and POST requests (workaround for server issue)
    $action = '';
    
    // Try POST first, then GET, then REQUEST
    if (!empty($_POST['action'])) {
        $action = $_POST['action'];
    } elseif (!empty($_GET['action'])) {
        $action = $_GET['action'];
    } else {
        $action = $_REQUEST['action'] ?? '';
    }
    
    // Debug logging for action detection
    error_log("Orders API - Action detected: '$action' from method: " . $_SERVER['REQUEST_METHOD']);

    switch ($action) {
        // --- Test endpoint ---
        case 'test':
            echo json_encode(['success' => true, 'message' => 'Orders API is working', 'timestamp' => date('Y-m-d H:i:s')]);
            break;
            
        // --- Actions primarily for the MOBILE APP ---
        case 'place_order':
            handlePlaceOrder($conn);
            break;
            
        case 'get_user_orders': // Renamed for clarity
            handleGetUserOrders($conn);
            break;

        // --- Actions for BOTH Admin and Mobile App ---
        case 'get_order_details':
            handleGetOrderDetails($conn);
            break;
            
        // --- Actions primarily for the WEB ADMIN PANEL ---
        case 'get_all_orders_for_admin': // Renamed for clarity
            handleGetAllOrdersForAdmin($conn);
            break;
            
        case 'update_order_status':
            handleUpdateOrderStatus($conn);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action specified']);
            break;
    }

} catch (Exception $e) {
    // Clean any output and return proper error JSON
    ob_clean();
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Server error occurred: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]
    ]);
    error_log("Orders API Error: " . $e->getMessage());
    error_log("Orders API Error Trace: " . $e->getTraceAsString());
}

// End output buffering and flush
ob_end_flush();

/**
 * FOR MOBILE APP: Places a new order
 */
function handlePlaceOrder($conn) {
    // Allow both POST and GET due to server configuration issues
    // if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    //     echo json_encode(['success' => false, 'message' => 'Only POST method is allowed.']);
    //     return;
    // }

    // --- Data validation --- (handle both POST and GET)
    $user_id = (int)($_POST['user_id'] ?? $_GET['user_id'] ?? 0);
    $total_amount = (float)($_POST['total_amount'] ?? $_GET['total_amount'] ?? 0);
    $items_json = $_POST['items'] ?? $_GET['items'] ?? '[]';
    $items = json_decode($items_json, true);
    
    // Debug logging removed to prevent output corruption
    
    if ($user_id <= 0 || $total_amount <= 0 || json_last_error() !== JSON_ERROR_NONE || empty($items)) {
        $error_msg = "Invalid or missing order data. user_id: $user_id, total_amount: $total_amount, json_error: " . json_last_error() . ", items_count: " . count($items);
        error_log("Order placement failed: " . $error_msg);
        echo json_encode(['success' => false, 'message' => $error_msg]);
        return;
    }
    
    // --- Get additional order details (preserved from your web admin API) ---
    $payment_method = trim($_POST['payment_method'] ?? $_GET['payment_method'] ?? 'COD');
    $delivery_method = trim($_POST['delivery_method'] ?? $_GET['delivery_method'] ?? 'Standard');
    $shipping_address = trim($_POST['shipping_address'] ?? $_GET['shipping_address'] ?? '');

    try {
        $conn->beginTransaction();

        // 1. Insert into the main 'orders' table
        $stmt_order = $conn->prepare("
            INSERT INTO orders (user_id, total_amount, payment_method, delivery_method, shipping_address, status, order_date) 
            VALUES (?, ?, ?, ?, ?, 'Pending', NOW())
        ");
        $stmt_order->execute([$user_id, $total_amount, $payment_method, $delivery_method, $shipping_address]);
        $order_id = $conn->lastInsertId();

        // 2. Insert order items
        foreach ($items as $item) {
            $stmt_item = $conn->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt_item->execute([
                $order_id, 
                $item['product_id'], 
                $item['quantity'], 
                $item['price'] // Mobile app sends 'price', database expects 'price_at_purchase'
            ]);
        }

        $conn->commit();
        
        echo json_encode(['success' => true, 'message' => 'Order placed successfully!', 'order_id' => (int)$order_id]);

        // Send notification to admin (outside transaction to prevent rollback)
        sendNewOrderNotification($conn, $order_id, $user_id, $total_amount);

    } catch (Exception $e) {
        if ($conn) {
            $conn->rollBack();
        }
        error_log("Order placement error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Order placement failed: ' . $e->getMessage()]);
        return;
    }
}

/**
 * FOR MOBILE APP: Retrieves the order history for a specific user.
 */
function handleGetUserOrders($conn) {
    $user_id = (int)($_GET['user_id'] ?? 0);
    if ($user_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid user ID is required.']);
        return;
    }

    $stmt = $conn->prepare("
        SELECT order_id, total_amount, status, order_date FROM orders 
        WHERE user_id = ? ORDER BY order_date DESC
    ");
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'orders' => $orders]);
}

/**
 * FOR BOTH: Gets detailed information about a specific order.
 */
function handleGetOrderDetails($conn) {
    try {
        // Log the start of the function
        error_log("handleGetOrderDetails called with order_id: " . ($_GET['order_id'] ?? 'not set'));
        
        // Debug output to help identify the issue
        $debug_info = [
            'timestamp' => date('Y-m-d H:i:s'),
            'order_id_requested' => $_GET['order_id'] ?? 'not set',
            'function_started' => true,
            'connection_status' => $conn ? 'connected' : 'not_connected',
            'php_version' => phpversion(),
            'memory_usage' => memory_get_usage(true)
        ];
        
        $order_id = (int)($_GET['order_id'] ?? 0);
        if ($order_id <= 0) {
            error_log("Invalid order_id provided: " . ($_GET['order_id'] ?? 'not set'));
            echo json_encode(['success' => false, 'message' => 'Valid order ID is required.', 'debug' => $debug_info]);
            return;
        }
        
        $debug_info['order_id'] = $order_id;
        error_log("Processing order_id: $order_id");
        
        // First check if order exists
        $stmt_check = $conn->prepare("SELECT order_id, user_id FROM orders WHERE order_id = ?");
        $stmt_check->execute([$order_id]);
        $orderCheck = $stmt_check->fetch(PDO::FETCH_ASSOC);
        
        if (!$orderCheck) {
            echo json_encode(['success' => false, 'message' => 'Order not found.']);
            return;
        }
        
        // Log for debugging
        error_log("Getting details for order #$order_id with user_id: " . $orderCheck['user_id']);

        // Get order details with customer info
        $stmt_order = $conn->prepare("
            SELECT o.*, u.firstName, u.lastName, u.email, 
                   u.contact_number as contact_number
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.user_id 
            WHERE o.order_id = ?
        ");
        $stmt_order->execute([$order_id]);
        $order = $stmt_order->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            echo json_encode(['success' => false, 'message' => 'Failed to fetch order with user details.']);
            return;
        }

        // Get order items
        $stmt_items = $conn->prepare("
            SELECT oi.*, p.product_name, p.image_url 
            FROM order_items oi 
            LEFT JOIN products p ON oi.product_id = p.product_id 
            WHERE oi.order_id = ?
        ");
        $stmt_items->execute([$order_id]);
        $items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);

        $order['items'] = $items;
        
        // Log success for debugging
        error_log("Successfully fetched order #$order_id details with " . count($items) . " items");
        
        $debug_info['final_success'] = true;
        $debug_info['items_count'] = count($items);
        
        echo json_encode(['success' => true, 'order' => $order, 'debug' => $debug_info]);
        
    } catch (Exception $e) {
        error_log("Error in handleGetOrderDetails for order #$order_id: " . $e->getMessage());
        error_log("Stack trace: " . $e->getTraceAsString());
        echo json_encode([
            'success' => false, 
            'message' => 'Failed to fetch order details: ' . $e->getMessage(),
            'error_details' => [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ],
            'debug_info' => $debug_info ?? null
        ]);
    }
}

/**
 * FOR WEB ADMIN: Retrieves all orders for admin panel display.
 */
function handleGetAllOrdersForAdmin($conn) {
    try {
        // CORRECTED: Join on user_id which is the correct primary key in users table
        $stmt = $conn->prepare("
            SELECT o.*, u.firstName, u.lastName, u.email, CONCAT(u.firstName, ' ', u.lastName) as customer_name
            FROM orders o LEFT JOIN users u ON o.user_id = u.user_id
            ORDER BY o.order_date DESC
        ");
        $stmt->execute();
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'orders' => $orders]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to retrieve orders.']);
        error_log("Get all orders failed: " . $e->getMessage());
    }
}

/**
 * FOR WEB ADMIN: Updates the status of an order.
 */
function handleUpdateOrderStatus($conn) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Only POST method is allowed.']);
        return;
    }

    $order_id = (int)($_POST['order_id'] ?? 0);
    $new_status = trim($_POST['status'] ?? '');

    if ($order_id <= 0 || empty($new_status)) {
        echo json_encode(['success' => false, 'message' => 'Valid order ID and status are required.']);
        return;
    }

    try {
        $conn->beginTransaction();

        // Update order status
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
        $result = $stmt->execute([$new_status, $order_id]);

        // If status is 'Completed' or 'Cancelled', move to transactions
        if ($new_status === 'Completed' || $new_status === 'Cancelled') {
            moveOrderToTransactions($conn, $order_id, $new_status);
        }

        $conn->commit();

        echo json_encode(['success' => true, 'message' => 'Order status updated successfully.']);

    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'message' => 'Failed to update order status.']);
        error_log("Update order status failed: " . $e->getMessage());
    }
}

/**
 * Moves a completed or cancelled order to the transactions table
 */
function moveOrderToTransactions($conn, $order_id, $status = 'Completed') {
    try {
        // Get order details
        $stmt_order = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
        $stmt_order->execute([$order_id]);
        $order = $stmt_order->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            throw new Exception("Order not found");
        }

        // Insert into transactions table
        $stmt_transaction = $conn->prepare("
            INSERT INTO transactions (order_id, user_id, amount, payment_method, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt_transaction->execute([
            $order_id,
            $order['user_id'],
            $order['total_amount'],
            $order['payment_method']
        ]);

        // Send notification to customer based on status
        if ($status === 'Completed') {
            $notification_message = "🎉 Congratulations! Your order #$order_id has been completed successfully. Thank you for choosing Hiryo Organics!";
            $notification_title = "Order Completed";
        } else if ($status === 'Cancelled') {
            $notification_message = "❌ Your order #$order_id has been cancelled. If you have any questions, please contact our support team.";
            $notification_title = "Order Cancelled";
        }
        
        $stmt_notification = $conn->prepare(
            "INSERT INTO notifications (user_id, order_id, title, message, type, is_read, created_at) VALUES (?, ?, ?, ?, 'order', 0, NOW())"
        );
        $stmt_notification->execute([$order['user_id'], $order_id, $notification_title, $notification_message]);
        
    } catch (Exception $e) {
        error_log("Error moving order to transactions: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Sends notification to admin when a new order is placed
 */
function sendNewOrderNotification($conn, $order_id, $user_id, $total_amount) {
    try {
        // Get user details for the notification
        $stmt_user = $conn->prepare("SELECT CONCAT(firstName, ' ', lastName) as user_name FROM users WHERE user_id = ?");
        $stmt_user->execute([$user_id]);
        $user = $stmt_user->fetch(PDO::FETCH_ASSOC);
        $user_name = $user ? $user['user_name'] : 'Unknown User';
        
        // Find the admin user (first user with admin role or user_id = 1 as fallback)
        $stmt_admin = $conn->prepare("SELECT user_id FROM users WHERE roles = 'admin' LIMIT 1");
        $stmt_admin->execute();
        $admin = $stmt_admin->fetch(PDO::FETCH_ASSOC);
        $admin_user_id = $admin ? $admin['user_id'] : 1; // Fallback to user_id = 1
        
        // Create notification for admin
        $title = "New Order Received";
        $message = "New order #{$order_id} from {$user_name} for ₱" . number_format($total_amount, 2) . " has been placed.";
        
        $stmt_notification = $conn->prepare("
            INSERT INTO notifications (user_id, order_id, title, message, type, is_read, created_at) 
            VALUES (?, ?, ?, ?, 'order', 0, NOW())
        ");
        $result = $stmt_notification->execute([$admin_user_id, $order_id, $title, $message]);
        
        if (!$result) {
            error_log("Failed to insert notification for admin user_id: " . $admin_user_id . ", Error: " . implode(', ', $stmt_notification->errorInfo()));
        }
        
    } catch (Exception $e) {
        // Don't fail the order if notification fails
        error_log("Failed to send new order notification: " . $e->getMessage());
    }
}
?>
