<?php
// Debug the transaction insert issue
header('Content-Type: text/plain');

echo "=== DEBUGGING TRANSACTION INSERT ISSUE ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check transactions table structure
    echo "=== STEP 1: CHECKING TRANSACTIONS TABLE STRUCTURE ===\n";
    $describe_stmt = $conn->prepare("DESCRIBE transactions");
    $describe_stmt->execute();
    $columns = $describe_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Transactions table columns:\n";
    foreach ($columns as $column) {
        echo "   - {$column['Field']} ({$column['Type']}) - {$column['Null']} - {$column['Key']}\n";
    }
    
    // Check if Transaction ID 50 exists
    echo "\n=== STEP 2: CHECKING IF TRANSACTION ID 50 EXISTS ===\n";
    $check_stmt = $conn->prepare("SELECT * FROM transactions WHERE transaction_id = 50");
    $check_stmt->execute();
    $transaction = $check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($transaction) {
        echo "✅ Transaction ID 50 found:\n";
        foreach ($transaction as $key => $value) {
            echo "   - {$key}: {$value}\n";
        }
    } else {
        echo "❌ Transaction ID 50 NOT found!\n";
    }
    
    // Check if Order #55 exists in transactions table
    echo "\n=== STEP 3: CHECKING IF ORDER #55 EXISTS IN TRANSACTIONS ===\n";
    $order_check_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = 55");
    $order_check_stmt->execute();
    $order_transaction = $order_check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_transaction) {
        echo "✅ Order #55 found in transactions:\n";
        foreach ($order_transaction as $key => $value) {
            echo "   - {$key}: {$value}\n";
        }
    } else {
        echo "❌ Order #55 NOT found in transactions table!\n";
    }
    
    // Check all recent transactions
    echo "\n=== STEP 4: CHECKING ALL RECENT TRANSACTIONS ===\n";
    $recent_stmt = $conn->prepare("SELECT transaction_id, order_id, customer_name, amount, created_at FROM transactions ORDER BY transaction_id DESC LIMIT 5");
    $recent_stmt->execute();
    $recent_transactions = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($recent_transactions)) {
        echo "❌ No transactions found in table!\n";
    } else {
        echo "Recent transactions:\n";
        foreach ($recent_transactions as $trans) {
            echo "   - Transaction #{$trans['transaction_id']}: Order #{$trans['order_id']}, Customer: {$trans['customer_name']}, Amount: {$trans['amount']}, Date: {$trans['created_at']}\n";
        }
    }
    
    // Check if Order #55 exists in orders table
    echo "\n=== STEP 5: CHECKING IF ORDER #55 EXISTS IN ORDERS TABLE ===\n";
    $orders_check_stmt = $conn->prepare("SELECT order_id, status FROM orders WHERE order_id = 55");
    $orders_check_stmt->execute();
    $order_in_orders = $orders_check_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_in_orders) {
        echo "✅ Order #55 found in orders table: Status = {$order_in_orders['status']}\n";
    } else {
        echo "❌ Order #55 NOT found in orders table!\n";
    }
    
    // Try to manually insert a test transaction
    echo "\n=== STEP 6: TESTING MANUAL INSERT ===\n";
    try {
        $test_insert_stmt = $conn->prepare("
            INSERT INTO transactions (
                order_id, user_id, customer_name, customer_email, customer_contact,
                delivery_method, payment_method, shipping_address, subtotal,
                delivery_fee, amount, created_at, items
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
        ");
        
        $test_result = $test_insert_stmt->execute([
            999, // test order ID
            1,   // test user ID
            'Test Customer',
            'test@example.com',
            '1234567890',
            'Delivery',
            'Cash',
            'Test Address',
            100.00,
            10.00,
            110.00,
            '[]'
        ]);
        
        if ($test_result) {
            $test_transaction_id = $conn->lastInsertId();
            echo "✅ Test transaction inserted successfully (ID: {$test_transaction_id})\n";
            
            // Check if it actually exists
            $test_check_stmt = $conn->prepare("SELECT * FROM transactions WHERE transaction_id = ?");
            $test_check_stmt->execute([$test_transaction_id]);
            $test_transaction = $test_check_stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($test_transaction) {
                echo "✅ Test transaction verified in table\n";
                
                // Clean up test transaction
                $cleanup_stmt = $conn->prepare("DELETE FROM transactions WHERE transaction_id = ?");
                $cleanup_stmt->execute([$test_transaction_id]);
                echo "✅ Test transaction cleaned up\n";
            } else {
                echo "❌ Test transaction NOT found after insert!\n";
            }
        } else {
            echo "❌ Test transaction insert failed\n";
            $error_info = $test_insert_stmt->errorInfo();
            echo "   Error: " . $error_info[2] . "\n";
        }
    } catch (Exception $e) {
        echo "❌ Test insert failed with exception: " . $e->getMessage() . "\n";
    }
    
    echo "\n=== DEBUG COMPLETE ===\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
