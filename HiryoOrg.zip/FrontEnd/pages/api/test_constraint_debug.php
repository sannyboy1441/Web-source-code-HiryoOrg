<?php
/**
 * Test Constraint Debug
 * This script debugs the SQLSTATE[23000] constraint violation
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'debug_info' => []
    ];
    
    // Test 1: Check if user_id 1 exists
    $stmt = $conn->prepare("SELECT user_id, username, email FROM users WHERE user_id = 1");
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $testResults['debug_info']['user_check'] = [
        'user_id' => 1,
        'exists' => $user ? true : false,
        'user_data' => $user
    ];
    
    // Test 2: Check if product_id 46 exists
    $stmt = $conn->prepare("SELECT product_id, product_name, price FROM products WHERE product_id = 46");
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $testResults['debug_info']['product_check'] = [
        'product_id' => 46,
        'exists' => $product ? true : false,
        'product_data' => $product
    ];
    
    // Test 3: Check orders table structure
    $stmt = $conn->prepare("DESCRIBE orders");
    $stmt->execute();
    $ordersStructure = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['debug_info']['orders_table_structure'] = $ordersStructure;
    
    // Test 4: Check order_items table structure
    $stmt = $conn->prepare("DESCRIBE order_items");
    $stmt->execute();
    $orderItemsStructure = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['debug_info']['order_items_table_structure'] = $orderItemsStructure;
    
    // Test 5: Check foreign key constraints
    $stmt = $conn->prepare("
        SELECT 
            CONSTRAINT_NAME,
            TABLE_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM 
            INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
        WHERE 
            REFERENCED_TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME IN ('orders', 'order_items')
    ");
    $stmt->execute();
    $foreignKeys = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['debug_info']['foreign_keys'] = $foreignKeys;
    
    // Test 6: Try to insert a test order manually to see the exact error
    try {
        $conn->beginTransaction();
        
        // Try inserting into orders table first
        $stmt = $conn->prepare("
            INSERT INTO orders (user_id, total_amount, payment_method, delivery_method, shipping_address, status, order_date) 
            VALUES (?, ?, ?, ?, ?, 'Pending', NOW())
        ");
        $result = $stmt->execute([1, 388.00, 'Cash on Delivery', 'Delivery', 'Test Address']);
        $orderId = $conn->lastInsertId();
        
        $testResults['debug_info']['manual_order_insert'] = [
            'success' => $result,
            'order_id' => $orderId,
            'error' => null
        ];
        
        // Try inserting into order_items table
        $stmt = $conn->prepare("
            INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) 
            VALUES (?, ?, ?, ?)
        ");
        $result = $stmt->execute([$orderId, 46, 1, 280.00]);
        
        $testResults['debug_info']['manual_order_item_insert'] = [
            'success' => $result,
            'order_id' => $orderId,
            'product_id' => 46,
            'error' => null
        ];
        
        // Rollback the test transaction
        $conn->rollBack();
        
    } catch (Exception $e) {
        $conn->rollBack();
        $testResults['debug_info']['manual_insert_error'] = [
            'error_message' => $e->getMessage(),
            'error_code' => $e->getCode(),
            'constraint_violation' => strpos($e->getMessage(), 'SQLSTATE[23000]') !== false
        ];
    }
    
    // Test 7: Check for duplicate key constraints
    $stmt = $conn->prepare("SHOW CREATE TABLE orders");
    $stmt->execute();
    $ordersCreateTable = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $conn->prepare("SHOW CREATE TABLE order_items");
    $stmt->execute();
    $orderItemsCreateTable = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $testResults['debug_info']['table_definitions'] = [
        'orders' => $ordersCreateTable['Create Table'] ?? 'Not found',
        'order_items' => $orderItemsCreateTable['Create Table'] ?? 'Not found'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
