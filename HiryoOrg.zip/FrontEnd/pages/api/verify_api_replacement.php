<?php
/**
 * Verify API Replacement
 * This will check if the orders_api.php file was actually replaced
 */

header('Content-Type: application/json');

try {
    $ordersApiPath = 'orders_api.php';
    
    if (!file_exists($ordersApiPath)) {
        echo json_encode([
            'success' => false,
            'message' => 'orders_api.php file not found'
        ]);
        exit;
    }
    
    $content = file_get_contents($ordersApiPath);
    
    // Check for specific markers that indicate it's the new file
    $hasCleanStructure = strpos($content, '// Set headers first') !== false;
    $hasOldStructure = strpos($content, 'ob_start()') !== false;
    $hasFinalVersion = strpos($content, 'orders_api_final.php') !== false;
    
    // Check file size (the new file should be smaller)
    $fileSize = strlen($content);
    
    // Check last modified time
    $lastModified = date('Y-m-d H:i:s', filemtime($ordersApiPath));
    
    echo json_encode([
        'success' => true,
        'message' => 'orders_api.php file found',
        'file_size' => $fileSize,
        'last_modified' => $lastModified,
        'checks' => [
            'has_clean_structure' => $hasCleanStructure,
            'has_old_structure' => $hasOldStructure,
            'has_final_version_marker' => $hasFinalVersion
        ],
        'file_exists' => true,
        'readable' => is_readable($ordersApiPath)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error checking file: ' . $e->getMessage()
    ]);
}
?>
