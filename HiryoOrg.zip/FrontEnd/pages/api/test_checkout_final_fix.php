<?php
/**
 * Test Checkout Final Fix
 * This script tests the final checkout functionality
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test orders API with GET request (workaround for POST issue)
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/orders_api.php';
    
    // Sample order data (exactly what mobile app sends)
    $orderData = [
        'action' => 'place_order',
        'user_id' => 1,
        'total_amount' => 388.00,
        'delivery_fee' => 108.00,
        'items' => '[{"product_id":46,"quantity":1,"price":280.00}]',
        'delivery_method' => 'Delivery',
        'shipping_address' => 'Purok Malapati, Sitio Primitiva, Tungkop Minglanilla, Cebu 6046',
        'payment_method' => 'Cash on Delivery'
    ];
    
    // Test with GET request (workaround for server POST issue)
    $getUrl = $apiUrl . '?' . http_build_query($orderData);
    
    $response = @file_get_contents($getUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $orderResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['checkout_with_get_workaround'] = [
        'status' => $orderResult['success'] ? 'PASS' : 'FAIL',
        'message' => $orderResult['success'] ? 'Checkout successful with GET workaround!' : 'Checkout failed: ' . ($orderResult['message'] ?? 'Unknown error'),
        'api_url' => $getUrl,
        'response' => $orderResult,
        'order_id' => $orderResult['order_id'] ?? 'N/A',
        'workaround_method' => 'GET request (due to server POST issue)'
    ];
    
    // Test 2: Verify users exist
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if ($conn) {
        $stmt = $conn->prepare("SELECT user_id, username, roles FROM users WHERE user_id IN (1, 4)");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $testResults['tests']['users_verification'] = [
            'status' => count($users) >= 2 ? 'PASS' : 'FAIL',
            'message' => count($users) >= 2 ? 'Required users exist' : 'Missing required users',
            'users_found' => count($users),
            'users' => $users
        ];
    }
    
    // Test 3: Verify product exists
    if ($conn) {
        $stmt = $conn->prepare("SELECT product_id, product_name, price FROM products WHERE product_id = 46");
        $stmt->execute();
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['product_verification'] = [
            'status' => $product ? 'PASS' : 'FAIL',
            'message' => $product ? 'Product ID 46 exists' : 'Product ID 46 not found',
            'product_data' => $product
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'mobile_checkout_should_work' => $failCount === 0 ? 'YES - Mobile checkout should work now!' : 'NO - Still has issues',
        'server_issue' => 'POST requests converted to GET (server configuration)',
        'workaround_applied' => 'Orders API now handles both GET and POST requests',
        'recommendations' => $failCount === 0 ? [
            '1. Mobile app checkout should work now',
            '2. Server POST issue is worked around',
            '3. All prerequisites are met',
            '4. Test mobile app checkout now!'
        ] : [
            '1. Fix remaining issues',
            '2. Check database connections',
            '3. Verify API functionality'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'checkout_final_fix_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
