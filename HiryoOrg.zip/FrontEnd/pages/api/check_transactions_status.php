<?php
// Check what happened to the transactions table
header('Content-Type: text/plain');

echo "=== CHECKING TRANSACTIONS TABLE STATUS ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check transactions table
    echo "=== TRANSACTIONS TABLE ===\n";
    $trans_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $trans_stmt->execute();
    $trans_count = $trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "Total transactions in transactions table: {$trans_count['count']}\n";
    
    if ($trans_count['count'] > 0) {
        echo "\nRecent transactions:\n";
        $recent_stmt = $conn->prepare("SELECT transaction_id, order_id, amount, customer_name, created_at FROM transactions ORDER BY transaction_id DESC LIMIT 10");
        $recent_stmt->execute();
        $recent_trans = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($recent_trans as $trans) {
            echo "   - Transaction #{$trans['transaction_id']}: Order #{$trans['order_id']}, Amount: {$trans['amount']}, Customer: {$trans['customer_name']}, Date: {$trans['created_at']}\n";
        }
    } else {
        echo "❌ No transactions found in transactions table!\n";
    }
    
    // Check orders table
    echo "\n=== ORDERS TABLE ===\n";
    $orders_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders");
    $orders_stmt->execute();
    $orders_count = $orders_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "Total orders in orders table: {$orders_count['count']}\n";
    
    if ($orders_count['count'] > 0) {
        echo "\nOrders in orders table:\n";
        $all_orders_stmt = $conn->prepare("SELECT order_id, status, total_amount, order_date FROM orders ORDER BY order_id DESC LIMIT 10");
        $all_orders_stmt->execute();
        $all_orders = $all_orders_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($all_orders as $order) {
            echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}, Date: {$order['order_date']}\n";
        }
    } else {
        echo "✅ Orders table is empty\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    echo "Orders in orders table: {$orders_count['count']}\n";
    echo "Transactions in transactions table: {$trans_count['count']}\n";
    
    if ($trans_count['count'] == 0) {
        echo "\n❌ ISSUE: All transactions were deleted!\n";
        echo "This means the cleanup script deleted the transactions too.\n";
        echo "We need to restore the transactions from backup or recreate them.\n";
    } else {
        echo "\n✅ SUCCESS: Transactions are properly in the transactions table!\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
