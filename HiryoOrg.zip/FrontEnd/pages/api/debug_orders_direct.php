<?php
/**
 * Direct Order Debugging
 * This script directly tests the problematic orders
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $results = [];
    
    // Test orders #14, #15, #16
    $testOrders = [14, 15, 16];
    
    foreach ($testOrders as $orderId) {
        $results["order_$orderId"] = testOrderDirect($conn, $orderId);
    }
    
    echo json_encode($results, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}

function testOrderDirect($conn, $orderId) {
    $result = [
        'order_id' => $orderId,
        'steps' => [],
        'success' => false,
        'error' => null
    ];
    
    try {
        // Step 1: Check if order exists
        $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
        $stmt->execute([$orderId]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $result['steps']['order_exists'] = [
            'success' => !empty($order),
            'data' => $order
        ];
        
        if (empty($order)) {
            $result['error'] = "Order $orderId not found";
            return $result;
        }
        
        // Step 2: Check user
        $userId = $order['user_id'];
        $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $result['steps']['user_exists'] = [
            'success' => !empty($user),
            'user_id' => $userId,
            'data' => $user
        ];
        
        // Step 3: Test the exact API query
        $stmt = $conn->prepare("
            SELECT o.*, u.firstName, u.lastName, u.email, 
                   u.contact_number as contact_number
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.user_id 
            WHERE o.order_id = ?
        ");
        $stmt->execute([$orderId]);
        $orderWithUser = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $result['steps']['order_user_join'] = [
            'success' => !empty($orderWithUser),
            'data' => $orderWithUser
        ];
        
        // Step 4: Check order items
        $stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $stmt->execute([$orderId]);
        $orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $result['steps']['order_items'] = [
            'success' => true,
            'count' => count($orderItems),
            'data' => $orderItems
        ];
        
        // Step 5: Test items with products join
        $stmt = $conn->prepare("
            SELECT oi.*, p.product_name, p.image_url 
            FROM order_items oi 
            LEFT JOIN products p ON oi.product_id = p.product_id 
            WHERE oi.order_id = ?
        ");
        $stmt->execute([$orderId]);
        $itemsWithProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $result['steps']['items_products_join'] = [
            'success' => true,
            'count' => count($itemsWithProducts),
            'data' => $itemsWithProducts
        ];
        
        // Final result
        if ($orderWithUser) {
            $orderWithUser['items'] = $itemsWithProducts;
            $result['final_data'] = $orderWithUser;
            $result['success'] = true;
        } else {
            $result['error'] = "Failed to join order with user data";
        }
        
    } catch (Exception $e) {
        $result['error'] = $e->getMessage();
        $result['trace'] = $e->getTraceAsString();
    }
    
    return $result;
}
?>
