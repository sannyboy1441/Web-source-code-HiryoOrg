<?php
header('Content-Type: text/plain');
echo "=== SIMPLE TRANSACTION RESTORE ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    // Just insert the 9 transactions we know existed
    $transactions = [
        [24, 395.00, '2025-10-18 20:21:35'],
        [17, 238.00, '2025-10-17 18:48:11'],
        [15, 220.00, '2025-10-17 01:46:27'],
        [14, 231.00, '2025-10-17 01:46:50'],
        [13, 220.00, '2025-10-17 00:53:41'],
        [12, 335.00, '2025-10-12 12:03:07'],
        [11, 280.00, '2025-10-12 12:36:19'],
        [10, 167.94, '2025-10-12 11:41:08'],
        [9, 488.00, '2025-10-12 11:07:58']
    ];
    
    foreach ($transactions as $trans) {
        $stmt = $conn->prepare("INSERT INTO transactions (order_id, user_id, customer_name, amount, created_at, items) VALUES (?, 1, 'Customer', ?, ?, '[]')");
        $stmt->execute($trans);
        echo "Restored Order #{$trans[0]}\n";
    }
    
    echo "\nDone. Check your transactions page now.\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
