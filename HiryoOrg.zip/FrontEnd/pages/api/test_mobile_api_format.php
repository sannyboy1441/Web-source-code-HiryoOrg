<?php
/**
 * Test Mobile API Format
 * This script tests if the mobile API response format matches what the app expects
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test get_all_products API format
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_all_products';
    
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 10
        ]
    ]);
    
    $response = @file_get_contents($apiUrl, false, $context);
    $productsResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    // Test 2: Check response format matches mobile app expectations
    $expectedFields = ['success', 'products', 'message', 'count', 'total_count'];
    $actualFields = array_keys($productsResult);
    $missingFields = array_diff($expectedFields, $actualFields);
    $extraFields = array_diff($actualFields, $expectedFields);
    
    $testResults['tests']['response_format_check'] = [
        'status' => empty($missingFields) ? 'PASS' : 'FAIL',
        'message' => empty($missingFields) ? 'Response format matches mobile app expectations' : 'Missing fields: ' . implode(', ', $missingFields),
        'expected_fields' => $expectedFields,
        'actual_fields' => $actualFields,
        'missing_fields' => array_values($missingFields),
        'extra_fields' => array_values($extraFields)
    ];
    
    // Test 3: Check product object format
    if ($productsResult['success'] && isset($productsResult['products']) && count($productsResult['products']) > 0) {
        $sampleProduct = $productsResult['products'][0];
        $expectedProductFields = ['product_id', 'product_name', 'description', 'category', 'price', 'stock_quantity', 'product_sku', 'weight_value', 'weight_unit', 'image_url', 'status'];
        $actualProductFields = array_keys($sampleProduct);
        $missingProductFields = array_diff($expectedProductFields, $actualProductFields);
        
        $testResults['tests']['product_format_check'] = [
            'status' => empty($missingProductFields) ? 'PASS' : 'FAIL',
            'message' => empty($missingProductFields) ? 'Product format matches mobile app expectations' : 'Missing product fields: ' . implode(', ', $missingProductFields),
            'expected_product_fields' => $expectedProductFields,
            'actual_product_fields' => $actualProductFields,
            'missing_product_fields' => array_values($missingProductFields),
            'sample_product' => $sampleProduct
        ];
    }
    
    // Test 4: Check data types
    if ($productsResult['success'] && isset($productsResult['products']) && count($productsResult['products']) > 0) {
        $sampleProduct = $productsResult['products'][0];
        $typeIssues = [];
        
        // Check if product_id is numeric
        if (!is_numeric($sampleProduct['product_id'])) {
            $typeIssues[] = 'product_id is not numeric: ' . gettype($sampleProduct['product_id']);
        }
        
        // Check if price is numeric
        if (!is_numeric($sampleProduct['price'])) {
            $typeIssues[] = 'price is not numeric: ' . gettype($sampleProduct['price']);
        }
        
        // Check if stock_quantity is numeric
        if (!is_numeric($sampleProduct['stock_quantity'])) {
            $typeIssues[] = 'stock_quantity is not numeric: ' . gettype($sampleProduct['stock_quantity']);
        }
        
        $testResults['tests']['data_types_check'] = [
            'status' => empty($typeIssues) ? 'PASS' : 'WARNING',
            'message' => empty($typeIssues) ? 'Data types are correct' : 'Data type issues: ' . implode(', ', $typeIssues),
            'type_issues' => $typeIssues,
            'sample_data_types' => [
                'product_id' => gettype($sampleProduct['product_id']),
                'price' => gettype($sampleProduct['price']),
                'stock_quantity' => gettype($sampleProduct['stock_quantity']),
                'product_name' => gettype($sampleProduct['product_name'])
            ]
        ];
    }
    
    // Test 5: Check if mobile app can parse the response
    $testResults['tests']['mobile_compatibility'] = [
        'status' => 'INFO',
        'message' => 'Mobile app compatibility check',
        'api_response' => $productsResult,
        'products_count' => isset($productsResult['products']) ? count($productsResult['products']) : 0,
        'has_success_field' => isset($productsResult['success']),
        'has_products_field' => isset($productsResult['products']),
        'has_total_count_field' => isset($productsResult['total_count']),
        'success_value' => $productsResult['success'] ?? 'missing'
    ];
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    $warningCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
        if ($test['status'] === 'WARNING') $warningCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'warnings' => $warningCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'mobile_app_should_work' => $failCount === 0 ? 'YES' : 'NO',
        'recommendations' => $failCount > 0 ? [
            '1. Fix missing fields in API response',
            '2. Ensure data types match mobile app expectations',
            '3. Test mobile app with corrected API'
        ] : ['Mobile app should now load products successfully']
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'mobile_api_format',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
