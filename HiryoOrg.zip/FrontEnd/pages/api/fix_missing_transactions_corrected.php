<?php
// Fix missing transactions with corrected SQL query
header('Content-Type: text/plain');

echo "=== FIXING MISSING TRANSACTIONS (CORRECTED) ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // First, let's manually check what we have
    echo "=== MANUAL CHECK ===\n";
    
    // Get all completed/cancelled orders
    $completed_stmt = $conn->prepare("
        SELECT order_id, status, total_amount, order_date
        FROM orders 
        WHERE status IN ('Completed', 'Cancelled')
        ORDER BY order_id DESC
    ");
    $completed_stmt->execute();
    $completed_orders = $completed_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Completed/Cancelled orders in orders table:\n";
    foreach ($completed_orders as $order) {
        echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}\n";
    }
    
    // Get all transaction order_ids
    $trans_stmt = $conn->prepare("SELECT DISTINCT order_id FROM transactions ORDER BY order_id DESC");
    $trans_stmt->execute();
    $transaction_order_ids = $trans_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "\nOrders already in transactions table:\n";
    foreach ($transaction_order_ids as $order_id) {
        echo "   - Order #{$order_id}\n";
    }
    
    // Find missing ones manually
    echo "\n=== FINDING MISSING ORDERS MANUALLY ===\n";
    $missing_orders = [];
    foreach ($completed_orders as $order) {
        if (!in_array($order['order_id'], $transaction_order_ids)) {
            $missing_orders[] = $order;
        }
    }
    
    if (empty($missing_orders)) {
        echo "✅ No missing transactions found!\n";
        exit;
    }
    
    echo "❌ Found " . count($missing_orders) . " completed/cancelled orders NOT in transactions:\n";
    foreach ($missing_orders as $order) {
        echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}\n";
    }
    
    echo "\n=== TRANSFERRING MISSING ORDERS ===\n";
    
    foreach ($missing_orders as $order_data) {
        $order_id = $order_data['order_id'];
        echo "\nProcessing Order #{$order_id}...\n";
        
        // Get full order details
        $order_stmt = $conn->prepare("
            SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number, u.address
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.user_id
            WHERE o.order_id = ?
        ");
        $order_stmt->execute([$order_id]);
        $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo "   ❌ Order #{$order_id} not found!\n";
            continue;
        }
        
        // Get order items
        $items_stmt = $conn->prepare("
            SELECT oi.*, p.product_name
            FROM order_items oi
            LEFT JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = ?
        ");
        $items_stmt->execute([$order_id]);
        $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "   ✅ Found " . count($items) . " order items\n";
        
        // Insert into transactions table
        $trans_stmt = $conn->prepare("
            INSERT INTO transactions (
                order_id, user_id, customer_name, customer_email, customer_contact,
                delivery_method, payment_method, shipping_address, subtotal,
                delivery_fee, amount, created_at, items
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
        ");
        
        $customer_name = trim(($order['firstName'] ?? '') . ' ' . ($order['lastName'] ?? ''));
        $items_json = json_encode($items);
        
        $trans_result = $trans_stmt->execute([
            $order_id,
            $order['user_id'],
            $customer_name,
            $order['email'],
            $order['contact_number'],
            $order['delivery_method'],
            $order['payment_method'],
            $order['shipping_address'],
            $order['subtotal'],
            $order['delivery_fee'],
            $order['total_amount'],
            $items_json
        ]);
        
        if ($trans_result) {
            $transaction_id = $conn->lastInsertId();
            echo "   ✅ Order #{$order_id} transferred to transactions table (Transaction ID: {$transaction_id})\n";
            
            // Delete order items
            $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $delete_items_stmt->execute([$order_id]);
            echo "   ✅ Deleted order items for Order #{$order_id}\n";
            
            // Delete from orders table
            $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $delete_stmt->execute([$order_id]);
            echo "   ✅ Deleted Order #{$order_id} from orders table\n";
            
        } else {
            echo "   ❌ Failed to transfer Order #{$order_id} to transactions table\n";
        }
    }
    
    // Final verification
    echo "\n=== FINAL VERIFICATION ===\n";
    
    // Check orders table
    $final_orders_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE status IN ('Completed', 'Cancelled')");
    $final_orders_stmt->execute();
    $final_orders_count = $final_orders_stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check transactions table
    $final_trans_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $final_trans_stmt->execute();
    $final_trans_count = $final_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "Completed/Cancelled orders still in orders table: {$final_orders_count['count']}\n";
    echo "Total transactions in transactions table: {$final_trans_count['count']}\n";
    
    if ($final_orders_count['count'] == 0) {
        echo "🎉 SUCCESS: All completed/cancelled orders have been transferred!\n";
    } else {
        echo "❌ Still {$final_orders_count['count']} completed/cancelled orders in orders table\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
