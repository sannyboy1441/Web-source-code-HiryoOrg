<?php
/**
 * Specific .htaccess Verification Script
 */

header('Content-Type: application/json');

// Multiple paths to check for .htaccess
$paths = [
    'relative_from_api' => __DIR__ . '/../styles/.htaccess',
    'relative_from_root' => $_SERVER['DOCUMENT_ROOT'] . '/HiryoOrg/FrontEnd/styles/.htaccess',
    'absolute_path' => '/home/u987478351/domains/hiryoorganics.swuitapp.com/public_html/FrontEnd/styles/.htaccess'
];

$results = [];

foreach ($paths as $name => $path) {
    $results[$name] = [
        'path' => $path,
        'exists' => file_exists($path),
        'readable' => is_readable($path),
        'size' => file_exists($path) ? filesize($path) : 0,
        'modified' => file_exists($path) ? date('Y-m-d H:i:s', filemtime($path)) : 'N/A'
    ];
}

// Check if styles directory exists
$stylesDir = dirname($paths['relative_from_api']);
$results['styles_directory'] = [
    'path' => $stylesDir,
    'exists' => is_dir($stylesDir),
    'readable' => is_readable($stylesDir),
    'contents' => is_dir($stylesDir) ? array_values(array_diff(scandir($stylesDir), ['.', '..'])) : []
];

// Try to read .htaccess content if it exists
$htaccessContent = '';
foreach ($paths as $name => $path) {
    if (file_exists($path) && is_readable($path)) {
        $htaccessContent = file_get_contents($path);
        $results['content_found'] = true;
        $results['content_source'] = $name;
        break;
    }
}

$results['htaccess_content'] = $htaccessContent;
$results['content_length'] = strlen($htaccessContent);

echo json_encode([
    'htaccess_verification' => $results,
    'conclusion' => !empty($htaccessContent) ? 
        '✅ .htaccess file found and readable!' : 
        '❌ .htaccess file not found or not readable',
    'server_info' => [
        'document_root' => $_SERVER['DOCUMENT_ROOT'],
        'script_dir' => __DIR__,
        'current_time' => date('Y-m-d H:i:s')
    ]
], JSON_PRETTY_PRINT);
?>
