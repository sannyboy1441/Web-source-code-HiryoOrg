<?php
/**
 * Debug script for Order #26 specifically
 */

header('Content-Type: application/json');

require_once '../datab_try.php';

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $order_id = 26;
    
    echo "Debugging Order #26...\n\n";
    
    // Check order details
    $orderStmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $orderStmt->execute([$order_id]);
    $order = $orderStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order #26 not found in orders table']);
        exit;
    }
    
    echo "Order #26 Details:\n";
    echo json_encode($order, JSON_PRETTY_PRINT) . "\n\n";
    
    // Check if order exists in transactions table
    $transStmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $transStmt->execute([$order_id]);
    $transaction = $transStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($transaction) {
        echo "Order #26 already exists in transactions table:\n";
        echo json_encode($transaction, JSON_PRETTY_PRINT) . "\n\n";
    } else {
        echo "Order #26 not found in transactions table\n\n";
    }
    
    // Check order items
    $itemsStmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $itemsStmt->execute([$order_id]);
    $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Order #26 Items:\n";
    echo json_encode($items, JSON_PRETTY_PRINT) . "\n\n";
    
    // Test status update
    echo "Testing status update to 'Completed'...\n";
    
    try {
        $conn->beginTransaction();
        
        // Update status
        $updateStmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
        $updateResult = $updateStmt->execute(['Completed', $order_id]);
        
        if (!$updateResult) {
            throw new Exception('Failed to update order status');
        }
        
        echo "Status update successful\n";
        
        // Get updated order
        $orderStmt->execute([$order_id]);
        $updatedOrder = $orderStmt->fetch(PDO::FETCH_ASSOC);
        
        echo "Updated order status: " . $updatedOrder['status'] . "\n";
        
        // Check if we should transfer to transactions
        if (strtolower($updatedOrder['status']) === 'completed') {
            echo "Order should be transferred to transactions table...\n";
            
            // Check if already exists in transactions
            if (!$transaction) {
                echo "Transferring to transactions table...\n";
                
                // Insert into transactions
                $insertStmt = $conn->prepare("
                    INSERT INTO transactions (order_id, user_id, amount, payment_method, created_at, customer_name, customer_email, customer_contact, delivery_method, shipping_address, subtotal, delivery_fee, items) 
                    VALUES (?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $insertResult = $insertStmt->execute([
                    $updatedOrder['order_id'],
                    $updatedOrder['user_id'],
                    $updatedOrder['total_amount'],
                    $updatedOrder['payment_method'],
                    $updatedOrder['customer_name'] ?? 'Unknown Customer',
                    $updatedOrder['customer_email'] ?? 'unknown@email.com',
                    $updatedOrder['customer_contact'] ?? '',
                    $updatedOrder['delivery_method'],
                    $updatedOrder['shipping_address'],
                    $updatedOrder['subtotal'],
                    $updatedOrder['delivery_fee'],
                    json_encode($items)
                ]);
                
                if ($insertResult) {
                    echo "Successfully transferred to transactions table\n";
                    
                    // Delete from orders
                    $deleteStmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
                    $deleteStmt->execute([$order_id]);
                    echo "Deleted from orders table\n";
                    
                    // Delete order items
                    $deleteItemsStmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
                    $deleteItemsStmt->execute([$order_id]);
                    echo "Deleted order items\n";
                } else {
                    throw new Exception('Failed to insert into transactions table');
                }
            } else {
                echo "Order already exists in transactions table\n";
            }
        }
        
        $conn->commit();
        echo "Transaction committed successfully\n";
        
        echo json_encode(['success' => true, 'message' => 'Order #26 processed successfully']);
        
    } catch (Exception $e) {
        $conn->rollback();
        echo "Transaction rolled back: " . $e->getMessage() . "\n";
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
