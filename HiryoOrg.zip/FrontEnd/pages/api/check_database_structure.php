<?php
/**
 * Check Database Structure
 * This script checks the database structure for potential issues
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $results = [
        'timestamp' => date('Y-m-d H:i:s'),
        'checks' => []
    ];
    
    // Check 1: Orders table structure
    $stmt = $conn->query("DESCRIBE orders");
    $results['checks']['orders_table_structure'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 2: Users table structure
    $stmt = $conn->query("DESCRIBE users");
    $results['checks']['users_table_structure'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 3: Order items table structure
    $stmt = $conn->query("DESCRIBE order_items");
    $results['checks']['order_items_table_structure'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 4: Products table structure
    $stmt = $conn->query("DESCRIBE products");
    $results['checks']['products_table_structure'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 5: Sample data from orders
    $stmt = $conn->query("SELECT order_id, user_id, status FROM orders WHERE order_id IN (14, 15, 16) ORDER BY order_id");
    $results['checks']['sample_orders'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 6: Sample data from users
    $stmt = $conn->query("SELECT user_id, firstName, lastName, email FROM users WHERE user_id IN (SELECT DISTINCT user_id FROM orders WHERE order_id IN (14, 15, 16))");
    $results['checks']['sample_users'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 7: Sample data from order_items
    $stmt = $conn->query("SELECT order_id, product_id, quantity FROM order_items WHERE order_id IN (14, 15, 16) ORDER BY order_id");
    $results['checks']['sample_order_items'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 8: Check for any NULL user_ids in orders
    $stmt = $conn->query("SELECT order_id, user_id FROM orders WHERE user_id IS NULL");
    $results['checks']['null_user_ids'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 9: Check for any missing users
    $stmt = $conn->query("
        SELECT DISTINCT o.order_id, o.user_id 
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        WHERE u.user_id IS NULL AND o.order_id IN (14, 15, 16)
    ");
    $results['checks']['missing_users'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Check 10: Check for any missing products
    $stmt = $conn->query("
        SELECT DISTINCT oi.order_id, oi.product_id 
        FROM order_items oi 
        LEFT JOIN products p ON oi.product_id = p.product_id 
        WHERE p.product_id IS NULL AND oi.order_id IN (14, 15, 16)
    ");
    $results['checks']['missing_products'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($results, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
