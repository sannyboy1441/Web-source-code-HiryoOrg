<?php
// Fix Order #51 specifically
header('Content-Type: text/plain');

echo "=== FIXING ORDER #51 SPECIFICALLY ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check if Order #51 exists in orders table
    echo "=== CHECKING ORDER #51 IN ORDERS TABLE ===\n";
    $order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = 51");
    $order_stmt->execute();
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "❌ Order #51 not found in orders table!\n";
        exit;
    }
    
    echo "✅ Order #51 found in orders table:\n";
    echo "   - Status: {$order['status']}\n";
    echo "   - Total: {$order['total_amount']}\n";
    echo "   - User ID: {$order['user_id']}\n";
    echo "   - Date: {$order['order_date']}\n\n";
    
    // Get order details with user info
    $order_details_stmt = $conn->prepare("
        SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_id = 51
    ");
    $order_details_stmt->execute();
    $order_details = $order_details_stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get order items
    $items_stmt = $conn->prepare("
        SELECT oi.*, p.product_name 
        FROM order_items oi 
        LEFT JOIN products p ON oi.product_id = p.product_id 
        WHERE oi.order_id = 51
    ");
    $items_stmt->execute();
    $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Order items found: " . count($items) . " items\n";
    foreach ($items as $item) {
        echo "   - {$item['product_name']}: {$item['quantity']} x {$item['price_at_purchase']}\n";
    }
    echo "\n";
    
    // Transfer to transactions table
    echo "=== TRANSFERRING ORDER #51 TO TRANSACTIONS TABLE ===\n";
    
    // Create transactions table if it doesn't exist
    $create_table_sql = "
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            user_id INT NOT NULL,
            customer_name VARCHAR(255),
            customer_email VARCHAR(255),
            customer_contact VARCHAR(20),
            delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            shipping_address TEXT,
            subtotal DECIMAL(10,2) NOT NULL,
            delivery_fee DECIMAL(10,2) NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            created_at DATETIME NOT NULL,
            items JSON,
            INDEX idx_user_id (user_id),
            INDEX idx_created_at (created_at)
        )
    ";
    $conn->exec($create_table_sql);
    echo "✅ Transactions table created/verified\n";
    
    // Insert into transactions table
    $trans_stmt = $conn->prepare("
        INSERT INTO transactions (
            order_id, user_id, customer_name, customer_email, customer_contact,
            delivery_method, payment_method, shipping_address, subtotal, 
            delivery_fee, amount, created_at, items
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
    ");
    
    $customer_name = trim(($order_details['firstName'] ?? '') . ' ' . ($order_details['lastName'] ?? ''));
    $items_json = json_encode($items);
    
    echo "Inserting with customer name: '$customer_name'\n";
    
    $trans_result = $trans_stmt->execute([
        51, // order_id
        $order_details['user_id'],
        $customer_name,
        $order_details['email'],
        $order_details['contact_number'],
        $order_details['delivery_method'],
        $order_details['payment_method'],
        $order_details['shipping_address'],
        $order_details['subtotal'],
        $order_details['delivery_fee'],
        $order_details['total_amount'],
        $items_json
    ]);
    
    if (!$trans_result) {
        $errorInfo = $trans_stmt->errorInfo();
        echo "❌ Failed to insert into transactions table: " . json_encode($errorInfo) . "\n";
        exit;
    }
    
    echo "✅ Successfully inserted Order #51 into transactions table\n";
    
    // Delete order items
    $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = 51");
    $delete_items_stmt->execute();
    echo "✅ Deleted order items for Order #51\n";
    
    // Delete from orders table
    $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = 51");
    $delete_stmt->execute();
    echo "✅ Deleted Order #51 from orders table\n";
    
    // Verify the transfer
    echo "\n=== VERIFYING TRANSFER ===\n";
    
    $verify_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = 51");
    $verify_trans_stmt->execute();
    $verify_trans = $verify_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($verify_trans) {
        echo "✅ Order #51 successfully transferred to transactions table:\n";
        echo "   - Transaction ID: {$verify_trans['transaction_id']}\n";
        echo "   - Customer: {$verify_trans['customer_name']}\n";
        echo "   - Amount: {$verify_trans['amount']}\n";
        echo "   - Date: {$verify_trans['created_at']}\n";
    } else {
        echo "❌ Order #51 NOT found in transactions table after transfer!\n";
    }
    
    $verify_order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = 51");
    $verify_order_stmt->execute();
    $verify_order = $verify_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($verify_order) {
        echo "❌ Order #51 still exists in orders table!\n";
    } else {
        echo "✅ Order #51 successfully removed from orders table\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if ($verify_trans && !$verify_order) {
        echo "🎉 SUCCESS: Order #51 has been transferred to transactions table!\n";
        echo "✅ The order completion process is now working!\n";
    } else {
        echo "❌ FAILURE: Order #51 transfer did not complete successfully\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
