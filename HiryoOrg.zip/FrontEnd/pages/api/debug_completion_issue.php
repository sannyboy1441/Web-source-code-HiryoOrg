<?php
// Debug why completed orders are not appearing in transactions
header('Content-Type: text/plain');

echo "=== DEBUGGING ORDER COMPLETION ISSUE ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check recent orders
    echo "=== RECENT ORDERS (Last 10) ===\n";
    $recent_stmt = $conn->prepare("SELECT order_id, status, total_amount, order_date FROM orders ORDER BY order_id DESC LIMIT 10");
    $recent_stmt->execute();
    $recent_orders = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($recent_orders as $order) {
        echo "Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}, Date: {$order['order_date']}\n";
    }
    
    // Check transactions count
    echo "\n=== TRANSACTIONS TABLE ===\n";
    $trans_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $trans_stmt->execute();
    $trans_count = $trans_stmt->fetch(PDO::FETCH_ASSOC);
    echo "Total transactions: {$trans_count['count']}\n";
    
    // Show recent transactions
    $recent_trans_stmt = $conn->prepare("SELECT transaction_id, order_id, customer_name, amount, created_at FROM transactions ORDER BY transaction_id DESC LIMIT 5");
    $recent_trans_stmt->execute();
    $recent_trans = $recent_trans_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "\nRecent transactions:\n";
    foreach ($recent_trans as $trans) {
        echo "Transaction #{$trans['transaction_id']}: Order #{$trans['order_id']}, Customer: {$trans['customer_name']}, Amount: {$trans['amount']}, Date: {$trans['created_at']}\n";
    }
    
    // Check for completed orders that should be in transactions
    echo "\n=== COMPLETED ORDERS NOT IN TRANSACTIONS ===\n";
    $missing_stmt = $conn->prepare("
        SELECT o.order_id, o.status, o.total_amount, o.order_date
        FROM orders o
        LEFT JOIN transactions t ON o.order_id = t.order_id
        WHERE o.status IN ('Completed', 'Cancelled') AND t.order_id IS NULL
        ORDER BY o.order_id DESC
    ");
    $missing_stmt->execute();
    $missing_orders = $missing_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($missing_orders)) {
        echo "✅ No completed orders missing from transactions table\n";
    } else {
        echo "❌ Found " . count($missing_orders) . " completed orders not in transactions:\n";
        foreach ($missing_orders as $order) {
            echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}, Date: {$order['order_date']}\n";
        }
    }
    
    // Also check manually by comparing the lists
    echo "\n=== MANUAL VERIFICATION ===\n";
    echo "Completed/Cancelled orders from orders table:\n";
    foreach ($recent_orders as $order) {
        if (in_array($order['status'], ['Completed', 'Cancelled'])) {
            echo "   - Order #{$order['order_id']}: {$order['status']}\n";
        }
    }
    
    echo "\nOrders in transactions table:\n";
    foreach ($recent_trans as $trans) {
        echo "   - Order #{$trans['order_id']} (Transaction #{$trans['transaction_id']})\n";
    }
    
    // Test API endpoint directly
    echo "\n=== TESTING API ENDPOINT ===\n";
    
    // Check if orders_api_fixed_v2.php exists and is accessible
    $api_file = 'orders_api_fixed_v2.php';
    if (file_exists($api_file)) {
        echo "✅ API file exists: $api_file\n";
        
        // Test with a simple GET request
        $test_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . "/$api_file?action=get_all_orders_for_admin";
        echo "Test URL: $test_url\n";
        
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 10
            ]
        ]);
        
        $response = @file_get_contents($test_url, false, $context);
        if ($response !== false) {
            echo "✅ API responds to GET requests\n";
            $data = json_decode($response, true);
            if ($data && isset($data['success'])) {
                echo "✅ API returns valid JSON response\n";
            } else {
                echo "❌ API returns invalid JSON response\n";
            }
        } else {
            echo "❌ API does not respond to GET requests\n";
        }
        
    } else {
        echo "❌ API file does not exist: $api_file\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    echo "Orders in orders table: " . count($recent_orders) . "\n";
    echo "Transactions in transactions table: {$trans_count['count']}\n";
    echo "Completed orders missing from transactions: " . count($missing_orders) . "\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
