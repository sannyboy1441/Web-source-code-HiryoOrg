<?php
/**
 * Test Action Debug
 * This script debugs the action parameter issue
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'debug_info' => []
    ];
    
    // Test 1: Check if orders_api.php file exists and is readable
    $ordersApiPath = __DIR__ . '/orders_api.php';
    $testResults['debug_info']['file_check'] = [
        'file_exists' => file_exists($ordersApiPath),
        'file_readable' => file_exists($ordersApiPath) ? is_readable($ordersApiPath) : false,
        'file_path' => $ordersApiPath
    ];
    
    // Test 2: Check the first few lines of orders_api.php to see the action handling
    if (file_exists($ordersApiPath)) {
        $fileContent = file_get_contents($ordersApiPath);
        $lines = explode("\n", $fileContent);
        
        // Look for action handling code
        $actionHandlingLines = [];
        foreach ($lines as $lineNum => $line) {
            if (strpos($line, 'action') !== false || strpos($line, 'switch') !== false || strpos($line, 'case') !== false) {
                $actionHandlingLines[] = [
                    'line' => $lineNum + 1,
                    'content' => trim($line)
                ];
            }
        }
        
        $testResults['debug_info']['action_handling_code'] = array_slice($actionHandlingLines, 0, 20); // First 20 matches
    }
    
    // Test 3: Test direct GET request to orders_api.php
    $testUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/orders_api.php?action=test';
    
    $response = @file_get_contents($testUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 10
        ]
    ]));
    
    $testResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response'];
    
    $testResults['debug_info']['get_test_action'] = [
        'url' => $testUrl,
        'response' => $testResult,
        'status' => $testResult['success'] ? 'WORKING' : 'FAILED'
    ];
    
    // Test 4: Test POST request with place_order action
    $postUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/orders_api.php';
    $postData = http_build_query(['action' => 'place_order']);
    
    $postResponse = @file_get_contents($postUrl, false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 10
        ]
    ]));
    
    $postResult = $postResponse ? json_decode($postResponse, true) : ['success' => false, 'message' => 'No response'];
    
    $testResults['debug_info']['post_place_order_action'] = [
        'url' => $postUrl,
        'post_data' => $postData,
        'response' => $postResult,
        'status' => strpos($postResult['message'] ?? '', 'Invalid action') === false ? 'WORKING' : 'INVALID_ACTION'
    ];
    
    // Test 5: Check what actions are actually supported
    if (file_exists($ordersApiPath)) {
        $fileContent = file_get_contents($ordersApiPath);
        preg_match_all("/case\s+['\"]([^'\"]+)['\"]/", $fileContent, $matches);
        $supportedActions = $matches[1] ?? [];
        
        $testResults['debug_info']['supported_actions'] = $supportedActions;
    }
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
