<?php
/**
 * Test Dashboard Database Connection
 * This script tests if the dashboard API can connect to the database
 */

header('Content-Type: application/json');

try {
    // Include database connection
    require_once '../datab_try.php';
    
    // Test both connections
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: MySQLi connection (original)
    $testResults['tests']['mysqli_connection'] = [
        'status' => isset($conn) && $conn ? 'PASS' : 'FAIL',
        'message' => isset($conn) && $conn ? 'MySQLi connection successful' : 'MySQLi connection failed',
        'connection_type' => 'MySQLi'
    ];
    
    // Test 2: PDO connection (for APIs)
    $pdoConn = getDBConnection();
    $testResults['tests']['pdo_connection'] = [
        'status' => $pdoConn ? 'PASS' : 'FAIL',
        'message' => $pdoConn ? 'PDO connection successful' : 'PDO connection failed',
        'connection_type' => 'PDO'
    ];
    
    // Test 3: Test a simple query with PDO
    if ($pdoConn) {
        try {
            $stmt = $pdoConn->prepare("SELECT COUNT(*) as count FROM users");
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $testResults['tests']['pdo_query_test'] = [
                'status' => 'PASS',
                'message' => 'PDO query executed successfully',
                'user_count' => $result['count']
            ];
        } catch (Exception $e) {
            $testResults['tests']['pdo_query_test'] = [
                'status' => 'FAIL',
                'message' => 'PDO query failed: ' . $e->getMessage()
            ];
        }
    }
    
    // Test 4: Test dashboard API specifically
    $dashboardUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/dashboard_api.php?action=get_dashboard_stats';
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 5
        ]
    ]);
    
    $response = @file_get_contents($dashboardUrl, false, $context);
    
    if ($response === false) {
        $testResults['tests']['dashboard_api'] = [
            'status' => 'FAIL',
            'message' => 'Dashboard API request failed',
            'url' => $dashboardUrl
        ];
    } else {
        $data = json_decode($response, true);
        $testResults['tests']['dashboard_api'] = [
            'status' => $data && isset($data['success']) && $data['success'] ? 'PASS' : 'FAIL',
            'message' => $data && isset($data['success']) && $data['success'] ? 'Dashboard API working' : 'Dashboard API error: ' . ($data['message'] ?? 'Unknown error'),
            'url' => $dashboardUrl,
            'response' => $data
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'database_connection_working' => $passCount > 0,
        'dashboard_api_working' => isset($testResults['tests']['dashboard_api']) && $testResults['tests']['dashboard_api']['status'] === 'PASS'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'dashboard_connection',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
