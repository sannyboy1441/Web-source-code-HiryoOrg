<?php
/**
 * Upload Verification Script
 * Check if all API fixes are properly uploaded to Hostinger
 */

header('Content-Type: application/json');

$checks = [
    'users_api_updated' => false,
    'notifications_api_updated' => false,
    'user_admin_api_exists' => false,
    'transactions_legacy_api_exists' => false,
    'dashboard_api_exists' => false,
    'htaccess_exists' => false
];

// Check if users_api.php has the legacy action support
if (file_exists(__DIR__ . '/users_api.php')) {
    $content = file_get_contents(__DIR__ . '/users_api.php');
    $checks['users_api_updated'] = strpos($content, 'get_users_for_admin') !== false;
}

// Check if notifications_api.php has the legacy action support
if (file_exists(__DIR__ . '/notifications_api.php')) {
    $content = file_get_contents(__DIR__ . '/notifications_api.php');
    $checks['notifications_api_updated'] = strpos($content, 'get_notifications_for_admin') !== false;
}

// Check if new API files exist
$checks['user_admin_api_exists'] = file_exists(__DIR__ . '/user_admin_api.php');
$checks['transactions_legacy_api_exists'] = file_exists(__DIR__ . '/transactions_api_actions_for_admin.php');
$checks['dashboard_api_exists'] = file_exists(__DIR__ . '/dashboard_api.php');

// Check if .htaccess exists in styles folder
$htaccessPath = __DIR__ . '/../styles/.htaccess';
$checks['htaccess_exists'] = file_exists($htaccessPath);

// Additional debug info for .htaccess
if (!$checks['htaccess_exists']) {
    $checks['htaccess_debug'] = [
        'path_checked' => $htaccessPath,
        'parent_dir_exists' => is_dir(__DIR__ . '/../styles/'),
        'parent_dir_contents' => is_dir(__DIR__ . '/../styles/') ? scandir(__DIR__ . '/../styles/') : 'Parent dir not found',
        'absolute_path' => realpath($htaccessPath) ?: 'File not found'
    ];
}

// Count successful checks
$successCount = array_sum($checks);
$totalChecks = count($checks);

echo json_encode([
    'upload_status' => $successCount . '/' . $totalChecks . ' files uploaded correctly',
    'all_uploaded' => $successCount === $totalChecks,
    'checks' => $checks,
    'server_info' => [
        'php_version' => PHP_VERSION,
        'server_time' => date('Y-m-d H:i:s'),
        'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown',
        'script_path' => __DIR__
    ],
    'next_steps' => $successCount === $totalChecks ? 
        'All files uploaded! Clear browser cache and reload the page.' : 
        'Upload missing files to Hostinger as shown in the checklist.'
], JSON_PRETTY_PRINT);
?>
