<?php
/**
 * Direct test of transactions API functionality
 */

header('Content-Type: application/json');

try {
    // Include database connection
    @include_once '../datab_try.php';
    
    if (!function_exists('getDBConnection')) {
        throw new Exception('getDBConnection function not found');
    }
    
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Test the exact query from handleGetAllTransactions
    $query = "
        SELECT 
            t.transaction_id, t.user_id, t.order_id, t.amount, t.payment_method, t.created_at,
            u.username as user_name, u.email as user_email, o.status as order_status
            FROM transactions t
            LEFT JOIN users u ON t.user_id = u.user_id
            LEFT JOIN orders o ON t.order_id = o.order_id
            ORDER BY t.created_at DESC
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'message' => 'Direct transactions test successful',
        'transaction_count' => count($transactions),
        'sample_transactions' => array_slice($transactions, 0, 3), // First 3 transactions
        'all_transactions' => $transactions
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Direct transactions test failed: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]
    ]);
}
?>
