<?php
// Restore transactions from the known order data
header('Content-Type: text/plain');

echo "=== RESTORING TRANSACTIONS ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Define the orders we know existed (from our previous verification)
    $known_orders = [
        ['order_id' => 24, 'status' => 'Completed', 'amount' => 395.00, 'date' => '2025-10-18 19:53:33'],
        ['order_id' => 17, 'status' => 'Cancelled', 'amount' => 238.00, 'date' => '2025-10-17 17:41:18'],
        ['order_id' => 15, 'status' => 'Completed', 'amount' => 220.00, 'date' => '2025-10-17 01:45:16'],
        ['order_id' => 14, 'status' => 'Completed', 'amount' => 231.00, 'date' => '2025-10-17 01:42:57'],
        ['order_id' => 13, 'status' => 'Completed', 'amount' => 220.00, 'date' => '2025-10-17 00:53:11'],
        ['order_id' => 12, 'status' => 'Completed', 'amount' => 335.00, 'date' => '2025-10-12 12:01:17'],
        ['order_id' => 11, 'status' => 'Completed', 'amount' => 280.00, 'date' => '2025-10-12 11:47:26'],
        ['order_id' => 10, 'status' => 'Completed', 'amount' => 167.94, 'date' => '2025-10-12 11:39:43'],
        ['order_id' => 9, 'status' => 'Cancelled', 'amount' => 488.00, 'date' => '2025-10-12 11:07:02']
    ];
    
    echo "=== RESTORING " . count($known_orders) . " TRANSACTIONS ===\n\n";
    
    foreach ($known_orders as $order_data) {
        $order_id = $order_data['order_id'];
        $status = $order_data['status'];
        $amount = $order_data['amount'];
        $order_date = $order_data['date'];
        
        echo "Restoring Order #{$order_id}...\n";
        
        // Create a transaction record
        $trans_stmt = $conn->prepare("
            INSERT INTO transactions (
                order_id, user_id, customer_name, customer_email, customer_contact,
                delivery_method, payment_method, shipping_address, subtotal,
                delivery_fee, amount, created_at, items
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        // Use default values for missing data
        $result = $trans_stmt->execute([
            $order_id,           // order_id
            1,                   // user_id (default)
            'Restored Customer', // customer_name
            'restored@example.com', // customer_email
            '000-000-0000',      // customer_contact
            'Delivery',          // delivery_method
            'Cash',              // payment_method
            'Restored Address',  // shipping_address
            $amount,             // subtotal
            0,                   // delivery_fee
            $amount,             // amount
            $order_date,         // created_at
            '[]'                 // items (empty array)
        ]);
        
        if ($result) {
            $transaction_id = $conn->lastInsertId();
            echo "   ✅ Restored as Transaction #{$transaction_id}\n";
        } else {
            echo "   ❌ Failed to restore Order #{$order_id}\n";
        }
    }
    
    // Verify restoration
    echo "\n=== VERIFICATION ===\n";
    $verify_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $verify_stmt->execute();
    $verify_count = $verify_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "Total transactions in transactions table: {$verify_count['count']}\n";
    
    if ($verify_count['count'] > 0) {
        echo "\nRecent transactions:\n";
        $recent_stmt = $conn->prepare("SELECT transaction_id, order_id, amount FROM transactions ORDER BY transaction_id DESC LIMIT 5");
        $recent_stmt->execute();
        $recent_trans = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($recent_trans as $trans) {
            echo "   - Transaction #{$trans['transaction_id']}: Order #{$trans['order_id']}, Amount: {$trans['amount']}\n";
        }
        
        echo "\n🎉 SUCCESS: Transactions have been restored!\n";
        echo "✅ " . $verify_count['count'] . " transactions restored\n";
        echo "✅ Web admin transactions page should now display data\n";
    } else {
        echo "\n❌ FAILURE: No transactions were restored\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
