<?php
/**
 * Orders API V4 - Fixed transfer logic with proper error handling
 */

// Prevent multiple executions
if (defined('ORDERS_API_V4_EXECUTED')) {
    exit();
}
define('ORDERS_API_V4_EXECUTED', true);

// Set headers first
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include database connection
$db_path = '../datab_try.php';
if (!@include_once $db_path) {
    echo json_encode(['success' => false, 'message' => 'Database connection file not found']);
    exit;
}

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    // Get action
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    
    // Debug logging
    error_log("API Call - Action: $action, POST: " . json_encode($_POST));
    
    switch ($action) {
        case 'get_order_details':
            handleGetOrderDetails($conn);
            break;
            
        case 'update_order_status':
            handleUpdateOrderStatus($conn);
            break;
            
        case 'get_all_orders_for_admin':
            handleGetAllOrdersForAdmin($conn);
            break;
            
        case 'place_order':
            handlePlaceOrder($conn);
            break;
            
        case 'get_user_orders':
            handleGetUserOrders($conn);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action specified']);
            break;
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error occurred: ' . $e->getMessage(), 'error_details' => [
        'file' => __FILE__,
        'line' => $e->getLine(),
        'message' => $e->getMessage()
    ]]);
}

function handleUpdateOrderStatus($conn) {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    
    error_log("handleUpdateOrderStatus called - Order ID: $order_id, Status: $status");
    
    if ($order_id <= 0 || empty($status)) {
        error_log("Invalid parameters - Order ID: $order_id, Status: '$status'");
        echo json_encode(['success' => false, 'message' => 'Valid order ID and status are required']);
        return;
    }
    
    try {
        // If status is 'completed' or 'cancelled', transfer to transactions table FIRST
        if (strtolower($status) === 'completed' || strtolower($status) === 'cancelled') {
            error_log("Processing completed/cancelled order #$order_id");
            
            // Check if order already exists in transactions table
            $check_trans_stmt = $conn->prepare("SELECT transaction_id FROM transactions WHERE order_id = ?");
            $check_trans_stmt->execute([$order_id]);
            $existing_transaction = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing_transaction) {
                error_log("Order #$order_id already exists in transactions table with ID: {$existing_transaction['transaction_id']}");
                // Just delete from orders table since it's already transferred
                $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
                $delete_result = $delete_stmt->execute([$order_id]);
                
                if ($delete_result) {
                    error_log("Successfully deleted already-transferred order #$order_id from orders table");
                }
                
                echo json_encode(['success' => true, 'message' => 'Order status updated successfully']);
                return;
            }
            
            // Get order details
            $order_stmt = $conn->prepare("
                SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number
                FROM orders o 
                LEFT JOIN users u ON o.user_id = u.user_id 
                WHERE o.order_id = ?
            ");
            $order_stmt->execute([$order_id]);
            $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                error_log("Order #$order_id not found");
                throw new Exception("Order not found");
            }
            
            error_log("Order found: ID={$order['order_id']}, User={$order['user_id']}, Total={$order['total_amount']}");
            
            // Get order items
            $items_stmt = $conn->prepare("
                SELECT oi.*, p.product_name 
                FROM order_items oi 
                LEFT JOIN products p ON oi.product_id = p.product_id 
                WHERE oi.order_id = ?
            ");
            $items_stmt->execute([$order_id]);
            $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            error_log("Order items found: " . count($items) . " items");
            
            // Create transactions table if it doesn't exist
            $create_table_sql = "
                CREATE TABLE IF NOT EXISTS transactions (
                    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
                    order_id INT NOT NULL,
                    user_id INT NOT NULL,
                    customer_name VARCHAR(255),
                    customer_email VARCHAR(255),
                    customer_contact VARCHAR(20),
                    delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
                    payment_method VARCHAR(50) NOT NULL,
                    shipping_address TEXT,
                    subtotal DECIMAL(10,2) NOT NULL,
                    delivery_fee DECIMAL(10,2) NOT NULL,
                    amount DECIMAL(10,2) NOT NULL,
                    created_at DATETIME NOT NULL,
                    items JSON,
                    INDEX idx_user_id (user_id),
                    INDEX idx_created_at (created_at)
                )
            ";
            $conn->exec($create_table_sql);
            error_log("Transactions table created/verified");
            
            // Insert into transactions table
            $trans_stmt = $conn->prepare("
                INSERT INTO transactions (
                    order_id, user_id, customer_name, customer_email, customer_contact,
                    delivery_method, payment_method, shipping_address, subtotal, 
                    delivery_fee, amount, created_at, items
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
            ");
            
            $customer_name = trim($order['firstName'] . ' ' . $order['lastName']);
            $items_json = json_encode($items);
            
            error_log("Inserting into transactions - Customer: $customer_name");
            
            $trans_result = $trans_stmt->execute([
                $order_id,
                $order['user_id'],
                $customer_name,
                $order['email'],
                $order['contact_number'],
                $order['delivery_method'],
                $order['payment_method'],
                $order['shipping_address'],
                $order['subtotal'],
                $order['delivery_fee'],
                $order['total_amount'],
                $items_json
            ]);
            
            if (!$trans_result) {
                $errorInfo = $trans_stmt->errorInfo();
                error_log("Transaction insert failed: " . json_encode($errorInfo));
                throw new Exception("Failed to transfer order to transactions table: " . json_encode($errorInfo));
            }
            
            error_log("Successfully inserted order #$order_id into transactions table");
            
            // Verify the transaction was inserted
            $verify_stmt = $conn->prepare("SELECT transaction_id FROM transactions WHERE order_id = ?");
            $verify_stmt->execute([$order_id]);
            $verify_transaction = $verify_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$verify_transaction) {
                error_log("CRITICAL: Transaction was not found after insert!");
                throw new Exception("Transaction was not created successfully");
            }
            
            error_log("Verified transaction created with ID: {$verify_transaction['transaction_id']}");
            
            // Now delete the order from orders table after successful transfer
            error_log("Deleting order #$order_id from orders table");
            
            // Delete order items first
            $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $delete_items_result = $delete_items_stmt->execute([$order_id]);
            
            if ($delete_items_result) {
                error_log("Successfully deleted order items for order #$order_id");
            } else {
                error_log("Failed to delete order items for order #$order_id");
            }
            
            // Delete from orders table
            $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $delete_result = $delete_stmt->execute([$order_id]);
            
            if ($delete_result) {
                error_log("Successfully deleted order #$order_id from orders table");
            } else {
                error_log("Failed to delete order #$order_id from orders table");
            }
            
            // Final verification - check if transaction still exists
            $final_check_stmt = $conn->prepare("SELECT transaction_id FROM transactions WHERE order_id = ?");
            $final_check_stmt->execute([$order_id]);
            $final_transaction = $final_check_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$final_transaction) {
                error_log("CRITICAL: Transaction disappeared after deleting order!");
                throw new Exception("Transaction was lost during deletion process");
            }
            
            error_log("Final verification: Transaction still exists with ID: {$final_transaction['transaction_id']}");
            
        } else {
            // If status is not 'completed' or 'cancelled', just update the status
            error_log("Updating order #$order_id status to: $status");
            
            $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
            $result = $stmt->execute([$status, $order_id]);
            
            if (!$result) {
                throw new Exception('Failed to update order status');
            }
            
            error_log("Successfully updated order #$order_id status to: $status");
        }
        
        echo json_encode(['success' => true, 'message' => 'Order status updated successfully']);
        
    } catch (Exception $e) {
        error_log("Error in handleUpdateOrderStatus: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Server error occurred: ' . $e->getMessage(), 'error_details' => [
            'file' => __FILE__,
            'line' => $e->getLine(),
            'message' => $e->getMessage()
        ]]);
    }
}

function handleGetOrderDetails($conn) {
    $order_id = (int)($_GET['order_id'] ?? 0);
    
    if ($order_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid order ID is required']);
        return;
    }
    
    try {
        $stmt = $conn->prepare("
            SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number as contact_number
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.user_id 
            WHERE o.order_id = ?
        ");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo json_encode(['success' => false, 'message' => 'Order not found']);
            return;
        }
        
        // Get order items
        $items_stmt = $conn->prepare("
            SELECT oi.*, p.product_name, p.product_image
            FROM order_items oi 
            LEFT JOIN products p ON oi.product_id = p.product_id 
            WHERE oi.order_id = ?
        ");
        $items_stmt->execute([$order_id]);
        $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $order['items'] = $items;
        
        echo json_encode(['success' => true, 'data' => $order]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to get order details: ' . $e->getMessage()]);
    }
}

function handleGetAllOrdersForAdmin($conn) {
    try {
        $stmt = $conn->prepare("
            SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.user_id 
            WHERE o.status NOT IN ('Completed', 'Cancelled')
            ORDER BY o.order_id DESC
        ");
        $stmt->execute();
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Post-process to ensure we have customer names
        foreach ($orders as &$order) {
            $firstName = $order['firstName'] ?? '';
            $lastName = $order['lastName'] ?? '';
            
            if (!empty($firstName) && !empty($lastName)) {
                $order['customer_name'] = $firstName . ' ' . $lastName;
            } elseif (!empty($firstName)) {
                $order['customer_name'] = $firstName;
            } else {
                $order['customer_name'] = 'Unknown Customer';
            }
        }
        
        echo json_encode(['success' => true, 'data' => $orders]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to get orders: ' . $e->getMessage()]);
    }
}

function handlePlaceOrder($conn) {
    $user_id = (int)($_POST['user_id'] ?? 0);
    $items_json = $_POST['items'] ?? '';
    $delivery_method = $_POST['delivery_method'] ?? 'Delivery';
    $payment_method = $_POST['payment_method'] ?? 'COD';
    $shipping_address = $_POST['shipping_address'] ?? '';
    $subtotal = (float)($_POST['subtotal'] ?? 0);
    $delivery_fee = (float)($_POST['delivery_fee'] ?? 0);
    $total_amount = (float)($_POST['total_amount'] ?? 0);
    
    if ($user_id <= 0 || empty($items_json) || $total_amount <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid user ID, items, and total amount are required']);
        return;
    }
    
    try {
        $conn->beginTransaction();
        
        // Insert order
        $stmt = $conn->prepare("
            INSERT INTO orders (user_id, status, delivery_method, payment_method, shipping_address, subtotal, delivery_fee, total_amount, order_date) 
            VALUES (?, 'Pending', ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$user_id, $delivery_method, $payment_method, $shipping_address, $subtotal, $delivery_fee, $total_amount]);
        $order_id = $conn->lastInsertId();
        
        // Parse and insert order items
        $items = json_decode($items_json, true);
        if (!is_array($items)) {
            throw new Exception('Invalid items format');
        }
        
        foreach ($items as $item) {
            $product_id = $item['product_id'] ?? $item['id'] ?? 0;
            $quantity = (int)($item['quantity'] ?? 1);
            $price = (float)($item['price'] ?? 0);
            
            $item_stmt = $conn->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) 
                VALUES (?, ?, ?, ?)
            ");
            $item_stmt->execute([$order_id, $product_id, $quantity, $price]);
        }
        
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Order placed successfully', 'order_id' => $order_id]);
        
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to place order: ' . $e->getMessage()]);
    }
}

function handleGetUserOrders($conn) {
    $user_id = (int)($_GET['user_id'] ?? 0);
    
    if ($user_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid user ID is required']);
        return;
    }
    
    try {
        $stmt = $conn->prepare("
            SELECT o.*, u.firstName, u.lastName
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.user_id 
            WHERE o.user_id = ? AND o.status NOT IN ('Completed', 'Cancelled')
            ORDER BY o.order_id DESC
        ");
        $stmt->execute([$user_id]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'data' => $orders]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to get user orders: ' . $e->getMessage()]);
    }
}
?>
