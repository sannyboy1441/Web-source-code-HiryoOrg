<?php
/**
 * Final Transactions API Test
 * Test all transaction-related endpoints
 */

header('Content-Type: application/json');

$tests = [];

// Test 1: Check if legacy API file exists
$tests['legacy_api_exists'] = file_exists(__DIR__ . '/transactions_api_actions_for_admin.php');

// Test 2: Check if main API file exists
$tests['main_api_exists'] = file_exists(__DIR__ . '/transactions_api.php');

// Test 3: Test the legacy API directly
if ($tests['legacy_api_exists']) {
    try {
        // Simulate the API call
        $_GET['action'] = 'get_all_transactions';
        ob_start();
        include __DIR__ . '/transactions_api_actions_for_admin.php';
        $output = ob_get_clean();
        
        $tests['legacy_api_response'] = [
            'success' => true,
            'output_length' => strlen($output),
            'is_json' => json_decode($output) !== null,
            'preview' => substr($output, 0, 100) . '...'
        ];
    } catch (Exception $e) {
        $tests['legacy_api_response'] = [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
} else {
    $tests['legacy_api_response'] = [
        'success' => false,
        'error' => 'Legacy API file not found'
    ];
}

// Test 4: Test main API
if ($tests['main_api_exists']) {
    try {
        $_GET['action'] = 'get_all_transactions';
        ob_start();
        include __DIR__ . '/transactions_api.php';
        $output = ob_get_clean();
        
        $tests['main_api_response'] = [
            'success' => true,
            'output_length' => strlen($output),
            'is_json' => json_decode($output) !== null,
            'preview' => substr($output, 0, 100) . '...'
        ];
    } catch (Exception $e) {
        $tests['main_api_response'] = [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
} else {
    $tests['main_api_response'] = [
        'success' => false,
        'error' => 'Main API file not found'
    ];
}

// Test 5: Database connection test
try {
    @include_once '../datab_try.php';
    if (function_exists('getDBConnection')) {
        $conn = getDBConnection();
        if ($conn) {
            $stmt = $conn->query("SELECT COUNT(*) as count FROM transactions");
            $result = $stmt->fetch();
            $tests['database_connection'] = [
                'success' => true,
                'transaction_count' => $result['count']
            ];
        } else {
            $tests['database_connection'] = [
                'success' => false,
                'error' => 'Database connection failed'
            ];
        }
    } else {
        $tests['database_connection'] = [
            'success' => false,
            'error' => 'getDBConnection function not found'
        ];
    }
} catch (Exception $e) {
    $tests['database_connection'] = [
        'success' => false,
        'error' => $e->getMessage()
    ];
}

echo json_encode([
    'transactions_api_test' => $tests,
    'conclusion' => $tests['legacy_api_exists'] && $tests['main_api_exists'] ? 
        '✅ Both API files exist - Issue may be browser cache' : 
        '❌ Missing API files - Need to upload',
    'recommendations' => [
        'Clear browser cache completely',
        'Test API endpoints directly',
        'Check if files are uploaded to correct location'
    ]
], JSON_PRETTY_PRINT);
?>
