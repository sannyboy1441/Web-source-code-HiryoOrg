<?php
// Check what the web admin is actually calling
header('Content-Type: text/plain');

echo "Checking Web Admin API Call...\n\n";

echo "=== REQUEST INFO ===\n";
echo "Method: " . $_SERVER['REQUEST_METHOD'] . "\n";
echo "Request URI: " . $_SERVER['REQUEST_URI'] . "\n";
echo "Query String: " . ($_SERVER['QUERY_STRING'] ?? 'None') . "\n";
echo "Content Type: " . ($_SERVER['CONTENT_TYPE'] ?? 'None') . "\n\n";

echo "=== GET PARAMETERS ===\n";
echo "GET: " . json_encode($_GET, JSON_PRETTY_PRINT) . "\n\n";

echo "=== POST PARAMETERS ===\n";
echo "POST: " . json_encode($_POST, JSON_PRETTY_PRINT) . "\n\n";

echo "=== RAW INPUT ===\n";
$raw_input = file_get_contents('php://input');
echo "Raw input: $raw_input\n\n";

echo "=== ACTION DETECTION ===\n";
$action = $_GET['action'] ?? $_POST['action'] ?? '';
echo "Detected action: '$action'\n\n";

if (empty($action)) {
    echo "❌ No action specified!\n";
} else {
    echo "✅ Action found: $action\n";
    
    if ($action === 'update_order_status') {
        echo "✅ Correct action for order status update\n";
        
        $order_id = $_POST['order_id'] ?? 0;
        $status = $_POST['status'] ?? '';
        
        echo "Order ID: $order_id\n";
        echo "Status: $status\n";
        
        if ($order_id > 0 && !empty($status)) {
            echo "✅ Valid parameters\n";
        } else {
            echo "❌ Invalid parameters\n";
        }
    } else {
        echo "❌ Wrong action for order status update\n";
    }
}

echo "\n=== TESTING API CALL ===\n";

// If we have the right parameters, test the API
if (!empty($_POST['order_id']) && !empty($_POST['status'])) {
    echo "Testing API call with provided parameters...\n";
    
    try {
        // Include database connection
        require_once '../datab_try.php';
        $conn = getDBConnection();
        
        if ($conn) {
            echo "Database connection successful\n";
            
            // Test the function
            include 'orders_api_v2.php';
        } else {
            echo "Database connection failed\n";
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "\n";
    }
} else {
    echo "No valid parameters provided for testing\n";
}
?>
