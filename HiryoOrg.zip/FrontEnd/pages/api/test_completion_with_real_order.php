<?php
// Test order completion with a real pending order
header('Content-Type: text/plain');

echo "=== TESTING ORDER COMPLETION WITH REAL ORDER ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Get the first pending order for testing
    echo "=== FINDING PENDING ORDER FOR TESTING ===\n";
    $pending_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders WHERE status = 'Pending' ORDER BY order_id DESC LIMIT 1");
    $pending_stmt->execute();
    $pending_order = $pending_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$pending_order) {
        echo "❌ No pending orders found for testing!\n";
        exit;
    }
    
    $test_order_id = $pending_order['order_id'];
    echo "✅ Found Order #{$test_order_id} for testing (Status: {$pending_order['status']}, Amount: {$pending_order['total_amount']})\n\n";
    
    // Step 1: Update status to "Completed" (simulate web admin completion)
    echo "=== STEP 1: UPDATING ORDER STATUS TO COMPLETED ===\n";
    $update_stmt = $conn->prepare("UPDATE orders SET status = 'Completed' WHERE order_id = ?");
    $update_result = $update_stmt->execute([$test_order_id]);
    
    if ($update_result) {
        echo "✅ Order #{$test_order_id} status updated to 'Completed'\n";
    } else {
        echo "❌ Failed to update order status\n";
        exit;
    }
    
    // Step 2: Get order details for transfer
    echo "\n=== STEP 2: GETTING ORDER DETAILS FOR TRANSFER ===\n";
    $order_stmt = $conn->prepare("
        SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number, u.address
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?
    ");
    $order_stmt->execute([$test_order_id]);
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "❌ Order #{$test_order_id} not found after status update!\n";
        exit;
    }
    
    echo "✅ Order details retrieved:\n";
    echo "   - Customer: {$order['firstName']} {$order['lastName']}\n";
    echo "   - Email: {$order['email']}\n";
    echo "   - Amount: {$order['total_amount']}\n";
    echo "   - Delivery Method: {$order['delivery_method']}\n";
    
    // Step 3: Get order items
    echo "\n=== STEP 3: GETTING ORDER ITEMS ===\n";
    $items_stmt = $conn->prepare("
        SELECT oi.*, p.product_name
        FROM order_items oi
        LEFT JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $items_stmt->execute([$test_order_id]);
    $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "✅ Found " . count($items) . " order items:\n";
    foreach ($items as $item) {
        echo "   - {$item['product_name']} (Qty: {$item['quantity']})\n";
    }
    
    // Step 4: Insert into transactions table
    echo "\n=== STEP 4: INSERTING INTO TRANSACTIONS TABLE ===\n";
    $trans_stmt = $conn->prepare("
        INSERT INTO transactions (
            order_id, user_id, customer_name, customer_email, customer_contact,
            delivery_method, payment_method, shipping_address, subtotal,
            delivery_fee, amount, created_at, items
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
    ");
    
    $customer_name = trim(($order['firstName'] ?? '') . ' ' . ($order['lastName'] ?? ''));
    $items_json = json_encode($items);
    
    $trans_result = $trans_stmt->execute([
        $test_order_id,
        $order['user_id'],
        $customer_name,
        $order['email'],
        $order['contact_number'],
        $order['delivery_method'],
        $order['payment_method'],
        $order['shipping_address'],
        $order['subtotal'],
        $order['delivery_fee'],
        $order['total_amount'],
        $items_json
    ]);
    
    if ($trans_result) {
        $transaction_id = $conn->lastInsertId();
        echo "✅ Order #{$test_order_id} successfully inserted into transactions table (Transaction ID: {$transaction_id})\n";
    } else {
        echo "❌ Failed to insert order into transactions table\n";
        $error_info = $trans_stmt->errorInfo();
        echo "   Error: " . $error_info[2] . "\n";
        exit;
    }
    
    // Step 5: Delete order items
    echo "\n=== STEP 5: DELETING ORDER ITEMS ===\n";
    $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
    $delete_items_result = $delete_items_stmt->execute([$test_order_id]);
    
    if ($delete_items_result) {
        $deleted_items = $delete_items_stmt->rowCount();
        echo "✅ Deleted {$deleted_items} order items from order_items table\n";
    } else {
        echo "❌ Failed to delete order items\n";
    }
    
    // Step 6: Delete from orders table
    echo "\n=== STEP 6: DELETING FROM ORDERS TABLE ===\n";
    $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
    $delete_result = $delete_stmt->execute([$test_order_id]);
    
    if ($delete_result) {
        echo "✅ Order #{$test_order_id} deleted from orders table\n";
    } else {
        echo "❌ Failed to delete order from orders table\n";
    }
    
    // Step 7: Verify the transfer
    echo "\n=== STEP 7: VERIFYING TRANSFER ===\n";
    
    // Check if order exists in orders table
    $check_order_stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ?");
    $check_order_stmt->execute([$test_order_id]);
    $order_exists = $check_order_stmt->fetch();
    
    if ($order_exists) {
        echo "❌ Order #{$test_order_id} still exists in orders table!\n";
    } else {
        echo "✅ Order #{$test_order_id} successfully removed from orders table\n";
    }
    
    // Check if order exists in transactions table
    $check_trans_stmt = $conn->prepare("SELECT transaction_id FROM transactions WHERE order_id = ?");
    $check_trans_stmt->execute([$test_order_id]);
    $trans_exists = $check_trans_stmt->fetch();
    
    if ($trans_exists) {
        echo "✅ Order #{$test_order_id} successfully transferred to transactions table\n";
    } else {
        echo "❌ Order #{$test_order_id} NOT found in transactions table!\n";
    }
    
    echo "\n=== TEST COMPLETE ===\n";
    if (!$order_exists && $trans_exists) {
        echo "🎉 SUCCESS: Order completion and transfer worked perfectly!\n";
    } else {
        echo "❌ FAILURE: Order completion process has issues\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
