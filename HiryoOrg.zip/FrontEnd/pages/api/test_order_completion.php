<?php
// Simple test script for order completion
header('Content-Type: text/plain');

echo "Testing Order Completion Process...\n\n";

try {
    // Include database connection (same as API)
    require_once '../datab_try.php';
    
    // Get PDO connection like the API does
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connection successful!\n\n";
    
    // First, let's see what orders exist
    echo "Checking available orders...\n";
    $all_orders_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders ORDER BY order_id DESC LIMIT 10");
    $all_orders_stmt->execute();
    $all_orders = $all_orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($all_orders)) {
        echo "No orders found in the database!\n";
        exit;
    }
    
    echo "Available orders:\n";
    foreach ($all_orders as $order_info) {
        echo "- Order #{$order_info['order_id']}: Status = {$order_info['status']}, Total = {$order_info['total_amount']}\n";
    }
    echo "\n";
    
    // Find a suitable order to test with (preferably one with "Delivered" status)
    $test_order = null;
    foreach ($all_orders as $order_info) {
        if ($order_info['status'] === 'Delivered') {
            $test_order = $order_info;
            break;
        }
    }
    
    // If no delivered orders, use the first available order
    if (!$test_order) {
        $test_order = $all_orders[0];
    }
    
    $order_id = $test_order['order_id'];
    
    echo "Testing with Order #$order_id (Status: {$test_order['status']})...\n";
    
    // Check current status
    $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "Order #$order_id not found!\n";
        exit;
    }
    
    echo "Order found - Status: " . $order['status'] . "\n";
    echo "Order details: " . json_encode($order, JSON_PRETTY_PRINT) . "\n\n";
    
    // Check if transactions table exists
    $table_check = $conn->query("SHOW TABLES LIKE 'transactions'");
    if ($table_check->rowCount() == 0) {
        echo "Transactions table does not exist!\n";
        echo "Creating transactions table...\n";
        
        $create_sql = "CREATE TABLE transactions (
            transaction_id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            user_id INT NOT NULL,
            customer_name VARCHAR(255),
            customer_email VARCHAR(255),
            customer_contact VARCHAR(20),
            delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            shipping_address TEXT,
            subtotal DECIMAL(10,2) NOT NULL,
            delivery_fee DECIMAL(10,2) NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            created_at DATETIME NOT NULL,
            items JSON
        )";
        
        $conn->exec($create_sql);
        echo "Transactions table created!\n\n";
    } else {
        echo "Transactions table exists.\n\n";
    }
    
    // Check if order already exists in transactions
    $trans_check = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $trans_check->execute([$order_id]);
    $existing = $trans_check->fetch(PDO::FETCH_ASSOC);
    
    if ($existing) {
        echo "Order already exists in transactions table:\n";
        echo json_encode($existing, JSON_PRETTY_PRINT) . "\n\n";
    } else {
        echo "Order not found in transactions table.\n\n";
    }
    
    // Test the API call directly
    echo "Testing API call...\n";
    
    // Simulate the API call
    $_POST['order_id'] = $order_id;
    $_POST['status'] = 'Completed';
    
    // Include the API function
    ob_start();
    include 'orders_api_v2.php';
    $api_output = ob_get_clean();
    
    echo "API Response: $api_output\n\n";
    
    // Check final state
    echo "Final check...\n";
    
    $final_order_check = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $final_order_check->execute([$order_id]);
    $final_order = $final_order_check->fetch(PDO::FETCH_ASSOC);
    
    if ($final_order) {
        echo "Order still exists in orders table:\n";
        echo json_encode($final_order, JSON_PRETTY_PRINT) . "\n";
    } else {
        echo "Order no longer exists in orders table.\n";
    }
    
    $final_trans_check = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $final_trans_check->execute([$order_id]);
    $final_trans = $final_trans_check->fetch(PDO::FETCH_ASSOC);
    
    if ($final_trans) {
        echo "Order exists in transactions table:\n";
        echo json_encode($final_trans, JSON_PRETTY_PRINT) . "\n";
    } else {
        echo "Order not found in transactions table.\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
