<?php
/**
 * Test Mobile Products API
 * This script tests the mobile app's product loading API
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test get_all_products API (used by mobile app)
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_all_products';
    
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 10
        ]
    ]);
    
    $response = @file_get_contents($apiUrl, false, $context);
    $productsResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['get_all_products_api'] = [
        'status' => $productsResult['success'] ? 'PASS' : 'FAIL',
        'message' => $productsResult['success'] ? 'Mobile products API working' : 'Mobile products API failed: ' . ($productsResult['message'] ?? 'Unknown error'),
        'products_count' => isset($productsResult['products']) ? count($productsResult['products']) : 0,
        'api_response' => $productsResult,
        'raw_response' => $response
    ];
    
    // Test 2: Check if products have required fields for mobile app
    if ($productsResult['success'] && isset($productsResult['products']) && count($productsResult['products']) > 0) {
        $sampleProduct = $productsResult['products'][0];
        $requiredFields = ['product_id', 'product_name', 'category', 'price', 'stock_quantity', 'status'];
        $missingFields = [];
        
        foreach ($requiredFields as $field) {
            if (!isset($sampleProduct[$field])) {
                $missingFields[] = $field;
            }
        }
        
        $testResults['tests']['product_fields_check'] = [
            'status' => empty($missingFields) ? 'PASS' : 'FAIL',
            'message' => empty($missingFields) ? 'All required fields present' : 'Missing required fields: ' . implode(', ', $missingFields),
            'sample_product' => $sampleProduct,
            'missing_fields' => $missingFields
        ];
    }
    
    // Test 3: Check if all products have 'Active' status (mobile app only shows active products)
    if ($productsResult['success'] && isset($productsResult['products'])) {
        $inactiveProducts = array_filter($productsResult['products'], function($product) {
            return $product['status'] !== 'Active';
        });
        
        $testResults['tests']['active_status_check'] = [
            'status' => empty($inactiveProducts) ? 'PASS' : 'WARNING',
            'message' => empty($inactiveProducts) ? 'All products have Active status' : 'Found ' . count($inactiveProducts) . ' products with non-Active status',
            'inactive_products' => array_values($inactiveProducts)
        ];
    }
    
    // Test 4: Test get_product_details API
    if ($productsResult['success'] && isset($productsResult['products']) && count($productsResult['products']) > 0) {
        $testProductId = $productsResult['products'][0]['product_id'];
        $detailsUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_product_details&product_id=' . $testProductId;
        
        $detailsResponse = @file_get_contents($detailsUrl, false, $context);
        $detailsResult = $detailsResponse ? json_decode($detailsResponse, true) : ['success' => false, 'message' => 'No response from details API'];
        
        $testResults['tests']['get_product_details_api'] = [
            'status' => $detailsResult['success'] ? 'PASS' : 'FAIL',
            'message' => $detailsResult['success'] ? 'Product details API working' : 'Product details API failed: ' . ($detailsResult['message'] ?? 'Unknown error'),
            'test_product_id' => $testProductId,
            'api_response' => $detailsResult
        ];
    }
    
    // Test 5: Check database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if ($conn) {
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products WHERE status = 'Active'");
        $stmt->execute();
        $activeCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        
        $testResults['tests']['database_connection'] = [
            'status' => 'PASS',
            'message' => 'Database connection working',
            'active_products_in_db' => $activeCount
        ];
    } else {
        $testResults['tests']['database_connection'] = [
            'status' => 'FAIL',
            'message' => 'Database connection failed'
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'mobile_app_should_work' => $failCount === 0 ? 'YES' : 'NO',
        'recommendations' => $failCount > 0 ? [
            '1. Check API endpoints are accessible',
            '2. Verify database connection',
            '3. Ensure products have required fields',
            '4. Check mobile app logs for specific errors'
        ] : ['Mobile app should load products successfully']
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'mobile_products_api',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
