<?php
// Test inserting into transactions table directly
header('Content-Type: text/plain');

echo "Testing Transactions Table Insert...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Check transactions table structure
    echo "=== TRANSACTIONS TABLE STRUCTURE ===\n";
    $structure_stmt = $conn->query("DESCRIBE transactions");
    $columns = $structure_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Transactions table columns:\n";
    foreach ($columns as $column) {
        echo "- {$column['Field']}: {$column['Type']} ({$column['Null']}, {$column['Key']}, {$column['Default']})\n";
    }
    echo "\n";
    
    // Find an order to test with
    echo "=== FINDING TEST ORDER ===\n";
    $order_stmt = $conn->prepare("SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number FROM orders o LEFT JOIN users u ON o.user_id = u.user_id WHERE o.status NOT IN ('Completed', 'Cancelled') ORDER BY o.order_id DESC LIMIT 1");
    $order_stmt->execute();
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "No orders found for testing!\n";
        exit;
    }
    
    echo "Test order found:\n";
    echo "- Order ID: {$order['order_id']}\n";
    echo "- User ID: {$order['user_id']}\n";
    echo "- Customer: {$order['firstName']} {$order['lastName']}\n";
    echo "- Email: {$order['email']}\n";
    echo "- Total: {$order['total_amount']}\n";
    echo "- Status: {$order['status']}\n\n";
    
    // Get order items
    echo "=== GETTING ORDER ITEMS ===\n";
    $items_stmt = $conn->prepare("SELECT oi.*, p.product_name FROM order_items oi LEFT JOIN products p ON oi.product_id = p.product_id WHERE oi.order_id = ?");
    $items_stmt->execute([$order['order_id']]);
    $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Order items: " . count($items) . " items\n";
    foreach ($items as $item) {
        echo "- {$item['product_name']}: {$item['quantity']} x {$item['price_at_purchase']}\n";
    }
    echo "\n";
    
    // Test the insert
    echo "=== TESTING INSERT ===\n";
    
    $customer_name = trim($order['firstName'] . ' ' . $order['lastName']);
    $items_json = json_encode($items);
    
    echo "Prepared data:\n";
    echo "- Customer Name: '$customer_name'\n";
    echo "- Items JSON: '$items_json'\n";
    echo "- Delivery Method: '{$order['delivery_method']}'\n";
    echo "- Payment Method: '{$order['payment_method']}'\n";
    echo "- Shipping Address: '{$order['shipping_address']}'\n";
    echo "- Subtotal: {$order['subtotal']}\n";
    echo "- Delivery Fee: {$order['delivery_fee']}\n";
    echo "- Total Amount: {$order['total_amount']}\n\n";
    
    // Test insert with test order ID
    $test_order_id = 99999;
    
    echo "Testing insert with test order ID: $test_order_id\n";
    
    $insert_stmt = $conn->prepare("
        INSERT INTO transactions (
            order_id, user_id, customer_name, customer_email, customer_contact,
            delivery_method, payment_method, shipping_address, subtotal, 
            delivery_fee, amount, created_at, items
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
    ");
    
    try {
        $result = $insert_stmt->execute([
            $test_order_id,
            $order['user_id'],
            $customer_name,
            $order['email'],
            $order['contact_number'],
            $order['delivery_method'],
            $order['payment_method'],
            $order['shipping_address'],
            $order['subtotal'],
            $order['delivery_fee'],
            $order['total_amount'],
            $items_json
        ]);
        
        if ($result) {
            echo "✅ Test insert successful!\n";
            
            // Check if it was inserted
            $check_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
            $check_stmt->execute([$test_order_id]);
            $inserted = $check_stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($inserted) {
                echo "✅ Test record found in transactions table:\n";
                echo "- Transaction ID: {$inserted['transaction_id']}\n";
                echo "- Order ID: {$inserted['order_id']}\n";
                echo "- Customer: {$inserted['customer_name']}\n";
                echo "- Amount: {$inserted['amount']}\n";
            } else {
                echo "❌ Test record not found in transactions table!\n";
            }
            
            // Clean up test record
            $delete_test = $conn->prepare("DELETE FROM transactions WHERE order_id = ?");
            $delete_test->execute([$test_order_id]);
            echo "✅ Test record cleaned up\n";
            
        } else {
            echo "❌ Test insert failed!\n";
            $errorInfo = $insert_stmt->errorInfo();
            echo "Error: " . json_encode($errorInfo) . "\n";
        }
        
    } catch (Exception $e) {
        echo "❌ Exception during insert: " . $e->getMessage() . "\n";
        echo "File: " . $e->getFile() . "\n";
        echo "Line: " . $e->getLine() . "\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
