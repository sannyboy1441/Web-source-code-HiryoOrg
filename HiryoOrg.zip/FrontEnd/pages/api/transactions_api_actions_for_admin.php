<?php
/**
 * Debug API endpoint - Captures requests to the old API name
 * This helps identify what's calling the old API endpoint
 */

header('Content-Type: application/json');

// Log the request details
error_log("Legacy API called: transactions_api_actions_for_admin");
error_log("Request method: " . $_SERVER['REQUEST_METHOD']);
error_log("GET params: " . print_r($_GET, true));
error_log("POST params: " . print_r($_POST, true));
error_log("Headers: " . print_r(getallheaders(), true));

// Include database connection
@include_once '../datab_try.php';

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Use the same logic as the main transactions API
    $query = "
        SELECT 
            t.transaction_id, t.user_id, t.order_id, t.amount, t.payment_method, t.created_at,
            u.username as user_name, u.email as user_email, o.status as order_status
            FROM transactions t
            LEFT JOIN users u ON t.user_id = u.user_id
            LEFT JOIN orders o ON t.order_id = o.order_id
            ORDER BY t.created_at DESC
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'message' => 'Legacy API endpoint - should use transactions_api.php instead',
        'transactions' => $transactions,
        'debug_info' => [
            'request_method' => $_SERVER['REQUEST_METHOD'],
            'action' => $_GET['action'] ?? $_POST['action'] ?? 'none',
            'transaction_count' => count($transactions)
        ]
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Legacy API error: ' . $e->getMessage(),
        'debug_info' => [
            'request_method' => $_SERVER['REQUEST_METHOD'],
            'action' => $_GET['action'] ?? $_POST['action'] ?? 'none'
        ]
    ]);
}
?>
