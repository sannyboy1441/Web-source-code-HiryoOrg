<?php
// Test the fixed order completion process
header('Content-Type: text/plain');

echo "=== TESTING FIXED ORDER COMPLETION ===\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check current orders table
    echo "=== CURRENT ORDERS TABLE ===\n";
    $orders_stmt = $conn->prepare("SELECT order_id, status, total_amount, order_date FROM orders ORDER BY order_id DESC LIMIT 5");
    $orders_stmt->execute();
    $orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "❌ No orders found in orders table!\n";
        exit;
    }
    
    foreach ($orders as $order) {
        echo "Order #{$order['order_id']}: Status = {$order['status']}, Amount = {$order['total_amount']}, Date = {$order['order_date']}\n";
    }
    
    // Find a pending order to test with
    $pending_stmt = $conn->prepare("SELECT order_id FROM orders WHERE status = 'Pending' LIMIT 1");
    $pending_stmt->execute();
    $pending_order = $pending_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$pending_order) {
        echo "\n❌ No pending orders found to test with!\n";
        echo "Available statuses:\n";
        $status_stmt = $conn->prepare("SELECT DISTINCT status FROM orders");
        $status_stmt->execute();
        $statuses = $status_stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($statuses as $status) {
            echo "- $status\n";
        }
        exit;
    }
    
    $test_order_id = $pending_order['order_id'];
    echo "\n✅ Found pending order #$test_order_id to test with\n\n";
    
    // Check transactions table before
    echo "=== TRANSACTIONS TABLE BEFORE ===\n";
    $trans_before_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions WHERE order_id = ?");
    $trans_before_stmt->execute([$test_order_id]);
    $trans_before_count = $trans_before_stmt->fetch(PDO::FETCH_ASSOC)['count'];
    echo "Transactions for order #$test_order_id: $trans_before_count\n\n";
    
    // Simulate the API call using the new API
    echo "=== SIMULATING API CALL WITH NEW API ===\n";
    echo "Calling orders_api_v3.php with action=update_order_status, order_id=$test_order_id, status=Completed\n\n";
    
    // Set up the POST data
    $_POST = [];
    $_POST['order_id'] = $test_order_id;
    $_POST['status'] = 'Completed';
    $_GET = [];
    $_GET['action'] = 'update_order_status';
    
    // Capture the API response
    ob_start();
    
    // Include the new API file
    include 'orders_api_v3.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Check orders table after
    echo "=== ORDERS TABLE AFTER ===\n";
    $orders_after_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders WHERE order_id = ?");
    $orders_after_stmt->execute([$test_order_id]);
    $order_after = $orders_after_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_after) {
        echo "❌ Order #$test_order_id still exists in orders table: Status = {$order_after['status']}\n";
    } else {
        echo "✅ Order #$test_order_id successfully removed from orders table\n";
    }
    
    // Check transactions table after
    echo "\n=== TRANSACTIONS TABLE AFTER ===\n";
    $trans_after_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $trans_after_stmt->execute([$test_order_id]);
    $transaction = $trans_after_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($transaction) {
        echo "✅ Order #$test_order_id successfully transferred to transactions table:\n";
        echo "- Transaction ID: {$transaction['transaction_id']}\n";
        echo "- Customer: {$transaction['customer_name']}\n";
        echo "- Amount: {$transaction['amount']}\n";
        echo "- Created: {$transaction['created_at']}\n";
    } else {
        echo "❌ Order #$test_order_id NOT found in transactions table - TRANSFER FAILED!\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if (!$order_after && $transaction) {
        echo "🎉 SUCCESS: Order completion and transfer worked perfectly!\n";
        echo "✅ The fix is working correctly!\n";
    } elseif ($order_after && $transaction) {
        echo "⚠️ PARTIAL: Order transferred but not deleted from orders table\n";
    } elseif (!$order_after && !$transaction) {
        echo "❌ FAILURE: Order deleted but not transferred - DATA LOST!\n";
    } else {
        echo "❌ FAILURE: Order still exists in orders table, not transferred\n";
    }
    
    // Clean up test transaction
    if ($transaction) {
        $conn->prepare("DELETE FROM transactions WHERE order_id = ?")->execute([$test_order_id]);
        echo "Cleaned up test transaction.\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
