<?php
/**
 * Test API Endpoints - Verify all APIs are working
 */

header('Content-Type: application/json');

echo json_encode([
    'success' => true,
    'message' => 'API endpoints test',
    'data' => [
        'available_apis' => [
            'dashboard_api.php' => 'Dashboard statistics and analytics',
            'transactions_api.php' => 'Transaction management',
            'orders_api.php' => 'Order management', 
            'products_api.php' => 'Product management',
            'users_api.php' => 'User management',
            'notifications_api.php' => 'Notification management',
            'announcements_api.php' => 'Announcement management',
            'admin_api.php' => 'Admin management',
            'unified_analytics_api.php' => 'Analytics and reporting',
            'login.php' => 'Authentication',
            'forgot_password.php' => 'Password reset',
            'update_profile.php' => 'Profile updates',
            'change_password.php' => 'Password changes'
        ],
        'server_info' => [
            'php_version' => PHP_VERSION,
            'server_time' => date('Y-m-d H:i:s'),
            'timezone' => date_default_timezone_get()
        ]
    ]
]);
?>
