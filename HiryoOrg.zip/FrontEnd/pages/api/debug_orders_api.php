<?php
/**
 * Debug Orders API
 * This script debugs the orders API to see why POST requests fail
 */

header('Content-Type: application/json');

// Start output buffering
ob_start();

// Include database connection
require_once '../datab_try.php';

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    // Debug information
    $debug = [
        'timestamp' => date('Y-m-d H:i:s'),
        'request_method' => $_SERVER['REQUEST_METHOD'],
        'get_data' => $_GET,
        'post_data' => $_POST,
        'request_data' => $_REQUEST,
        'action_from_get' => $_GET['action'] ?? 'NOT_SET',
        'action_from_post' => $_POST['action'] ?? 'NOT_SET',
        'action_from_request' => $_REQUEST['action'] ?? 'NOT_SET'
    ];

    $action = $_REQUEST['action'] ?? '';

    $debug['final_action'] = $action;
    $debug['action_length'] = strlen($action);
    $debug['action_trimmed'] = trim($action);

    switch ($action) {
        case 'test':
            echo json_encode(['success' => true, 'message' => 'Debug API working', 'debug' => $debug]);
            break;
            
        case 'place_order':
            echo json_encode(['success' => true, 'message' => 'Place order action received', 'debug' => $debug]);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action specified', 'debug' => $debug]);
            break;
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage(), 'debug' => $debug ?? []]);
}

ob_end_flush();
?>
