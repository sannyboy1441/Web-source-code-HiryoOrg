<?php
// Check why transactions are not showing in the web admin
header('Content-Type: text/plain');

echo "=== CHECKING TRANSACTIONS DISPLAY ISSUE ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Check transactions table directly
    echo "=== TRANSACTIONS TABLE (Raw Data) ===\n";
    $trans_stmt = $conn->prepare("SELECT * FROM transactions ORDER BY transaction_id DESC LIMIT 10");
    $trans_stmt->execute();
    $transactions = $trans_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($transactions)) {
        echo "❌ No transactions found in transactions table!\n";
    } else {
        echo "Found " . count($transactions) . " transactions:\n";
        foreach ($transactions as $trans) {
            echo "   - Transaction ID: {$trans['transaction_id']}, Order ID: {$trans['order_id']}, Customer: {$trans['customer_name']}, Amount: {$trans['amount']}, Date: {$trans['created_at']}\n";
        }
    }
    
    // Test the transactions API directly
    echo "\n=== TESTING TRANSACTIONS API ===\n";
    
    // Set up for API call
    $_GET = [];
    $_GET['action'] = 'get_all_transactions';
    
    echo "Calling transactions_api_v4.php...\n";
    
    // Capture the API response
    ob_start();
    
    // Include the transactions API
    include 'transactions_api_v4.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Parse the response to see what's happening
    $response_data = json_decode($api_response, true);
    
    if ($response_data && isset($response_data['success'])) {
        if ($response_data['success']) {
            $trans_count = count($response_data['transactions'] ?? []);
            echo "✅ API returned success with $trans_count transactions\n";
            
            if ($trans_count > 0) {
                echo "First transaction: " . json_encode($response_data['transactions'][0]) . "\n";
            }
        } else {
            echo "❌ API returned error: " . ($response_data['message'] ?? 'Unknown error') . "\n";
        }
    } else {
        echo "❌ API response could not be parsed as JSON\n";
    }
    
    // Check if there's a specific issue with Order #51
    echo "\n=== CHECKING ORDER #51 SPECIFICALLY ===\n";
    $order_51_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = 51");
    $order_51_stmt->execute();
    $order_51 = $order_51_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_51) {
        echo "✅ Order #51 found in transactions table:\n";
        echo "   - Transaction ID: {$order_51['transaction_id']}\n";
        echo "   - Customer: {$order_51['customer_name']}\n";
        echo "   - Amount: {$order_51['amount']}\n";
        echo "   - Date: {$order_51['created_at']}\n";
    } else {
        echo "❌ Order #51 NOT found in transactions table!\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if ($order_51) {
        echo "✅ Order #51 is in transactions table\n";
        echo "🔍 Issue is likely with the transactions API or web admin display\n";
    } else {
        echo "❌ Order #51 is NOT in transactions table\n";
        echo "🔍 Issue is with the order completion process\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
