<?php
/**
 * Test Orders Direct
 * Direct test of orders API functionality
 */

header('Content-Type: application/json');

// Simulate the exact same request that the mobile app makes
$_SERVER['REQUEST_METHOD'] = 'POST';
$_POST['action'] = 'place_order';
$_POST['user_id'] = 1;
$_POST['total_amount'] = 388.00;
$_POST['delivery_fee'] = 108.00;
$_POST['items'] = '[{"product_id":46,"quantity":1,"price":280.00}]';
$_POST['delivery_method'] = 'Delivery';
$_POST['shipping_address'] = 'Purok Malapati, Sitio Primitiva, Tungkop Minglanilla, Cebu 6046';
$_POST['payment_method'] = 'Cash on Delivery';

// Include the orders API directly
ob_start();
try {
    include 'orders_api.php';
    $output = ob_get_contents();
    ob_end_clean();
    
    echo json_encode([
        'direct_test' => [
            'status' => 'SUCCESS',
            'output' => $output,
            'parsed_output' => json_decode($output, true)
        ]
    ], JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    ob_end_clean();
    echo json_encode([
        'direct_test' => [
            'status' => 'ERROR',
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]
    ], JSON_PRETTY_PRINT);
}
?>
