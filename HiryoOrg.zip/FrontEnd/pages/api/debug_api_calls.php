<?php
// Debug API calls to see what the web admin is actually sending
header('Content-Type: text/plain');

echo "API Call Debug Information...\n\n";

echo "=== REQUEST METHOD ===\n";
echo "Method: " . $_SERVER['REQUEST_METHOD'] . "\n\n";

echo "=== GET PARAMETERS ===\n";
echo "GET data: " . json_encode($_GET, JSON_PRETTY_PRINT) . "\n\n";

echo "=== POST PARAMETERS ===\n";
echo "POST data: " . json_encode($_POST, JSON_PRETTY_PRINT) . "\n\n";

echo "=== REQUEST HEADERS ===\n";
foreach (getallheaders() as $name => $value) {
    echo "$name: $value\n";
}
echo "\n";

echo "=== RAW INPUT ===\n";
$raw_input = file_get_contents('php://input');
echo "Raw input: $raw_input\n\n";

echo "=== SERVER INFO ===\n";
echo "Request URI: " . $_SERVER['REQUEST_URI'] . "\n";
echo "Query String: " . ($_SERVER['QUERY_STRING'] ?? 'None') . "\n";
echo "Content Type: " . ($_SERVER['CONTENT_TYPE'] ?? 'None') . "\n";
echo "Content Length: " . ($_SERVER['CONTENT_LENGTH'] ?? 'None') . "\n\n";

echo "=== ACTION DETECTION ===\n";
$action = $_GET['action'] ?? $_POST['action'] ?? '';
echo "Detected action: '$action'\n";

if (empty($action)) {
    echo "❌ No action specified!\n";
} else {
    echo "✅ Action found: $action\n";
}

echo "\n=== TESTING API CALL ===\n";

// Test if we can call the API directly
if (!empty($_POST['order_id']) && !empty($_POST['status'])) {
    echo "Testing direct API call...\n";
    
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if ($conn) {
        echo "Database connection successful\n";
        
        // Test the function directly
        include 'orders_api_v2.php';
    } else {
        echo "Database connection failed\n";
    }
} else {
    echo "No order_id or status provided for testing\n";
}
?>
