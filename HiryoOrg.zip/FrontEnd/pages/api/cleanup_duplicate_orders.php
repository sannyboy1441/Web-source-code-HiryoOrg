<?php
// Clean up duplicate orders that exist in both tables
header('Content-Type: text/plain');

echo "=== CLEANING UP DUPLICATE ORDERS ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Find orders that exist in both tables
    echo "=== FINDING DUPLICATE ORDERS ===\n";
    $duplicate_stmt = $conn->prepare("
        SELECT o.order_id, o.status, o.total_amount
        FROM orders o
        INNER JOIN transactions t ON o.order_id = t.order_id
        WHERE o.status IN ('Completed', 'Cancelled')
        ORDER BY o.order_id DESC
    ");
    $duplicate_stmt->execute();
    $duplicate_orders = $duplicate_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($duplicate_orders)) {
        echo "✅ No duplicate orders found!\n";
        exit;
    }
    
    echo "Found " . count($duplicate_orders) . " duplicate orders (exist in both tables):\n";
    foreach ($duplicate_orders as $order) {
        echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}\n";
    }
    
    echo "\n=== CLEANING UP DUPLICATES ===\n";
    
    foreach ($duplicate_orders as $order_data) {
        $order_id = $order_data['order_id'];
        echo "\nCleaning up Order #{$order_id}...\n";
        
        // Delete order items first
        $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
        $delete_items_result = $delete_items_stmt->execute([$order_id]);
        
        if ($delete_items_result) {
            $deleted_items = $delete_items_stmt->rowCount();
            echo "   ✅ Deleted {$deleted_items} order items for Order #{$order_id}\n";
        } else {
            echo "   ❌ Failed to delete order items for Order #{$order_id}\n";
        }
        
        // Delete from orders table
        $delete_order_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
        $delete_order_result = $delete_order_stmt->execute([$order_id]);
        
        if ($delete_order_result) {
            echo "   ✅ Deleted Order #{$order_id} from orders table\n";
        } else {
            echo "   ❌ Failed to delete Order #{$order_id} from orders table\n";
        }
    }
    
    // Final verification
    echo "\n=== FINAL VERIFICATION ===\n";
    
    // Check orders table
    $final_orders_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE status IN ('Completed', 'Cancelled')");
    $final_orders_stmt->execute();
    $final_orders_count = $final_orders_stmt->fetch(PDO::FETCH_ASSOC);
    
    // Check transactions table
    $final_trans_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $final_trans_stmt->execute();
    $final_trans_count = $final_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "Completed/Cancelled orders still in orders table: {$final_orders_count['count']}\n";
    echo "Total transactions in transactions table: {$final_trans_count['count']}\n";
    
    if ($final_orders_count['count'] == 0) {
        echo "\n🎉 SUCCESS: All duplicate orders have been cleaned up!\n";
        echo "✅ Orders table now only contains active orders\n";
        echo "✅ Transactions table contains all completed orders\n";
        echo "✅ No more duplicates!\n";
    } else {
        echo "\n❌ Still {$final_orders_count['count']} completed orders in orders table\n";
    }
    
    // Show current orders table
    echo "\n=== CURRENT ORDERS TABLE ===\n";
    $current_orders_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders ORDER BY order_id DESC LIMIT 10");
    $current_orders_stmt->execute();
    $current_orders = $current_orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($current_orders)) {
        echo "✅ Orders table is empty - all orders have been processed!\n";
    } else {
        echo "Orders in orders table:\n";
        foreach ($current_orders as $order) {
            echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}\n";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
