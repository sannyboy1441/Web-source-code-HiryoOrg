<?php
/**
 * Test Orders Bypass Cache
 * This script tests orders API with cache bypassing
 */

header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'cache_bypass_tests' => []
    ];
    
    // Test 1: Test with timestamp to bypass cache
    $timestamp = time();
    $testUrl = "http://" . $_SERVER['HTTP_HOST'] . "/HiryoOrg/FrontEnd/pages/api/orders_api.php?action=test&t={$timestamp}";
    
    $response = @file_get_contents($testUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 10
        ]
    ]));
    
    $testResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response'];
    
    $testResults['cache_bypass_tests']['test_action_with_timestamp'] = [
        'url' => $testUrl,
        'response' => $testResult,
        'status' => $testResult['success'] ? 'WORKING' : 'FAILED'
    ];
    
    // Test 2: Test place_order with fresh data
    $postUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/orders_api.php';
    $orderData = [
        'action' => 'place_order',
        'user_id' => 1,
        'total_amount' => 388.00,
        'delivery_fee' => 108.00,
        'items' => '[{"product_id":46,"quantity":1,"price":280.00}]',
        'delivery_method' => 'Delivery',
        'shipping_address' => 'Test Address',
        'payment_method' => 'Cash on Delivery',
        'timestamp' => $timestamp
    ];
    
    $postData = http_build_query($orderData);
    
    $postResponse = @file_get_contents($postUrl, false, stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 15
        ]
    ]));
    
    $postResult = $postResponse ? json_decode($postResponse, true) : ['success' => false, 'message' => 'No response'];
    
    $testResults['cache_bypass_tests']['place_order_with_timestamp'] = [
        'url' => $postUrl,
        'post_data' => $orderData,
        'response' => $postResult,
        'status' => $postResult['success'] ? 'SUCCESS' : 'FAILED',
        'error_type' => strpos($postResult['message'] ?? '', 'Invalid action') !== false ? 'INVALID_ACTION' : 
                       (strpos($postResult['message'] ?? '', 'SQLSTATE[23000]') !== false ? 'CONSTRAINT_VIOLATION' : 'OTHER')
    ];
    
    // Test 3: Check file modification time
    $ordersApiPath = __DIR__ . '/orders_api.php';
    $testResults['cache_bypass_tests']['file_info'] = [
        'file_exists' => file_exists($ordersApiPath),
        'last_modified' => file_exists($ordersApiPath) ? date('Y-m-d H:i:s', filemtime($ordersApiPath)) : 'N/A',
        'file_size' => file_exists($ordersApiPath) ? filesize($ordersApiPath) : 0
    ];
    
    // Test 4: Test different action to see if it's a general issue
    $otherActionUrl = "http://" . $_SERVER['HTTP_HOST'] . "/HiryoOrg/FrontEnd/pages/api/orders_api.php?action=nonexistent&t={$timestamp}";
    
    $otherResponse = @file_get_contents($otherActionUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 10
        ]
    ]));
    
    $otherResult = $otherResponse ? json_decode($otherResponse, true) : ['success' => false, 'message' => 'No response'];
    
    $testResults['cache_bypass_tests']['nonexistent_action_test'] = [
        'url' => $otherActionUrl,
        'response' => $otherResult,
        'expected_error' => strpos($otherResult['message'] ?? '', 'Invalid action') !== false ? 'CORRECT' : 'UNEXPECTED'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
