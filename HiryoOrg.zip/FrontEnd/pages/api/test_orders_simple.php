<?php
/**
 * Simple Orders API Test - No Database Required
 */

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Get action parameter
$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'test':
        echo json_encode(['success' => true, 'message' => 'Simple Orders API is working', 'timestamp' => date('Y-m-d H:i:s')]);
        break;
        
    case 'get_all_orders_for_admin':
        // Return mock orders data
        $orders = [
            [
                'order_id' => 8,
                'user_id' => 1,
                'total_amount' => 1250.00,
                'payment_method' => 'COD',
                'delivery_method' => 'Delivery',
                'status' => 'Pending',
                'order_date' => '2025-01-17 14:30:00',
                'firstName' => 'Juan',
                'lastName' => 'Dela Cruz',
                'email' => 'juan.delacruz@email.com',
                'customer_name' => 'Juan Dela Cruz'
            ],
            [
                'order_id' => 9,
                'user_id' => 2,
                'total_amount' => 850.00,
                'payment_method' => 'COD',
                'delivery_method' => 'Pickup',
                'status' => 'Processing',
                'order_date' => '2025-01-17 12:15:00',
                'firstName' => 'Maria',
                'lastName' => 'Santos',
                'email' => 'maria.santos@email.com',
                'customer_name' => 'Maria Santos'
            ],
            [
                'order_id' => 10,
                'user_id' => 3,
                'total_amount' => 2100.00,
                'payment_method' => 'COD',
                'delivery_method' => 'Delivery',
                'status' => 'Shipped',
                'order_date' => '2025-01-17 10:45:00',
                'firstName' => 'Pedro',
                'lastName' => 'Garcia',
                'email' => 'pedro.garcia@email.com',
                'customer_name' => 'Pedro Garcia'
            ],
            [
                'order_id' => 11,
                'user_id' => 4,
                'total_amount' => 1750.00,
                'payment_method' => 'COD',
                'delivery_method' => 'Delivery',
                'status' => 'Pending',
                'order_date' => '2025-01-17 09:20:00',
                'firstName' => 'Ana',
                'lastName' => 'Rodriguez',
                'email' => 'ana.rodriguez@email.com',
                'customer_name' => 'Ana Rodriguez'
            ],
            [
                'order_id' => 12,
                'user_id' => 5,
                'total_amount' => 950.00,
                'payment_method' => 'COD',
                'delivery_method' => 'Pickup',
                'status' => 'Completed',
                'order_date' => '2025-01-17 08:10:00',
                'firstName' => 'Carlos',
                'lastName' => 'Lopez',
                'email' => 'carlos.lopez@email.com',
                'customer_name' => 'Carlos Lopez'
            ]
        ];
        
        echo json_encode(['success' => true, 'orders' => $orders]);
        break;
        
    case 'get_order_details':
        $order_id = (int)($_GET['order_id'] ?? 0);
        
        if ($order_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Valid order ID is required.']);
            break;
        }
        
        // Return mock order details based on order ID
        $orderDetails = [
            'order_id' => $order_id,
            'user_id' => 1,
            'total_amount' => 1250.00,
            'payment_method' => 'COD',
            'delivery_method' => 'Delivery',
            'shipping_address' => '123 Main Street, Manila, Philippines',
            'status' => 'Pending',
            'order_date' => '2025-01-17 14:30:00',
            'firstName' => 'Juan',
            'lastName' => 'Dela Cruz',
            'email' => 'juan.delacruz@email.com',
            'phoneNumber' => '+63 912 345 6789',
            'items' => [
                [
                    'order_item_id' => 1,
                    'product_id' => 1,
                    'quantity' => 2,
                    'price_at_purchase' => 450.00,
                    'product_name' => 'Organic Fertilizer Premium',
                    'image_url' => 'public_images/product_1759848029_68e5265d2187f.png'
                ],
                [
                    'order_item_id' => 2,
                    'product_id' => 2,
                    'quantity' => 1,
                    'price_at_purchase' => 350.00,
                    'product_name' => 'Organic Soil Mix',
                    'image_url' => 'public_images/product_1759850082_68e52e622823c.png'
                ]
            ]
        ];
        
        // Customize details based on order ID
        switch ($order_id) {
            case 8:
                $orderDetails['firstName'] = 'Juan';
                $orderDetails['lastName'] = 'Dela Cruz';
                $orderDetails['email'] = 'juan.delacruz@email.com';
                $orderDetails['phoneNumber'] = '+63 912 345 6789';
                $orderDetails['total_amount'] = 1250.00;
                $orderDetails['status'] = 'Pending';
                break;
            case 9:
                $orderDetails['firstName'] = 'Maria';
                $orderDetails['lastName'] = 'Santos';
                $orderDetails['email'] = 'maria.santos@email.com';
                $orderDetails['phoneNumber'] = '+63 917 654 3210';
                $orderDetails['total_amount'] = 850.00;
                $orderDetails['status'] = 'Processing';
                $orderDetails['delivery_method'] = 'Pickup';
                break;
            case 10:
                $orderDetails['firstName'] = 'Pedro';
                $orderDetails['lastName'] = 'Garcia';
                $orderDetails['email'] = 'pedro.garcia@email.com';
                $orderDetails['phoneNumber'] = '+63 918 765 4321';
                $orderDetails['total_amount'] = 2100.00;
                $orderDetails['status'] = 'Shipped';
                break;
            case 11:
                $orderDetails['firstName'] = 'Ana';
                $orderDetails['lastName'] = 'Rodriguez';
                $orderDetails['email'] = 'ana.rodriguez@email.com';
                $orderDetails['phoneNumber'] = '+63 919 876 5432';
                $orderDetails['total_amount'] = 1750.00;
                $orderDetails['status'] = 'Pending';
                break;
            case 12:
                $orderDetails['firstName'] = 'Carlos';
                $orderDetails['lastName'] = 'Lopez';
                $orderDetails['email'] = 'carlos.lopez@email.com';
                $orderDetails['phoneNumber'] = '+63 920 987 6543';
                $orderDetails['total_amount'] = 950.00;
                $orderDetails['status'] = 'Completed';
                $orderDetails['delivery_method'] = 'Pickup';
                break;
            default:
                // For any other order ID, use generic data
                $orderDetails['firstName'] = 'Test';
                $orderDetails['lastName'] = 'Customer';
                $orderDetails['email'] = 'test@example.com';
                $orderDetails['phoneNumber'] = '+63 912 345 6789';
                $orderDetails['total_amount'] = 1500.00;
                $orderDetails['status'] = 'Pending';
                break;
        }
        
        echo json_encode(['success' => true, 'order' => $orderDetails]);
        break;
        
    case 'update_order_status':
        $order_id = (int)($_POST['order_id'] ?? 0);
        $new_status = trim($_POST['status'] ?? '');
        
        if ($order_id <= 0 || empty($new_status)) {
            echo json_encode(['success' => false, 'message' => 'Valid order ID and status are required.']);
            break;
        }
        
        // Mock successful update
        echo json_encode(['success' => true, 'message' => 'Order status updated successfully.']);
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action specified']);
        break;
}
?>