<?php
// Debug API V3 step by step
header('Content-Type: text/plain');

echo "Debugging API V3 Step by Step...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Find an order to test with
    $order_stmt = $conn->prepare("SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number FROM orders o LEFT JOIN users u ON o.user_id = u.user_id WHERE o.status NOT IN ('Completed', 'Cancelled') ORDER BY o.order_id DESC LIMIT 1");
    $order_stmt->execute();
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "No active orders found for testing!\n";
        echo "Let's test with a completed order instead...\n\n";
        
        $order_stmt = $conn->prepare("SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number FROM orders o LEFT JOIN users u ON o.user_id = u.user_id WHERE o.status = 'Completed' ORDER BY o.order_id DESC LIMIT 1");
        $order_stmt->execute();
        $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo "No orders found at all!\n";
            exit;
        }
    }
    
    echo "Test order found:\n";
    echo "- Order ID: {$order['order_id']}\n";
    echo "- Status: {$order['status']}\n";
    echo "- Customer: {$order['firstName']} {$order['lastName']}\n";
    echo "- Total: {$order['total_amount']}\n\n";
    
    // Step 1: Check if order already exists in transactions
    echo "=== STEP 1: CHECK EXISTING TRANSACTION ===\n";
    $check_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $check_trans_stmt->execute([$order['order_id']]);
    $existing_transaction = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_transaction) {
        echo "✅ Order already exists in transactions table:\n";
        echo "- Transaction ID: {$existing_transaction['transaction_id']}\n";
        echo "- Amount: {$existing_transaction['amount']}\n";
        echo "- Customer: {$existing_transaction['customer_name']}\n";
        echo "This order was already transferred successfully.\n\n";
    } else {
        echo "❌ Order NOT found in transactions table\n\n";
        
        // Step 2: Test the transfer logic manually
        echo "=== STEP 2: TEST TRANSFER LOGIC MANUALLY ===\n";
        
        // Get order items
        $items_stmt = $conn->prepare("
            SELECT oi.*, p.product_name 
            FROM order_items oi 
            LEFT JOIN products p ON oi.product_id = p.product_id 
            WHERE oi.order_id = ?
        ");
        $items_stmt->execute([$order['order_id']]);
        $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "Order items found: " . count($items) . " items\n";
        foreach ($items as $item) {
            echo "- {$item['product_name']}: {$item['quantity']} x {$item['price_at_purchase']}\n";
        }
        echo "\n";
        
        // Test creating transactions table
        echo "=== STEP 3: TEST TRANSACTIONS TABLE ===\n";
        $create_table_sql = "
            CREATE TABLE IF NOT EXISTS transactions (
                transaction_id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                user_id INT NOT NULL,
                customer_name VARCHAR(255),
                customer_email VARCHAR(255),
                customer_contact VARCHAR(20),
                delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
                payment_method VARCHAR(50) NOT NULL,
                shipping_address TEXT,
                subtotal DECIMAL(10,2) NOT NULL,
                delivery_fee DECIMAL(10,2) NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                created_at DATETIME NOT NULL,
                items JSON,
                INDEX idx_user_id (user_id),
                INDEX idx_created_at (created_at)
            )
        ";
        
        try {
            $conn->exec($create_table_sql);
            echo "✅ Transactions table created/verified\n";
        } catch (Exception $e) {
            echo "❌ Error creating transactions table: " . $e->getMessage() . "\n";
        }
        
        // Test inserting into transactions table
        echo "=== STEP 4: TEST INSERT INTO TRANSACTIONS ===\n";
        
        $customer_name = trim($order['firstName'] . ' ' . $order['lastName']);
        $items_json = json_encode($items);
        
        echo "Prepared data:\n";
        echo "- Customer Name: '$customer_name'\n";
        echo "- Email: {$order['email']}\n";
        echo "- Contact: {$order['contact_number']}\n";
        echo "- Delivery Method: {$order['delivery_method']}\n";
        echo "- Payment Method: {$order['payment_method']}\n";
        echo "- Shipping Address: {$order['shipping_address']}\n";
        echo "- Subtotal: {$order['subtotal']}\n";
        echo "- Delivery Fee: {$order['delivery_fee']}\n";
        echo "- Total Amount: {$order['total_amount']}\n";
        echo "- Items JSON: $items_json\n\n";
        
        $trans_stmt = $conn->prepare("
            INSERT INTO transactions (
                order_id, user_id, customer_name, customer_email, customer_contact,
                delivery_method, payment_method, shipping_address, subtotal, 
                delivery_fee, amount, created_at, items
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
        ");
        
        try {
            $trans_result = $trans_stmt->execute([
                $order['order_id'],
                $order['user_id'],
                $customer_name,
                $order['email'],
                $order['contact_number'],
                $order['delivery_method'],
                $order['payment_method'],
                $order['shipping_address'],
                $order['subtotal'],
                $order['delivery_fee'],
                $order['total_amount'],
                $items_json
            ]);
            
            if ($trans_result) {
                echo "✅ Successfully inserted order #{$order['order_id']} into transactions table\n";
                
                // Verify the insert
                $verify_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
                $verify_stmt->execute([$order['order_id']]);
                $verify_transaction = $verify_stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($verify_transaction) {
                    echo "✅ Verification successful - transaction found:\n";
                    echo "- Transaction ID: {$verify_transaction['transaction_id']}\n";
                    echo "- Customer: {$verify_transaction['customer_name']}\n";
                    echo "- Amount: {$verify_transaction['amount']}\n";
                } else {
                    echo "❌ Verification failed - transaction not found after insert\n";
                }
            } else {
                echo "❌ Failed to insert into transactions table\n";
                $errorInfo = $trans_stmt->errorInfo();
                echo "Error Info: " . json_encode($errorInfo) . "\n";
            }
        } catch (Exception $e) {
            echo "❌ Exception during insert: " . $e->getMessage() . "\n";
            echo "File: " . $e->getFile() . "\n";
            echo "Line: " . $e->getLine() . "\n";
        }
    }
    
    // Step 5: Test the actual API call
    echo "\n=== STEP 5: TEST ACTUAL API CALL ===\n";
    
    // Set up POST data
    $_POST = [];
    $_POST['order_id'] = $order['order_id'];
    $_POST['status'] = 'Completed';
    $_GET['action'] = 'update_order_status';
    
    echo "Making API call with: order_id={$order['order_id']}, status=Completed\n";
    
    // Capture the API response
    ob_start();
    
    // Include the API file
    include 'orders_api_v3.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Check what happened to the order after API call
    echo "=== STEP 6: CHECK RESULTS AFTER API CALL ===\n";
    
    // Check if order still exists in orders table
    $check_order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $check_order_stmt->execute([$order['order_id']]);
    $order_still_exists = $check_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_still_exists) {
        echo "❌ Order still exists in orders table:\n";
        echo "- Status: {$order_still_exists['status']}\n";
        echo "- Total: {$order_still_exists['total_amount']}\n";
    } else {
        echo "✅ Order removed from orders table\n";
    }
    
    // Check if order exists in transactions table
    $check_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $check_trans_stmt->execute([$order['order_id']]);
    $order_in_transactions = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_in_transactions) {
        echo "✅ Order found in transactions table:\n";
        echo "- Transaction ID: {$order_in_transactions['transaction_id']}\n";
        echo "- Customer: {$order_in_transactions['customer_name']}\n";
        echo "- Amount: {$order_in_transactions['amount']}\n";
        echo "- Created: {$order_in_transactions['created_at']}\n";
    } else {
        echo "❌ Order NOT found in transactions table - TRANSFER FAILED!\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
