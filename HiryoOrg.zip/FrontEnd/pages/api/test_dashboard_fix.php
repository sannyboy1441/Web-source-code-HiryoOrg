<?php
/**
 * Test Dashboard Fix
 * This script tests if the dashboard API now works correctly
 */

header('Content-Type: application/json');

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check orders table columns
    $stmt = $conn->prepare("SHOW COLUMNS FROM orders");
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['orders_table_columns'] = [
        'status' => 'INFO',
        'message' => 'Orders table columns',
        'columns' => array_column($columns, 'Field')
    ];
    
    // Test 2: Check users table columns
    $stmt = $conn->prepare("SHOW COLUMNS FROM users");
    $stmt->execute();
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['users_table_columns'] = [
        'status' => 'INFO',
        'message' => 'Users table columns',
        'columns' => array_column($columns, 'Field')
    ];
    
    // Test 3: Test dashboard API
    $dashboardUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/dashboard_api.php?action=get_dashboard_stats';
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 5
        ]
    ]);
    
    $response = @file_get_contents($dashboardUrl, false, $context);
    
    if ($response === false) {
        $testResults['tests']['dashboard_api'] = [
            'status' => 'FAIL',
            'message' => 'Dashboard API request failed',
            'url' => $dashboardUrl
        ];
    } else {
        $data = json_decode($response, true);
        $testResults['tests']['dashboard_api'] = [
            'status' => $data && isset($data['success']) && $data['success'] ? 'PASS' : 'FAIL',
            'message' => $data && isset($data['success']) && $data['success'] ? 'Dashboard API working' : 'Dashboard API error: ' . ($data['message'] ?? 'Unknown error'),
            'url' => $dashboardUrl,
            'response' => $data
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'dashboard_api_working' => isset($testResults['tests']['dashboard_api']) && $testResults['tests']['dashboard_api']['status'] === 'PASS'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'dashboard_fix',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
