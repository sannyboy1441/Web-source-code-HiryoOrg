<?php
/**
 * Test Database Connection
 */

header('Content-Type: application/json');

// Test multiple paths for datab_try.php
$possible_paths = [
    '../datab_try.php',
    '../../datab_try.php',
    __DIR__ . '/../datab_try.php',
    __DIR__ . '/../../datab_try.php'
];

$connection_success = false;
$connection_details = [];

foreach ($possible_paths as $path) {
    if (file_exists($path)) {
        try {
            include_once $path;
            
            if (function_exists('getDBConnection')) {
                $conn = getDBConnection();
                if ($conn) {
                    // Test a simple query
                    $stmt = $conn->query("SELECT COUNT(*) as count FROM users");
                    $result = $stmt->fetch();
                    
                    $connection_success = true;
                    $connection_details = [
                        'success' => true,
                        'path_used' => $path,
                        'user_count' => $result['count'],
                        'connection_status' => 'Working'
                    ];
                    break;
                }
            }
        } catch (Exception $e) {
            $connection_details = [
                'success' => false,
                'path_tested' => $path,
                'error' => $e->getMessage()
            ];
        }
    }
}

if (!$connection_success) {
    $connection_details = [
        'success' => false,
        'error' => 'Could not establish database connection',
        'paths_tested' => $possible_paths
    ];
}

echo json_encode([
    'database_connection_test' => $connection_details,
    'server_info' => [
        'document_root' => $_SERVER['DOCUMENT_ROOT'],
        'script_dir' => __DIR__,
        'php_version' => PHP_VERSION,
        'current_time' => date('Y-m-d H:i:s')
    ]
], JSON_PRETTY_PRINT);
?>
