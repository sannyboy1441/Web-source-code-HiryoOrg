<?php
/**
 * Test Products CRUD Operations
 * This script tests if products API is working correctly for add, edit, delete
 */

header('Content-Type: application/json');

// Test configuration
$testResults = [
    'timestamp' => date('Y-m-d H:i:s'),
    'tests' => []
];

// Test 1: Check if products_api.php exists
$apiPath = __DIR__ . '/products_api.php';
$testResults['tests']['api_file_exists'] = [
    'status' => file_exists($apiPath) ? 'PASS' : 'FAIL',
    'message' => file_exists($apiPath) ? 'products_api.php exists' : 'products_api.php not found',
    'path' => $apiPath
];

// Test 2: Try to get products
try {
    $url = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_products_for_admin';
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 5
        ]
    ]);
    
    $response = @file_get_contents($url, false, $context);
    
    if ($response === false) {
        $testResults['tests']['get_products'] = [
            'status' => 'FAIL',
            'message' => 'Failed to fetch products',
            'url' => $url
        ];
    } else {
        $data = json_decode($response, true);
        $testResults['tests']['get_products'] = [
            'status' => $data && isset($data['success']) && $data['success'] ? 'PASS' : 'FAIL',
            'message' => $data && isset($data['success']) && $data['success'] ? 'Successfully fetched ' . count($data['products'] ?? []) . ' products' : 'API returned error',
            'url' => $url,
            'response' => $data
        ];
    }
} catch (Exception $e) {
    $testResults['tests']['get_products'] = [
        'status' => 'FAIL',
        'message' => 'Exception: ' . $e->getMessage()
    ];
}

// Test 3: Check database connection
try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if ($conn) {
        // Test query
        $stmt = $conn->query("SELECT COUNT(*) as count FROM products WHERE status = 'Active'");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['database_connection'] = [
            'status' => 'PASS',
            'message' => 'Database connected successfully',
            'active_products_count' => $result['count']
        ];
    } else {
        $testResults['tests']['database_connection'] = [
            'status' => 'FAIL',
            'message' => 'Failed to connect to database'
        ];
    }
} catch (Exception $e) {
    $testResults['tests']['database_connection'] = [
        'status' => 'FAIL',
        'message' => 'Database error: ' . $e->getMessage()
    ];
}

// Summary
$passCount = 0;
$failCount = 0;
foreach ($testResults['tests'] as $test) {
    if ($test['status'] === 'PASS') {
        $passCount++;
    } else {
        $failCount++;
    }
}

$testResults['summary'] = [
    'total_tests' => count($testResults['tests']),
    'passed' => $passCount,
    'failed' => $failCount,
    'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌'
];

echo json_encode($testResults, JSON_PRETTY_PRINT);
?>

