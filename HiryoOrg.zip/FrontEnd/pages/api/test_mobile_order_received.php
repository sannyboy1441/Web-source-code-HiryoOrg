<?php
/**
 * Test script for mobile app order received functionality
 */

header('Content-Type: application/json');

require_once '../datab_try.php';

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Test data - simulate mobile app request
    $_POST['action'] = 'update_order_status';
    $_POST['order_id'] = 26; // Order #26 from the screenshot
    $_POST['status'] = 'Completed';
    
    echo "Testing mobile app order received functionality...\n\n";
    
    // Check if order exists
    $checkStmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $checkStmt->execute([$_POST['order_id']]);
    $order = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit;
    }
    
    echo "Order found: " . json_encode($order, JSON_PRETTY_PRINT) . "\n\n";
    
    // Test the update
    echo "Testing status update...\n";
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    $result = $stmt->execute([$_POST['status'], $_POST['order_id']]);
    
    if ($result) {
        echo "Status update successful\n";
        
        // Check if order still exists
        $checkStmt->execute([$_POST['order_id']]);
        $updatedOrder = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($updatedOrder) {
            echo "Order still exists with status: " . $updatedOrder['status'] . "\n";
        } else {
            echo "Order was moved to transactions table\n";
        }
        
        echo json_encode(['success' => true, 'message' => 'Order marked as completed successfully']);
    } else {
        echo "Status update failed\n";
        echo json_encode(['success' => false, 'message' => 'Failed to update order status']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
