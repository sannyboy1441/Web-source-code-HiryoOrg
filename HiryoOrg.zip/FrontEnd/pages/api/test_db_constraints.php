<?php
/**
 * Test Database Constraints
 * This script tests database constraints that might be causing SQLSTATE[23000]
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'constraint_tests' => []
    ];
    
    // Test 1: Check if user_id 1 exists and is valid
    $stmt = $conn->prepare("SELECT user_id, username, email, roles FROM users WHERE user_id = 1");
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $testResults['constraint_tests']['user_constraint'] = [
        'user_id' => 1,
        'exists' => $user ? true : false,
        'user_data' => $user,
        'can_reference' => $user ? 'YES' : 'NO'
    ];
    
    // Test 2: Check if product_id 46 exists and is valid
    $stmt = $conn->prepare("SELECT product_id, product_name, price, status FROM products WHERE product_id = 46");
    $stmt->execute();
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $testResults['constraint_tests']['product_constraint'] = [
        'product_id' => 46,
        'exists' => $product ? true : false,
        'product_data' => $product,
        'can_reference' => $product ? 'YES' : 'NO'
    ];
    
    // Test 3: Check notifications table structure and constraints
    $stmt = $conn->prepare("DESCRIBE notifications");
    $stmt->execute();
    $notificationsStructure = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['constraint_tests']['notifications_table'] = [
        'structure' => $notificationsStructure,
        'has_user_id_constraint' => false,
        'has_order_id_constraint' => false
    ];
    
    // Check for foreign key constraints
    foreach ($notificationsStructure as $column) {
        if ($column['Field'] === 'user_id') {
            $testResults['constraint_tests']['notifications_table']['has_user_id_constraint'] = true;
        }
        if ($column['Field'] === 'order_id') {
            $testResults['constraint_tests']['notifications_table']['has_order_id_constraint'] = true;
        }
    }
    
    // Test 4: Try to insert a test notification to see what constraints exist
    try {
        $stmt = $conn->prepare("
            INSERT INTO notifications (user_id, order_id, title, message, type, is_read, created_at) 
            VALUES (?, ?, ?, ?, ?, 0, NOW())
        ");
        $result = $stmt->execute([1, 999, 'Test Notification', 'This is a test', 'test']);
        
        $testResults['constraint_tests']['notification_insert_test'] = [
            'success' => $result,
            'message' => 'Test notification inserted successfully'
        ];
        
        // Clean up test notification
        $stmt = $conn->prepare("DELETE FROM notifications WHERE order_id = 999 AND type = 'test'");
        $stmt->execute();
        
    } catch (Exception $e) {
        $testResults['constraint_tests']['notification_insert_test'] = [
            'success' => false,
            'error' => $e->getMessage(),
            'constraint_violation' => strpos($e->getMessage(), 'SQLSTATE[23000]') !== false
        ];
    }
    
    // Test 5: Check if there are any admin users
    $stmt = $conn->prepare("SELECT user_id, username, roles FROM users WHERE roles = 'admin'");
    $stmt->execute();
    $adminUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['constraint_tests']['admin_users'] = [
        'count' => count($adminUsers),
        'users' => $adminUsers,
        'has_admin' => count($adminUsers) > 0
    ];
    
    // Test 6: Check orders table structure
    $stmt = $conn->prepare("DESCRIBE orders");
    $stmt->execute();
    $ordersStructure = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['constraint_tests']['orders_table_structure'] = $ordersStructure;
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
