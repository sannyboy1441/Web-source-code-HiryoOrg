<?php
// Test API V3 with a fresh order
header('Content-Type: text/plain');

echo "Testing API V3 with Fresh Order...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Find an order that's NOT completed
    $order_stmt = $conn->prepare("SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number FROM orders o LEFT JOIN users u ON o.user_id = u.user_id WHERE o.status NOT IN ('Completed', 'Cancelled') ORDER BY o.order_id DESC LIMIT 1");
    $order_stmt->execute();
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "No active orders found for testing!\n";
        echo "Creating a test order...\n\n";
        
        // Get a user to create order for
        $user_stmt = $conn->prepare("SELECT user_id, firstName, lastName, email FROM users LIMIT 1");
        $user_stmt->execute();
        $user = $user_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            echo "❌ No users found to create test order!\n";
            exit;
        }
        
        echo "Creating test order for user: {$user['firstName']} {$user['lastName']}\n";
        
        // Create test order
        $create_order_stmt = $conn->prepare("
            INSERT INTO orders (user_id, status, total_amount, subtotal, delivery_fee, payment_method, delivery_method, shipping_address, order_date) 
            VALUES (?, 'Pending', 100.00, 90.00, 10.00, 'COD', 'Delivery', 'Test Address', NOW())
        ");
        $create_order_stmt->execute([$user['user_id']]);
        $test_order_id = $conn->lastInsertId();
        
        echo "✅ Test order created with ID: $test_order_id\n\n";
        
        // Create test order items
        $product_stmt = $conn->prepare("SELECT product_id, product_name, price FROM products LIMIT 1");
        $product_stmt->execute();
        $product = $product_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($product) {
            $create_item_stmt = $conn->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) 
                VALUES (?, ?, 1, ?)
            ");
            $create_item_stmt->execute([$test_order_id, $product['product_id'], $product['price']]);
            echo "✅ Test order item created for product: {$product['product_name']}\n";
        }
        
        // Get the created order
        $order_stmt = $conn->prepare("SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number FROM orders o LEFT JOIN users u ON o.user_id = u.user_id WHERE o.order_id = ?");
        $order_stmt->execute([$test_order_id]);
        $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    echo "Test order found:\n";
    echo "- Order ID: {$order['order_id']}\n";
    echo "- Status: {$order['status']}\n";
    echo "- Customer: {$order['firstName']} {$order['lastName']}\n";
    echo "- Total: {$order['total_amount']}\n\n";
    
    // Test the API call
    echo "=== TESTING API V3 ===\n";
    
    // Set up POST data
    $_POST = [];
    $_POST['order_id'] = $order['order_id'];
    $_POST['status'] = 'Completed';
    $_GET['action'] = 'update_order_status';
    
    echo "Making API call with: order_id={$order['order_id']}, status=Completed\n";
    
    // Capture the API response
    ob_start();
    
    // Include the API file
    include 'orders_api_v3.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Check what happened to the order
    echo "=== CHECKING RESULTS ===\n";
    
    // Check if order still exists in orders table
    $check_order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $check_order_stmt->execute([$order['order_id']]);
    $order_still_exists = $check_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_still_exists) {
        echo "❌ Test order still exists in orders table:\n";
        echo "- Status: {$order_still_exists['status']}\n";
        echo "- Total: {$order_still_exists['total_amount']}\n";
    } else {
        echo "✅ Test order removed from orders table\n";
    }
    
    // Check if order exists in transactions table
    $check_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $check_trans_stmt->execute([$order['order_id']]);
    $order_in_transactions = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_in_transactions) {
        echo "✅ Test order successfully transferred to transactions table:\n";
        echo "- Transaction ID: {$order_in_transactions['transaction_id']}\n";
        echo "- Customer: {$order_in_transactions['customer_name']}\n";
        echo "- Amount: {$order_in_transactions['amount']}\n";
        echo "- Created: {$order_in_transactions['created_at']}\n";
    } else {
        echo "❌ Test order NOT found in transactions table - TRANSFER FAILED!\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if (!$order_still_exists && $order_in_transactions) {
        echo "🎉 SUCCESS: API V3 is working perfectly!\n";
        echo "✅ Test order removed from orders table\n";
        echo "✅ Test order transferred to transactions table\n";
        echo "✅ Order completion process is fully functional\n";
    } else {
        echo "❌ FAILURE: API V3 still has issues!\n";
        echo "❌ Order completion process needs further debugging\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
