<?php
/**
 * Check if orders_api.php has the correct content
 */

header('Content-Type: application/json');

try {
    $ordersApiPath = 'orders_api.php';
    
    if (!file_exists($ordersApiPath)) {
        echo json_encode([
            'success' => false,
            'message' => 'orders_api.php file not found'
        ]);
        exit;
    }
    
    $content = file_get_contents($ordersApiPath);
    
    // Check for the fixed column reference
    $hasCorrectColumn = strpos($content, 'u.contact_number as contact_number') !== false;
    $hasOldColumn = strpos($content, 'u.phoneNumber') !== false;
    
    // Check for enhanced error reporting
    $hasEnhancedError = strpos($content, 'error_details') !== false;
    
    // Check for the global error handler fix
    $hasGlobalErrorFix = strpos($content, 'Server error occurred:') !== false;
    
    echo json_encode([
        'success' => true,
        'message' => 'orders_api.php file found',
        'file_size' => strlen($content),
        'checks' => [
            'has_correct_column' => $hasCorrectColumn,
            'has_old_column' => $hasOldColumn,
            'has_enhanced_error' => $hasEnhancedError,
            'has_global_error_fix' => $hasGlobalErrorFix
        ],
        'file_exists' => true,
        'readable' => is_readable($ordersApiPath)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error checking file: ' . $e->getMessage()
    ]);
}
?>
