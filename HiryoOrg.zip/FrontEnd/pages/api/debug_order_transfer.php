<?php
// Debug script to test order transfer to transactions
try {
    require_once '../../BackEnd/back_end_files.php';
} catch (Exception $e) {
    echo "Error loading back_end_files.php: " . $e->getMessage() . "\n";
    exit;
}

echo "Debugging Order Transfer to Transactions...\n\n";

// Check if database connection exists
if (!isset($conn) || !$conn) {
    echo "Database connection not available!\n";
    exit;
}

try {
    // Test with a specific order ID - you can change this
    $test_order_id = 29; // Change this to the order ID you want to test
    
    echo "Testing Order #$test_order_id...\n";
    
    // Check if order exists
    $order_stmt = $conn->prepare("
        SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_id = ?
    ");
    $order_stmt->execute([$test_order_id]);
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "Order #$test_order_id not found!\n";
        exit;
    }
    
    echo "Order found: " . json_encode($order, JSON_PRETTY_PRINT) . "\n\n";
    
    // Check current status
    echo "Current status: " . $order['status'] . "\n";
    
    // Get order items
    $items_stmt = $conn->prepare("
        SELECT oi.*, p.product_name 
        FROM order_items oi 
        LEFT JOIN products p ON oi.product_id = p.product_id 
        WHERE oi.order_id = ?
    ");
    $items_stmt->execute([$test_order_id]);
    $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Order items: " . json_encode($items, JSON_PRETTY_PRINT) . "\n\n";
    
    // Check if transactions table exists
    $table_check = $conn->query("SHOW TABLES LIKE 'transactions'");
    if ($table_check->rowCount() == 0) {
        echo "Transactions table does not exist. Creating...\n";
        $create_table_sql = "
            CREATE TABLE transactions (
                transaction_id INT AUTO_INCREMENT PRIMARY KEY,
                order_id INT NOT NULL,
                user_id INT NOT NULL,
                customer_name VARCHAR(255),
                customer_email VARCHAR(255),
                customer_contact VARCHAR(20),
                delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
                payment_method VARCHAR(50) NOT NULL,
                shipping_address TEXT,
                subtotal DECIMAL(10,2) NOT NULL,
                delivery_fee DECIMAL(10,2) NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                created_at DATETIME NOT NULL,
                items JSON,
                INDEX idx_user_id (user_id),
                INDEX idx_created_at (created_at)
            )
        ";
        $conn->exec($create_table_sql);
        echo "Transactions table created.\n\n";
    } else {
        echo "Transactions table exists.\n\n";
    }
    
    // Check if order already exists in transactions
    $trans_check = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $trans_check->execute([$test_order_id]);
    $existing_transaction = $trans_check->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_transaction) {
        echo "Order already exists in transactions: " . json_encode($existing_transaction, JSON_PRETTY_PRINT) . "\n";
    } else {
        echo "Order not found in transactions table.\n";
    }
    
    // Test the transfer process
    echo "\nTesting transfer process...\n";
    
    if ($order && !$existing_transaction) {
        // Insert into transactions table
        $trans_stmt = $conn->prepare("
            INSERT INTO transactions (
                order_id, user_id, customer_name, customer_email, customer_contact,
                delivery_method, payment_method, shipping_address, subtotal, 
                delivery_fee, amount, created_at, items
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
        ");
        
        $customer_name = trim($order['firstName'] . ' ' . $order['lastName']);
        $items_json = json_encode($items);
        
        echo "Customer name: $customer_name\n";
        echo "Items JSON: $items_json\n";
        echo "Total amount: " . $order['total_amount'] . "\n";
        
        $result = $trans_stmt->execute([
            $test_order_id,
            $order['user_id'],
            $customer_name,
            $order['email'],
            $order['contact_number'],
            $order['delivery_method'],
            $order['payment_method'],
            $order['shipping_address'],
            $order['subtotal'],
            $order['delivery_fee'],
            $order['total_amount'],
            $items_json
        ]);
        
        if ($result) {
            echo "✅ Successfully inserted into transactions table!\n";
            
            // Now delete from orders table
            $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $delete_result = $delete_stmt->execute([$test_order_id]);
            
            if ($delete_result) {
                echo "✅ Successfully deleted from orders table!\n";
            } else {
                echo "❌ Failed to delete from orders table!\n";
            }
            
            // Delete order items
            $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $delete_items_result = $delete_items_stmt->execute([$test_order_id]);
            
            if ($delete_items_result) {
                echo "✅ Successfully deleted from order_items table!\n";
            } else {
                echo "❌ Failed to delete from order_items table!\n";
            }
            
        } else {
            echo "❌ Failed to insert into transactions table!\n";
            $errorInfo = $trans_stmt->errorInfo();
            echo "Error: " . json_encode($errorInfo) . "\n";
        }
    }
    
    echo "\n=== Final Check ===\n";
    
    // Check if order still exists in orders table
    $final_order_check = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $final_order_check->execute([$test_order_id]);
    $final_order = $final_order_check->fetch(PDO::FETCH_ASSOC);
    
    if ($final_order) {
        echo "Order still exists in orders table: " . json_encode($final_order, JSON_PRETTY_PRINT) . "\n";
    } else {
        echo "Order no longer exists in orders table.\n";
    }
    
    // Check if order exists in transactions table
    $final_trans_check = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $final_trans_check->execute([$test_order_id]);
    $final_transaction = $final_trans_check->fetch(PDO::FETCH_ASSOC);
    
    if ($final_transaction) {
        echo "Order exists in transactions table: " . json_encode($final_transaction, JSON_PRETTY_PRINT) . "\n";
    } else {
        echo "Order not found in transactions table.\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
