<?php
// Verify the final fix is working
header('Content-Type: text/plain');

echo "Verifying Final Fix Results...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Check orders table
    echo "=== ORDERS TABLE ===\n";
    $orders_stmt = $conn->prepare("SELECT order_id, status, total_amount, order_date FROM orders ORDER BY order_id DESC LIMIT 10");
    $orders_stmt->execute();
    $orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "✅ No orders found in orders table - All orders have been processed!\n";
    } else {
        echo "Active orders found:\n";
        foreach ($orders as $order) {
            echo "- Order #{$order['order_id']}: Status = {$order['status']}, Total = ₱{$order['total_amount']}, Date = {$order['order_date']}\n";
        }
    }
    echo "\n";
    
    // Check transactions table
    echo "=== TRANSACTIONS TABLE ===\n";
    $transactions_stmt = $conn->prepare("SELECT transaction_id, order_id, customer_name, amount, created_at FROM transactions ORDER BY transaction_id DESC LIMIT 10");
    $transactions_stmt->execute();
    $transactions = $transactions_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($transactions)) {
        echo "❌ No transactions found in transactions table!\n";
    } else {
        echo "Completed transactions found:\n";
        foreach ($transactions as $transaction) {
            echo "- Transaction #{$transaction['transaction_id']}: Order #{$transaction['order_id']}, Customer = {$transaction['customer_name']}, Amount = ₱{$transaction['amount']}, Date = {$transaction['created_at']}\n";
        }
    }
    echo "\n";
    
    // Summary
    echo "=== SUMMARY ===\n";
    $orders_count = count($orders);
    $transactions_count = count($transactions);
    
    echo "Orders table: $orders_count active orders\n";
    echo "Transactions table: $transactions_count completed transactions\n\n";
    
    if ($orders_count === 0 && $transactions_count > 0) {
        echo "🎉 SUCCESS: Fix is working perfectly!\n";
        echo "✅ All orders have been transferred to transactions table\n";
        echo "✅ No active orders remaining in orders table\n";
        echo "✅ Order completion process is working correctly\n";
        echo "✅ Web admin will show 'No orders found' (correct behavior)\n";
    } elseif ($orders_count > 0 && $transactions_count > 0) {
        echo "✅ PARTIAL SUCCESS: Some orders transferred, some still active\n";
        echo "✅ Order completion process is working\n";
        echo "ℹ️  Active orders are waiting to be completed\n";
    } elseif ($orders_count > 0 && $transactions_count === 0) {
        echo "⚠️  ISSUE: Orders exist but none have been transferred yet\n";
        echo "❌ Order completion process may not be working\n";
    } else {
        echo "🤔 UNEXPECTED: No orders and no transactions found\n";
        echo "ℹ️  Database might be empty or there's a connection issue\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
