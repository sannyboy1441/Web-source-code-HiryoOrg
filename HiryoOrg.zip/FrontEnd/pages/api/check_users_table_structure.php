<?php
/**
 * Check Users Table Structure
 * This script checks the actual structure of the users table
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }
    
    $results = [
        'timestamp' => date('Y-m-d H:i:s'),
        'table_info' => []
    ];
    
    // Check users table structure
    $stmt = $conn->prepare("DESCRIBE users");
    $stmt->execute();
    $usersStructure = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $results['table_info']['users_table_structure'] = $usersStructure;
    
    // Check if user_id 1 exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = 1");
    $stmt->execute();
    $user1 = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $results['table_info']['user_1_exists'] = $user1 ? true : false;
    $results['table_info']['user_1_data'] = $user1;
    
    // Check if any admin users exist
    $stmt = $conn->prepare("SELECT * FROM users WHERE roles = 'admin'");
    $stmt->execute();
    $adminUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $results['table_info']['admin_users'] = $adminUsers;
    
    // Get all users
    $stmt = $conn->prepare("SELECT user_id, username, email, roles, status FROM users ORDER BY user_id");
    $stmt->execute();
    $allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $results['table_info']['all_users'] = $allUsers;
    
    echo json_encode($results, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
