<?php
// Fix missing transactions by transferring completed orders
header('Content-Type: text/plain');

echo "=== FIXING MISSING TRANSACTIONS ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Find completed/cancelled orders not in transactions
    echo "=== FINDING MISSING TRANSACTIONS ===\n";
    $missing_stmt = $conn->prepare("
        SELECT o.order_id, o.status, o.total_amount, o.order_date
        FROM orders o
        LEFT JOIN transactions t ON o.order_id = t.order_id
        WHERE o.status IN ('Completed', 'Cancelled') AND t.order_id IS NULL
        ORDER BY o.order_id DESC
    ");
    $missing_stmt->execute();
    $missing_orders = $missing_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($missing_orders)) {
        echo "✅ No missing transactions found!\n";
        exit;
    }
    
    echo "Found " . count($missing_orders) . " completed/cancelled orders not in transactions:\n";
    foreach ($missing_orders as $order) {
        echo "   - Order #{$order['order_id']}: {$order['status']}, Amount: {$order['total_amount']}\n";
    }
    
    echo "\n=== TRANSFERRING MISSING ORDERS ===\n";
    
    foreach ($missing_orders as $order_data) {
        $order_id = $order_data['order_id'];
        echo "\nProcessing Order #{$order_id}...\n";
        
        // Get full order details
        $order_stmt = $conn->prepare("
            SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number, u.address
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.user_id
            WHERE o.order_id = ?
        ");
        $order_stmt->execute([$order_id]);
        $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo "   ❌ Order #{$order_id} not found!\n";
            continue;
        }
        
        // Get order items
        $items_stmt = $conn->prepare("
            SELECT oi.*, p.product_name
            FROM order_items oi
            LEFT JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = ?
        ");
        $items_stmt->execute([$order_id]);
        $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "   ✅ Found " . count($items) . " order items\n";
        
        // Insert into transactions table
        $trans_stmt = $conn->prepare("
            INSERT INTO transactions (
                order_id, user_id, customer_name, customer_email, customer_contact,
                delivery_method, payment_method, shipping_address, subtotal,
                delivery_fee, amount, created_at, items
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
        ");
        
        $customer_name = trim(($order['firstName'] ?? '') . ' ' . ($order['lastName'] ?? ''));
        $items_json = json_encode($items);
        
        $trans_result = $trans_stmt->execute([
            $order_id,
            $order['user_id'],
            $customer_name,
            $order['email'],
            $order['contact_number'],
            $order['delivery_method'],
            $order['payment_method'],
            $order['shipping_address'],
            $order['subtotal'],
            $order['delivery_fee'],
            $order['total_amount'],
            $items_json
        ]);
        
        if ($trans_result) {
            $transaction_id = $conn->lastInsertId();
            echo "   ✅ Order #{$order_id} transferred to transactions table (Transaction ID: {$transaction_id})\n";
            
            // Delete order items
            $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $delete_items_stmt->execute([$order_id]);
            echo "   ✅ Deleted order items for Order #{$order_id}\n";
            
            // Delete from orders table
            $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $delete_stmt->execute([$order_id]);
            echo "   ✅ Deleted Order #{$order_id} from orders table\n";
            
        } else {
            echo "   ❌ Failed to transfer Order #{$order_id} to transactions table\n";
        }
    }
    
    // Final verification
    echo "\n=== FINAL VERIFICATION ===\n";
    $final_missing_stmt = $conn->prepare("
        SELECT o.order_id, o.status
        FROM orders o
        LEFT JOIN transactions t ON o.order_id = t.order_id
        WHERE o.status IN ('Completed', 'Cancelled') AND t.order_id IS NULL
    ");
    $final_missing_stmt->execute();
    $final_missing = $final_missing_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($final_missing)) {
        echo "🎉 SUCCESS: All completed/cancelled orders have been transferred!\n";
    } else {
        echo "❌ Still " . count($final_missing) . " orders missing from transactions:\n";
        foreach ($final_missing as $order) {
            echo "   - Order #{$order['order_id']}: {$order['status']}\n";
        }
    }
    
    // Show final counts
    $orders_count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders");
    $orders_count_stmt->execute();
    $orders_count = $orders_count_stmt->fetch(PDO::FETCH_ASSOC);
    
    $trans_count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $trans_count_stmt->execute();
    $trans_count = $trans_count_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "\n=== FINAL COUNTS ===\n";
    echo "Orders in orders table: {$orders_count['count']}\n";
    echo "Transactions in transactions table: {$trans_count['count']}\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
