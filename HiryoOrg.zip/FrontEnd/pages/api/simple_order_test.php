<?php
// Simple test for order completion
header('Content-Type: text/plain');

echo "Simple Order Completion Test...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // First, let's see what orders exist
    echo "Checking available orders...\n";
    $all_orders_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders ORDER BY order_id DESC LIMIT 10");
    $all_orders_stmt->execute();
    $all_orders = $all_orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($all_orders)) {
        echo "No orders found in the database!\n";
        exit;
    }
    
    echo "Available orders:\n";
    foreach ($all_orders as $order_info) {
        echo "- Order #{$order_info['order_id']}: Status = {$order_info['status']}, Total = {$order_info['total_amount']}\n";
    }
    echo "\n";
    
    // Find a suitable order to test with (preferably one with "Delivered" status)
    $test_order = null;
    foreach ($all_orders as $order_info) {
        if ($order_info['status'] === 'Delivered') {
            $test_order = $order_info;
            break;
        }
    }
    
    // If no delivered orders, use the first available order
    if (!$test_order) {
        $test_order = $all_orders[0];
    }
    
    $order_id = $test_order['order_id'];
    
    echo "Testing with Order #$order_id (Status: {$test_order['status']})...\n";
    
    // Step 1: Check if order exists
    echo "Step 1: Checking if order exists...\n";
    $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "Order #$order_id not found!\n";
        exit;
    }
    
    echo "Order found - Status: " . $order['status'] . "\n\n";
    
    // Step 2: Update status to Completed
    echo "Step 2: Updating status to Completed...\n";
    $update_stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    $result = $update_stmt->execute(['Completed', $order_id]);
    
    if ($result) {
        echo "Status updated successfully!\n\n";
    } else {
        echo "Failed to update status!\n";
        exit;
    }
    
    // Step 3: Check if transactions table exists
    echo "Step 3: Checking transactions table...\n";
    $table_check = $conn->query("SHOW TABLES LIKE 'transactions'");
    if ($table_check->rowCount() == 0) {
        echo "Creating transactions table...\n";
        $create_sql = "CREATE TABLE transactions (
            transaction_id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            user_id INT NOT NULL,
            customer_name VARCHAR(255),
            customer_email VARCHAR(255),
            customer_contact VARCHAR(20),
            delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
            payment_method VARCHAR(50) NOT NULL,
            shipping_address TEXT,
            subtotal DECIMAL(10,2) NOT NULL,
            delivery_fee DECIMAL(10,2) NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            created_at DATETIME NOT NULL,
            items JSON
        )";
        $conn->exec($create_sql);
        echo "Transactions table created!\n\n";
    } else {
        echo "Transactions table exists.\n\n";
    }
    
    // Step 4: Get order details with user info
    echo "Step 4: Getting order details...\n";
    $order_stmt = $conn->prepare("
        SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        WHERE o.order_id = ?
    ");
    $order_stmt->execute([$order_id]);
    $order_details = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order_details) {
        echo "Failed to get order details!\n";
        exit;
    }
    
    echo "Order details retrieved:\n";
    echo "Customer: " . $order_details['firstName'] . " " . $order_details['lastName'] . "\n";
    echo "Email: " . $order_details['email'] . "\n";
    echo "Total: " . $order_details['total_amount'] . "\n\n";
    
    // Step 5: Get order items
    echo "Step 5: Getting order items...\n";
    $items_stmt = $conn->prepare("
        SELECT oi.*, p.product_name 
        FROM order_items oi 
        LEFT JOIN products p ON oi.product_id = p.product_id 
        WHERE oi.order_id = ?
    ");
    $items_stmt->execute([$order_id]);
    $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Order items retrieved: " . count($items) . " items\n\n";
    
    // Step 6: Insert into transactions
    echo "Step 6: Inserting into transactions table...\n";
    $trans_stmt = $conn->prepare("
        INSERT INTO transactions (
            order_id, user_id, customer_name, customer_email, customer_contact,
            delivery_method, payment_method, shipping_address, subtotal, 
            delivery_fee, amount, created_at, items
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
    ");
    
    $customer_name = trim($order_details['firstName'] . ' ' . $order_details['lastName']);
    $items_json = json_encode($items);
    
    $trans_result = $trans_stmt->execute([
        $order_id,
        $order_details['user_id'],
        $customer_name,
        $order_details['email'],
        $order_details['contact_number'],
        $order_details['delivery_method'],
        $order_details['payment_method'],
        $order_details['shipping_address'],
        $order_details['subtotal'],
        $order_details['delivery_fee'],
        $order_details['total_amount'],
        $items_json
    ]);
    
    if ($trans_result) {
        echo "Successfully inserted into transactions table!\n\n";
    } else {
        echo "Failed to insert into transactions table!\n";
        $errorInfo = $trans_stmt->errorInfo();
        echo "Error: " . json_encode($errorInfo) . "\n";
        exit;
    }
    
    // Step 7: Delete from orders table
    echo "Step 7: Deleting from orders table...\n";
    $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
    $delete_result = $delete_stmt->execute([$order_id]);
    
    if ($delete_result) {
        echo "Successfully deleted from orders table!\n\n";
    } else {
        echo "Failed to delete from orders table!\n";
        exit;
    }
    
    // Step 8: Delete order items
    echo "Step 8: Deleting order items...\n";
    $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
    $delete_items_result = $delete_items_stmt->execute([$order_id]);
    
    if ($delete_items_result) {
        echo "Successfully deleted order items!\n\n";
    } else {
        echo "Failed to delete order items!\n";
        exit;
    }
    
    // Final verification
    echo "Final verification...\n";
    
    $final_order_check = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $final_order_check->execute([$order_id]);
    $final_order = $final_order_check->fetch(PDO::FETCH_ASSOC);
    
    if ($final_order) {
        echo "❌ Order still exists in orders table!\n";
    } else {
        echo "✅ Order successfully removed from orders table!\n";
    }
    
    $final_trans_check = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $final_trans_check->execute([$order_id]);
    $final_trans = $final_trans_check->fetch(PDO::FETCH_ASSOC);
    
    if ($final_trans) {
        echo "✅ Order successfully transferred to transactions table!\n";
        echo "Transaction ID: " . $final_trans['transaction_id'] . "\n";
        echo "Customer: " . $final_trans['customer_name'] . "\n";
        echo "Amount: " . $final_trans['amount'] . "\n";
    } else {
        echo "❌ Order not found in transactions table!\n";
    }
    
    echo "\n=== TEST COMPLETED ===\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
