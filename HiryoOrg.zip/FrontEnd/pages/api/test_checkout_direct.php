<?php
/**
 * Test Checkout Direct
 * This script directly tests the checkout functionality
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test direct orders_api.php call
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/orders_api.php';
    
    // Sample order data (exactly what mobile app sends)
    $orderData = [
        'action' => 'place_order',
        'user_id' => 1,
        'total_amount' => 388.00,
        'delivery_fee' => 108.00,
        'items' => '[{"product_id":46,"quantity":1,"price":280.00}]',
        'delivery_method' => 'Delivery',
        'shipping_address' => 'Purok Malapati, Sitio Primitiva, Tungkop Minglanilla, Cebu 6046',
        'payment_method' => 'Cash on Delivery'
    ];
    
    // Test POST request
    $postData = http_build_query($orderData);
    
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 15
        ]
    ]);
    
    $response = @file_get_contents($apiUrl, false, $context);
    $orderResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['direct_place_order'] = [
        'status' => $orderResult['success'] ? 'PASS' : 'FAIL',
        'message' => $orderResult['success'] ? 'Direct order placement successful' : 'Direct order placement failed: ' . ($orderResult['message'] ?? 'Unknown error'),
        'api_url' => $apiUrl,
        'order_data' => $orderData,
        'response' => $orderResult,
        'order_id' => $orderResult['order_id'] ?? 'N/A'
    ];
    
    // Test 2: Check if we can include orders_api.php directly
    $testResults['tests']['include_orders_api'] = [
        'status' => 'INFO',
        'message' => 'Testing include orders_api.php',
        'file_exists' => file_exists(__DIR__ . '/orders_api.php')
    ];
    
    // Test 3: Check database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    $testResults['tests']['database_check'] = [
        'status' => $conn ? 'PASS' : 'FAIL',
        'message' => $conn ? 'Database connection working' : 'Database connection failed'
    ];
    
    // Test 4: Check if user_id 1 exists
    if ($conn) {
        try {
            $stmt = $conn->prepare("SELECT user_id, username FROM users WHERE user_id = 1");
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $testResults['tests']['test_user_check'] = [
                'status' => $user ? 'PASS' : 'FAIL',
                'message' => $user ? 'Test user (ID: 1) exists' : 'Test user (ID: 1) not found',
                'user_data' => $user
            ];
        } catch (Exception $e) {
            $testResults['tests']['test_user_check'] = [
                'status' => 'FAIL',
                'message' => 'Error checking user: ' . $e->getMessage()
            ];
        }
    }
    
    // Test 5: Check if product_id 46 exists
    if ($conn) {
        try {
            $stmt = $conn->prepare("SELECT product_id, product_name, price FROM products WHERE product_id = 46");
            $stmt->execute();
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $testResults['tests']['test_product_check'] = [
                'status' => $product ? 'PASS' : 'FAIL',
                'message' => $product ? 'Test product (ID: 46) exists' : 'Test product (ID: 46) not found',
                'product_data' => $product
            ];
        } catch (Exception $e) {
            $testResults['tests']['test_product_check'] = [
                'status' => 'FAIL',
                'message' => 'Error checking product: ' . $e->getMessage()
            ];
        }
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'checkout_issue_found' => $failCount > 0 ? 'YES - Found checkout issues' : 'NO - Checkout should work',
        'recommendations' => $failCount === 0 ? [
            '1. Checkout should work now',
            '2. All prerequisites are met',
            '3. Test mobile app checkout'
        ] : [
            '1. Fix database connection issues',
            '2. Ensure test user and product exist',
            '3. Check orders API functionality'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'checkout_direct_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
