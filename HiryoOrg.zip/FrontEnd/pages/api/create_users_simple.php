<?php
/**
 * Create Users Simple
 * This script creates users using only the columns that exist
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo json_encode(['error' => 'Database connection failed']);
        exit;
    }
    
    $results = [
        'timestamp' => date('Y-m-d H:i:s'),
        'user_creation' => []
    ];
    
    // Check if user_id 1 exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE user_id = 1");
    $stmt->execute();
    $user1 = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user1) {
        // Create user_id 1 (mobile app test user) - using minimal required fields
        $stmt = $conn->prepare("
            INSERT INTO users (user_id, username, email, firstName, lastName, password, roles, status) 
            VALUES (1, 'testuser', 'test@example.com', 'Test', 'User', ?, 'customer', 'Active')
        ");
        $hashedPassword = password_hash('password123', PASSWORD_DEFAULT);
        $result = $stmt->execute([$hashedPassword]);
        
        $results['user_creation']['user_1'] = [
            'created' => $result,
            'user_id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com'
        ];
    } else {
        $results['user_creation']['user_1'] = [
            'created' => false,
            'message' => 'User ID 1 already exists'
        ];
    }
    
    // Check if admin user exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE roles = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$admin) {
        // Create admin user - using minimal required fields
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, firstName, lastName, password, roles, status) 
            VALUES ('admin', 'admin@hiryoorganics.com', 'Admin', 'User', ?, 'admin', 'Active')
        ");
        $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $result = $stmt->execute([$hashedPassword]);
        $adminId = $conn->lastInsertId();
        
        $results['user_creation']['admin_user'] = [
            'created' => $result,
            'admin_id' => $adminId,
            'username' => 'admin',
            'email' => 'admin@hiryoorganics.com'
        ];
    } else {
        $results['user_creation']['admin_user'] = [
            'created' => false,
            'message' => 'Admin user already exists',
            'admin_id' => $admin['user_id']
        ];
    }
    
    // Verify users exist now
    $stmt = $conn->prepare("SELECT user_id, username, roles FROM users WHERE user_id = 1 OR roles = 'admin'");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $results['verification'] = [
        'users_found' => count($users),
        'users' => $users
    ];
    
    $results['summary'] = [
        'status' => 'SUCCESS',
        'message' => 'Users created successfully',
        'mobile_app_ready' => true,
        'next_steps' => [
            '1. Test mobile app checkout now',
            '2. Users are available for order placement',
            '3. Admin notifications will work'
        ]
    ];
    
    echo json_encode($results, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
