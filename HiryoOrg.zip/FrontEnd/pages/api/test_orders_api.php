<?php
/**
 * Test Orders API
 * This script tests the orders API for mobile app checkout
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test place_order action with sample data
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/orders_api.php';
    
    // Sample order data (similar to what mobile app sends)
    $orderData = [
        'action' => 'place_order',
        'user_id' => 1, // Test user ID
        'total_amount' => 388.00,
        'delivery_fee' => 108.00,
        'items' => '[{"product_id":46,"quantity":1,"price":280.00}]', // Hiryo Quad Myco Plus
        'delivery_method' => 'Delivery',
        'shipping_address' => 'Purok Malapati, Sitio Primitiva, Tungkop Minglanilla, Cebu 6046',
        'payment_method' => 'Cash on Delivery'
    ];
    
    $postData = http_build_query($orderData);
    
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 15
        ]
    ]);
    
    $response = @file_get_contents($apiUrl, false, $context);
    $orderResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['place_order_test'] = [
        'status' => $orderResult['success'] ? 'PASS' : 'FAIL',
        'message' => $orderResult['success'] ? 'Order placement successful' : 'Order placement failed: ' . ($orderResult['message'] ?? 'Unknown error'),
        'api_url' => $apiUrl,
        'order_data' => $orderData,
        'response' => $orderResult,
        'order_id' => $orderResult['order_id'] ?? 'N/A'
    ];
    
    // Test 2: Test get_user_orders action
    $getOrdersUrl = $apiUrl . '?action=get_user_orders&user_id=1';
    
    $getResponse = @file_get_contents($getOrdersUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 10
        ]
    ]));
    
    $ordersResult = $getResponse ? json_decode($getResponse, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['get_user_orders_test'] = [
        'status' => $ordersResult['success'] ? 'PASS' : 'FAIL',
        'message' => $ordersResult['success'] ? 'User orders retrieved successfully' : 'Failed to get user orders: ' . ($ordersResult['message'] ?? 'Unknown error'),
        'orders_count' => isset($ordersResult['orders']) ? count($ordersResult['orders']) : 0,
        'response' => $ordersResult
    ];
    
    // Test 3: Check if orders_api.php file exists and is accessible
    $filePath = __DIR__ . '/orders_api.php';
    $testResults['tests']['api_file_check'] = [
        'status' => file_exists($filePath) ? 'PASS' : 'FAIL',
        'message' => file_exists($filePath) ? 'orders_api.php file exists' : 'orders_api.php file not found',
        'file_path' => $filePath,
        'file_readable' => file_exists($filePath) ? is_readable($filePath) : false
    ];
    
    // Test 4: Check database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    $testResults['tests']['database_connection'] = [
        'status' => $conn ? 'PASS' : 'FAIL',
        'message' => $conn ? 'Database connection working' : 'Database connection failed',
        'connection_type' => $conn ? get_class($conn) : 'null'
    ];
    
    // Test 5: Check if orders table exists and has data
    if ($conn) {
        try {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders");
            $stmt->execute();
            $orderCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
            
            $testResults['tests']['orders_table_check'] = [
                'status' => 'PASS',
                'message' => 'Orders table exists and accessible',
                'orders_count' => $orderCount
            ];
        } catch (Exception $e) {
            $testResults['tests']['orders_table_check'] = [
                'status' => 'FAIL',
                'message' => 'Orders table error: ' . $e->getMessage()
            ];
        }
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'mobile_checkout_should_work' => $failCount === 0 ? 'YES' : 'NO',
        'recommendations' => $failCount === 0 ? [
            '1. Mobile app checkout should work now',
            '2. Orders API is functioning correctly',
            '3. Database connection is stable'
        ] : [
            '1. Fix orders API issues',
            '2. Check database connection',
            '3. Verify orders table structure'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'orders_api_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
