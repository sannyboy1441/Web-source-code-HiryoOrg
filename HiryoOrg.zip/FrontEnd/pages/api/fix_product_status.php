<?php
/**
 * Fix Product Status
 * This script fixes products with empty or invalid status values
 */

header('Content-Type: application/json');

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Find products with empty status
    $stmt = $conn->prepare("SELECT product_id, product_name, status FROM products WHERE status = '' OR status IS NULL");
    $stmt->execute();
    $emptyStatusProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['empty_status_products'] = [
        'status' => 'INFO',
        'message' => 'Products with empty status',
        'count' => count($emptyStatusProducts),
        'products' => $emptyStatusProducts
    ];
    
    // Test 2: Fix products with empty status
    if (count($emptyStatusProducts) > 0) {
        $updateStmt = $conn->prepare("UPDATE products SET status = 'Active' WHERE status = '' OR status IS NULL");
        $result = $updateStmt->execute();
        $affectedRows = $updateStmt->rowCount();
        
        $testResults['tests']['fix_empty_status'] = [
            'status' => $result ? 'PASS' : 'FAIL',
            'message' => $result ? "Fixed $affectedRows products with empty status" : 'Failed to fix empty status products',
            'affected_rows' => $affectedRows
        ];
    } else {
        $testResults['tests']['fix_empty_status'] = [
            'status' => 'INFO',
            'message' => 'No products with empty status found'
        ];
    }
    
    // Test 3: Verify all products now have valid status
    $stmt = $conn->prepare("SELECT product_id, product_name, status FROM products ORDER BY product_id DESC LIMIT 10");
    $stmt->execute();
    $recentProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['verify_status_fix'] = [
        'status' => 'INFO',
        'message' => 'Recent products status check',
        'products' => $recentProducts
    ];
    
    // Test 4: Test the get_products_for_admin API
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_products_for_admin';
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 5
        ]
    ]);
    
    $response = @file_get_contents($apiUrl, false, $context);
    
    if ($response === false) {
        $testResults['tests']['api_test'] = [
            'status' => 'FAIL',
            'message' => 'API test failed - no response',
            'url' => $apiUrl
        ];
    } else {
        $data = json_decode($response, true);
        $testResults['tests']['api_test'] = [
            'status' => $data && isset($data['success']) && $data['success'] ? 'PASS' : 'FAIL',
            'message' => $data && isset($data['success']) && $data['success'] ? 'API working correctly' : 'API error: ' . ($data['message'] ?? 'Unknown error'),
            'products_returned' => isset($data['products']) ? count($data['products']) : 0,
            'url' => $apiUrl
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'products_should_now_be_visible' => 'All products now have valid status values'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'fix_product_status',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
