<?php
/**
 * Test CSS MIME Type Fix
 */

header('Content-Type: application/json');

$cssUrl = 'https://hiryoorganics.swuitapp.com/FrontEnd/styles/notifications.css';
$results = [];

// Test 1: Check if CSS file exists
$cssPath = __DIR__ . '/../styles/notifications.css';
$results['css_file_exists'] = file_exists($cssPath);
$results['css_file_size'] = file_exists($cssPath) ? filesize($cssPath) : 0;
$results['css_file_readable'] = is_readable($cssPath);

// Test 2: Check .htaccess files
$htaccessPaths = [
    'styles_htaccess' => __DIR__ . '/../styles/.htaccess',
    'frontend_htaccess' => __DIR__ . '/../.htaccess'
];

foreach ($htaccessPaths as $name => $path) {
    $results[$name] = [
        'exists' => file_exists($path),
        'readable' => is_readable($path),
        'size' => file_exists($path) ? filesize($path) : 0
    ];
}

// Test 3: Simulate HTTP request to CSS file
$context = stream_context_create([
    'http' => [
        'method' => 'HEAD',
        'header' => 'User-Agent: Mozilla/5.0'
    ]
]);

$headers = @get_headers($cssUrl, 1, $context);
$results['http_test'] = [
    'css_url' => $cssUrl,
    'headers_received' => $headers ?: 'Failed to get headers',
    'content_type' => $headers['Content-Type'] ?? 'Not found'
];

// Test 4: Check if mod_rewrite is available
$results['server_modules'] = [
    'mod_rewrite' => function_exists('apache_get_modules') ? in_array('mod_rewrite', apache_get_modules()) : 'Unknown',
    'mod_headers' => function_exists('apache_get_modules') ? in_array('mod_headers', apache_get_modules()) : 'Unknown'
];

echo json_encode([
    'css_mime_test' => $results,
    'conclusion' => $results['css_file_exists'] ? 
        'CSS file exists - MIME type issue may be server configuration' : 
        'CSS file not found',
    'recommendations' => [
        'Upload both .htaccess files to Hostinger',
        'Clear browser cache completely',
        'Test CSS file directly in browser',
        'Check Hostinger server configuration'
    ]
], JSON_PRETTY_PRINT);
?>
