<?php
// Fix transfer for ALL remaining completed orders
header('Content-Type: text/plain');

echo "=== FIXING TRANSFER FOR ALL COMPLETED ORDERS ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Find all completed orders that are NOT in transactions table
    $completed_orders_stmt = $conn->prepare("
        SELECT o.order_id 
        FROM orders o 
        WHERE o.status = 'Completed' 
        AND o.order_id NOT IN (SELECT order_id FROM transactions)
    ");
    $completed_orders_stmt->execute();
    $orders_to_transfer = $completed_orders_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($orders_to_transfer)) {
        echo "✅ All completed orders are already transferred!\n";
        exit;
    }
    
    echo "Found " . count($orders_to_transfer) . " completed orders that need to be transferred:\n";
    foreach ($orders_to_transfer as $order_id) {
        echo "   - Order #$order_id\n";
    }
    echo "\n";
    
    $success_count = 0;
    $error_count = 0;
    
    foreach ($orders_to_transfer as $order_id) {
        echo "Processing Order #$order_id...\n";
        
        try {
            // Get order details
            $order_stmt = $conn->prepare("
                SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number
                FROM orders o 
                LEFT JOIN users u ON o.user_id = u.user_id 
                WHERE o.order_id = ?
            ");
            $order_stmt->execute([$order_id]);
            $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                echo "   ❌ Order #$order_id not found\n";
                $error_count++;
                continue;
            }
            
            // Get order items
            $items_stmt = $conn->prepare("
                SELECT oi.*, p.product_name 
                FROM order_items oi 
                LEFT JOIN products p ON oi.product_id = p.product_id 
                WHERE oi.order_id = ?
            ");
            $items_stmt->execute([$order_id]);
            $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Create transactions table if it doesn't exist
            $create_table_sql = "
                CREATE TABLE IF NOT EXISTS transactions (
                    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
                    order_id INT NOT NULL,
                    user_id INT NOT NULL,
                    customer_name VARCHAR(255),
                    customer_email VARCHAR(255),
                    customer_contact VARCHAR(20),
                    delivery_method ENUM('Delivery', 'Pickup') NOT NULL,
                    payment_method VARCHAR(50) NOT NULL,
                    shipping_address TEXT,
                    subtotal DECIMAL(10,2) NOT NULL,
                    delivery_fee DECIMAL(10,2) NOT NULL,
                    amount DECIMAL(10,2) NOT NULL,
                    created_at DATETIME NOT NULL,
                    items JSON,
                    INDEX idx_user_id (user_id),
                    INDEX idx_created_at (created_at)
                )
            ";
            $conn->exec($create_table_sql);
            
            // Insert into transactions table
            $trans_stmt = $conn->prepare("
                INSERT INTO transactions (
                    order_id, user_id, customer_name, customer_email, customer_contact,
                    delivery_method, payment_method, shipping_address, subtotal, 
                    delivery_fee, amount, created_at, items
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
            ");
            
            $customer_name = trim(($order['firstName'] ?? '') . ' ' . ($order['lastName'] ?? ''));
            $items_json = json_encode($items);
            
            $trans_result = $trans_stmt->execute([
                $order_id,
                $order['user_id'],
                $customer_name,
                $order['email'],
                $order['contact_number'],
                $order['delivery_method'],
                $order['payment_method'],
                $order['shipping_address'],
                $order['subtotal'],
                $order['delivery_fee'],
                $order['total_amount'],
                $items_json
            ]);
            
            if (!$trans_result) {
                echo "   ❌ Failed to insert into transactions table\n";
                $error_count++;
                continue;
            }
            
            // Delete order items
            $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $delete_items_stmt->execute([$order_id]);
            
            // Delete from orders table
            $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $delete_stmt->execute([$order_id]);
            
            echo "   ✅ Successfully transferred Order #$order_id\n";
            $success_count++;
            
        } catch (Exception $e) {
            echo "   ❌ Error processing Order #$order_id: " . $e->getMessage() . "\n";
            $error_count++;
        }
    }
    
    echo "\n=== SUMMARY ===\n";
    echo "✅ Successfully transferred: $success_count orders\n";
    echo "❌ Failed to transfer: $error_count orders\n";
    
    if ($error_count == 0) {
        echo "\n🎉 ALL COMPLETED ORDERS HAVE BEEN TRANSFERRED!\n";
        echo "✅ The transfer process is now complete!\n";
    } else {
        echo "\n⚠️ Some orders failed to transfer. Check the errors above.\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
