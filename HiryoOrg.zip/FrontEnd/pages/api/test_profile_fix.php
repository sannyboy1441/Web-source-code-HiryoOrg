<?php
/**
 * Test Profile Fix
 * This script tests the profile functionality
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check if API files exist
    $apiFiles = [
        'update_profile.php' => __DIR__ . '/update_profile.php',
        'change_password.php' => __DIR__ . '/change_password.php'
    ];
    
    foreach ($apiFiles as $filename => $path) {
        $testResults['tests']["api_file_$filename"] = [
            'status' => file_exists($path) ? 'PASS' : 'FAIL',
            'message' => file_exists($path) ? "API file exists: $filename" : "Missing API file: $filename",
            'file_path' => $path
        ];
    }
    
    // Test 2: Test update profile API with GET request (workaround)
    $updateUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/update_profile.php';
    $updateData = [
        'username' => 'testuser',
        'password' => 'password123',
        'field' => 'firstName',
        'value' => 'Updated Test'
    ];
    
    $getUrl = $updateUrl . '?' . http_build_query($updateData);
    
    $response = @file_get_contents($getUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $updateResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['update_profile_api'] = [
        'status' => $updateResult['success'] ? 'PASS' : 'FAIL',
        'message' => $updateResult['success'] ? 'Profile update API working!' : 'Profile update failed: ' . ($updateResult['message'] ?? 'Unknown error'),
        'api_url' => $getUrl,
        'response' => $updateResult,
        'workaround_method' => 'GET request (due to server POST issue)'
    ];
    
    // Test 3: Test change password API with GET request (workaround)
    $passwordUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/change_password.php';
    $passwordData = [
        'username' => 'testuser',
        'currentPassword' => 'password123',
        'newPassword' => 'newpassword123'
    ];
    
    $passwordGetUrl = $passwordUrl . '?' . http_build_query($passwordData);
    
    $passwordResponse = @file_get_contents($passwordGetUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $passwordResult = $passwordResponse ? json_decode($passwordResponse, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['change_password_api'] = [
        'status' => $passwordResult['success'] ? 'PASS' : 'FAIL',
        'message' => $passwordResult['success'] ? 'Password change API working!' : 'Password change failed: ' . ($passwordResult['message'] ?? 'Unknown error'),
        'api_url' => $passwordGetUrl,
        'response' => $passwordResult,
        'workaround_method' => 'GET request (due to server POST issue)'
    ];
    
    // Test 4: Verify database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if ($conn) {
        $stmt = $conn->prepare("SELECT user_id, username, firstName FROM users WHERE username = 'testuser'");
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['database_connection'] = [
            'status' => $user ? 'PASS' : 'FAIL',
            'message' => $user ? 'Database connection working and test user found' : 'Database connection or test user issue',
            'user_data' => $user
        ];
    } else {
        $testResults['tests']['database_connection'] = [
            'status' => 'FAIL',
            'message' => 'Database connection failed'
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'profile_should_work' => $failCount === 0 ? 'YES - Profile should work now!' : 'NO - Still has issues',
        'fixes_applied' => [
            '1. Fixed API URLs (added /HiryoOrg/FrontEnd/pages/api/)',
            '2. Created missing visibility icons (ic_visibility.xml, ic_visibility_off.xml)',
            '3. Created update_profile.php API',
            '4. Created change_password.php API',
            '5. Applied GET workaround for server POST issue',
            '6. Profile activity declared in AndroidManifest.xml'
        ],
        'recommendations' => $failCount === 0 ? [
            '1. Mobile app profile should work now',
            '2. Profile editing should be functional',
            '3. Password changing should work',
            '4. Test mobile app profile section!'
        ] : [
            '1. Fix remaining API issues',
            '2. Check database connections',
            '3. Verify file permissions'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'profile_fix_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
