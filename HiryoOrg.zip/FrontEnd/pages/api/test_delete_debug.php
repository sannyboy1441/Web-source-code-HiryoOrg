<?php
/**
 * Test Delete Debug
 * This script tests the delete API directly to see what's happening
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test the delete API directly
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php';
    
    // Create test data
    $testProductId = 999; // Use a non-existent ID first to test error handling
    
    $deleteData = http_build_query([
        'action' => 'delete_product',
        'product_id' => $testProductId
    ]);
    
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $deleteData,
            'timeout' => 10
        ]
    ]);
    
    $response = @file_get_contents($apiUrl, false, $context);
    $deleteResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['delete_api_direct'] = [
        'status' => 'INFO',
        'message' => 'Direct API test with non-existent product',
        'product_id' => $testProductId,
        'api_response' => $deleteResult,
        'raw_response' => $response
    ];
    
    // Test 2: Check what products exist
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if ($conn) {
        $stmt = $conn->prepare("SELECT product_id, product_name FROM products ORDER BY product_id DESC LIMIT 5");
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $testResults['tests']['available_products'] = [
            'status' => 'INFO',
            'message' => 'Available products for testing',
            'products' => $products
        ];
        
        // Test 3: Try deleting the last product (if any exist)
        if (count($products) > 0) {
            $lastProduct = $products[0];
            $deleteData2 = http_build_query([
                'action' => 'delete_product',
                'product_id' => $lastProduct['product_id']
            ]);
            
            $context2 = stream_context_create([
                'http' => [
                    'method' => 'POST',
                    'header' => 'Content-Type: application/x-www-form-urlencoded',
                    'content' => $deleteData2,
                    'timeout' => 10
                ]
            ]);
            
            $response2 = @file_get_contents($apiUrl, false, $context2);
            $deleteResult2 = $response2 ? json_decode($response2, true) : ['success' => false, 'message' => 'No response from API'];
            
            $testResults['tests']['delete_real_product'] = [
                'status' => $deleteResult2['success'] ? 'PASS' : 'FAIL',
                'message' => $deleteResult2['success'] ? 'Successfully deleted real product' : 'Failed to delete real product',
                'product_id' => $lastProduct['product_id'],
                'product_name' => $lastProduct['product_name'],
                'api_response' => $deleteResult2,
                'raw_response' => $response2
            ];
        }
    }
    
    // Test 4: Check server logs or error handling
    $testResults['tests']['debug_info'] = [
        'status' => 'INFO',
        'message' => 'Debug information',
        'server_info' => [
            'php_version' => phpversion(),
            'server_time' => date('Y-m-d H:i:s'),
            'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'N/A',
            'script_path' => __DIR__
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'delete_debug',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
