<?php
/**
 * ENHANCED Transactions API - Complete data handling with full names and items
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../datab_try.php';

// --- Main API Router ---
try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    $action = $_REQUEST['action'] ?? '';

    switch ($action) {
        case 'get_all_transactions':
            handleGetAllTransactionsEnhanced($conn);
            break;
            
        case 'get_user_transactions':
            handleGetUserTransactionsEnhanced($conn);
            break;
            
        case 'get_completed_order_details':
            handleGetCompletedOrderDetailsEnhanced($conn);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid or missing action.']);
            break;
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}

/**
 * ENHANCED: Get all transactions with complete data including full names
 */
function handleGetAllTransactionsEnhanced($conn) {
    try {
        // First check if transactions table exists
        $checkTableStmt = $conn->prepare("SHOW TABLES LIKE 'transactions'");
        $checkTableStmt->execute();
        $tableExists = $checkTableStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tableExists) {
            echo json_encode([
                'success' => true, 
                'transactions' => [],
                'message' => 'No completed transactions yet. Transactions will appear here when orders are completed.'
            ]);
            return;
        }
        
        // Enhanced query with complete user data
        $query = "
            SELECT 
                t.transaction_id,
                t.order_id,
                t.user_id,
                COALESCE(t.total_amount, t.amount, 0) as amount,
                COALESCE(t.payment_method, 'COD') as payment_method,
                COALESCE(t.completion_date, t.created_at, NOW()) as created_at,
                COALESCE(
                    t.customer_name, 
                    CONCAT(u.firstName, ' ', u.lastName),
                    u.firstName,
                    u.username,
                    'Unknown Customer'
                ) as user_name,
                COALESCE(t.customer_email, u.email, 'unknown@email.com') as user_email,
                COALESCE(t.customer_contact, u.contact_number, '') as customer_contact,
                COALESCE(t.delivery_method, 'Delivery') as delivery_method,
                COALESCE(t.shipping_address, u.address, '') as shipping_address,
                COALESCE(t.subtotal, 0) as subtotal,
                COALESCE(t.delivery_fee, 0) as delivery_fee,
                t.items,
                'Completed' as order_status
            FROM transactions t
            LEFT JOIN users u ON t.user_id = u.user_id
            ORDER BY COALESCE(t.completion_date, t.created_at) DESC
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true, 
            'transactions' => $transactions,
            'message' => count($transactions) === 0 ? 'No completed transactions found. Transactions will appear here when orders are completed.' : null
        ]);
        
    } catch (PDOException $e) {
        error_log("Transactions API Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    } catch (Exception $e) {
        error_log("Transactions API Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

/**
 * ENHANCED: Get user transactions for mobile app
 */
function handleGetUserTransactionsEnhanced($conn) {
    $userId = (int)($_REQUEST['user_id'] ?? 0);
    if ($userId <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid user ID is required.']);
        return;
    }
    
    try {
        // Enhanced query with complete user data
        $query = "
            SELECT 
                t.transaction_id, 
                t.order_id, 
                t.user_id,
                COALESCE(t.total_amount, t.amount, 0) as amount, 
                COALESCE(t.payment_method, 'COD') as payment_method, 
                COALESCE(t.completion_date, t.created_at, NOW()) as created_at,
                'Completed' as order_status,
                COALESCE(
                    t.customer_name, 
                    CONCAT(u.firstName, ' ', u.lastName),
                    u.firstName,
                    u.username,
                    'Unknown Customer'
                ) as customer_name,
                COALESCE(t.customer_email, u.email, 'unknown@email.com') as customer_email,
                COALESCE(t.customer_contact, u.contact_number, '') as customer_contact,
                COALESCE(t.delivery_method, 'Delivery') as delivery_method,
                COALESCE(t.shipping_address, u.address, '') as shipping_address,
                COALESCE(t.subtotal, 0) as subtotal,
                COALESCE(t.delivery_fee, 0) as delivery_fee,
                t.items
            FROM transactions t 
            LEFT JOIN users u ON t.user_id = u.user_id
            WHERE t.user_id = ? 
            ORDER BY COALESCE(t.completion_date, t.created_at) DESC
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$userId]);
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'transactions' => $transactions]);
        
    } catch (Exception $e) {
        error_log("Get user transactions error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to get user transactions: ' . $e->getMessage()]);
    }
}

/**
 * ENHANCED: Get completed order details for modal
 */
function handleGetCompletedOrderDetailsEnhanced($conn) {
    $order_id = (int)($_REQUEST['order_id'] ?? 0);
    
    if ($order_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid order ID is required']);
        return;
    }
    
    try {
        // Enhanced query with complete user data and items
        $query = "
            SELECT 
                t.transaction_id,
                t.order_id,
                t.user_id,
                COALESCE(t.total_amount, t.amount, 0) as amount,
                COALESCE(t.payment_method, 'COD') as payment_method,
                COALESCE(t.completion_date, t.created_at, NOW()) as created_at,
                COALESCE(
                    t.customer_name, 
                    CONCAT(u.firstName, ' ', u.lastName),
                    u.firstName,
                    u.username,
                    'Unknown Customer'
                ) as customer_name,
                COALESCE(t.customer_email, u.email, 'unknown@email.com') as customer_email,
                COALESCE(t.customer_contact, u.contact_number, '') as customer_contact,
                COALESCE(t.delivery_method, 'Delivery') as delivery_method,
                COALESCE(t.shipping_address, u.address, '') as shipping_address,
                COALESCE(t.subtotal, 0) as subtotal,
                COALESCE(t.delivery_fee, 0) as delivery_fee,
                t.items,
                'Completed' as order_status
            FROM transactions t
            LEFT JOIN users u ON t.user_id = u.user_id
            WHERE t.order_id = ?
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$order_id]);
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$transaction) {
            echo json_encode(['success' => false, 'message' => 'Completed order not found']);
            return;
        }
        
        // Parse items JSON
        $items = [];
        if (!empty($transaction['items']) && $transaction['items'] !== 'NULL') {
            $items = json_decode($transaction['items'], true) ?: [];
        }
        
        // If no items in transactions table, try to get from order_items
        if (empty($items)) {
            $itemsQuery = "
                SELECT 
                    oi.quantity,
                    oi.price,
                    p.product_name as name,
                    p.product_name as product_name
                FROM order_items oi
                LEFT JOIN products p ON oi.product_id = p.product_id
                WHERE oi.order_id = ?
            ";
            $itemsStmt = $conn->prepare($itemsQuery);
            $itemsStmt->execute([$order_id]);
            $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        // Add items to transaction data
        $transaction['items'] = $items;
        
        echo json_encode(['success' => true, 'order' => $transaction]);
        
    } catch (Exception $e) {
        error_log("Get completed order details error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to get order details: ' . $e->getMessage()]);
    }
}

?>
