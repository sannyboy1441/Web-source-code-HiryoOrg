<?php
/**
 * Test Transactions API - Debug the 400 error
 */

header('Content-Type: application/json');

// Include database connection
@include_once '../datab_try.php';

echo json_encode([
    'test' => 'Transactions API Test',
    'database_connected' => isset($conn) && $conn !== false,
    'pdo_connected' => function_exists('getDBConnection') && getDBConnection() !== null,
    'action' => $_GET['action'] ?? $_POST['action'] ?? 'none',
    'request_method' => $_SERVER['REQUEST_METHOD'],
    'all_params' => [
        'GET' => $_GET,
        'POST' => $_POST,
        'REQUEST' => $_REQUEST
    ],
    'server_info' => [
        'php_version' => PHP_VERSION,
        'time' => date('Y-m-d H:i:s')
    ]
]);

// Test database connection
if (function_exists('getDBConnection')) {
    try {
        $testConn = getDBConnection();
        if ($testConn) {
            echo "\n\nDatabase Test:\n";
            $stmt = $testConn->query("SELECT COUNT(*) as count FROM transactions");
            $result = $stmt->fetch();
            echo json_encode([
                'database_test' => 'success',
                'transaction_count' => $result['count']
            ]);
        } else {
            echo "\n\nDatabase Test: FAILED - No connection\n";
        }
    } catch (Exception $e) {
        echo "\n\nDatabase Test: ERROR - " . $e->getMessage() . "\n";
    }
}
?>
