<?php
// Check current database state
header('Content-Type: text/plain');

echo "Checking Current Database State...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Check orders table
    echo "=== ORDERS TABLE ===\n";
    $orders_stmt = $conn->prepare("SELECT order_id, status, total_amount, order_date FROM orders ORDER BY order_id DESC LIMIT 10");
    $orders_stmt->execute();
    $orders = $orders_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "No orders found in orders table!\n";
    } else {
        echo "Recent orders:\n";
        foreach ($orders as $order) {
            echo "- Order #{$order['order_id']}: Status = {$order['status']}, Total = {$order['total_amount']}, Date = {$order['order_date']}\n";
        }
    }
    echo "\n";
    
    // Check transactions table
    echo "=== TRANSACTIONS TABLE ===\n";
    $trans_stmt = $conn->prepare("SELECT transaction_id, order_id, customer_name, amount, created_at FROM transactions ORDER BY transaction_id DESC LIMIT 10");
    $trans_stmt->execute();
    $transactions = $trans_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($transactions)) {
        echo "No transactions found in transactions table!\n";
    } else {
        echo "Recent transactions:\n";
        foreach ($transactions as $trans) {
            echo "- Transaction #{$trans['transaction_id']}: Order #{$trans['order_id']}, Customer = {$trans['customer_name']}, Amount = {$trans['amount']}, Date = {$trans['created_at']}\n";
        }
    }
    echo "\n";
    
    // Check for completed orders that should be in transactions
    echo "=== COMPLETED ORDERS CHECK ===\n";
    $completed_stmt = $conn->prepare("SELECT order_id FROM orders WHERE status = 'Completed'");
    $completed_stmt->execute();
    $completed_orders = $completed_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($completed_orders)) {
        echo "Found completed orders still in orders table:\n";
        foreach ($completed_orders as $order) {
            echo "- Order #{$order['order_id']} is completed but still in orders table!\n";
            
            // Check if it exists in transactions
            $check_trans = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
            $check_trans->execute([$order['order_id']]);
            $exists_in_trans = $check_trans->fetch(PDO::FETCH_ASSOC);
            
            if ($exists_in_trans) {
                echo "  ✅ Order #{$order['order_id']} also exists in transactions table\n";
            } else {
                echo "  ❌ Order #{$order['order_id']} NOT found in transactions table - TRANSFER FAILED!\n";
            }
        }
    } else {
        echo "No completed orders found in orders table.\n";
    }
    echo "\n";
    
    // Check transactions table structure
    echo "=== TRANSACTIONS TABLE STRUCTURE ===\n";
    $structure_stmt = $conn->query("DESCRIBE transactions");
    $columns = $structure_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Transactions table columns:\n";
    foreach ($columns as $column) {
        echo "- {$column['Field']}: {$column['Type']} ({$column['Null']}, {$column['Key']}, {$column['Default']})\n";
    }
    echo "\n";
    
    // Test a simple insert to see if there are any constraints
    echo "=== TESTING TRANSACTIONS TABLE INSERT ===\n";
    try {
        $test_insert = $conn->prepare("INSERT INTO transactions (order_id, user_id, customer_name, customer_email, customer_contact, delivery_method, payment_method, shipping_address, subtotal, delivery_fee, amount, created_at, items) VALUES (99999, 1, 'Test Customer', 'test@email.com', '1234567890', 'Delivery', 'COD', 'Test Address', 100.00, 10.00, 110.00, NOW(), '[]')");
        $test_insert->execute();
        echo "✅ Test insert successful - transactions table is working\n";
        
        // Delete the test record
        $delete_test = $conn->prepare("DELETE FROM transactions WHERE order_id = 99999");
        $delete_test->execute();
        echo "✅ Test record deleted successfully\n";
    } catch (Exception $e) {
        echo "❌ Test insert failed: " . $e->getMessage() . "\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
