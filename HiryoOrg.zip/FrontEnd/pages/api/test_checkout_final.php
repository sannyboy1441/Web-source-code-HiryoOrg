<?php
/**
 * Test Checkout Final
 * Final test for checkout functionality
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test direct orders_api.php place_order
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/orders_api.php';
    
    // Sample order data (exactly what mobile app sends)
    $orderData = [
        'action' => 'place_order',
        'user_id' => 1,
        'total_amount' => 388.00,
        'delivery_fee' => 108.00,
        'items' => '[{"product_id":46,"quantity":1,"price":280.00}]',
        'delivery_method' => 'Delivery',
        'shipping_address' => 'Purok Malapati, Sitio Primitiva, Tungkop Minglanilla, Cebu 6046',
        'payment_method' => 'Cash on Delivery'
    ];
    
    $postData = http_build_query($orderData);
    
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 15
        ]
    ]);
    
    $response = @file_get_contents($apiUrl, false, $context);
    $orderResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['final_checkout_test'] = [
        'status' => $orderResult['success'] ? 'PASS' : 'FAIL',
        'message' => $orderResult['success'] ? 'Checkout test successful!' : 'Checkout test failed: ' . ($orderResult['message'] ?? 'Unknown error'),
        'api_url' => $apiUrl,
        'response' => $orderResult,
        'order_id' => $orderResult['order_id'] ?? 'N/A',
        'constraint_violation_fixed' => strpos($orderResult['message'] ?? '', 'SQLSTATE[23000]') === false
    ];
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'mobile_checkout_should_work' => $failCount === 0 ? 'YES - Mobile checkout should work now!' : 'NO - Still has issues',
        'constraint_violation_status' => $failCount === 0 ? 'FIXED ✅' : 'STILL EXISTS ❌',
        'recommendations' => $failCount === 0 ? [
            '1. Mobile app checkout should work now',
            '2. SQLSTATE[23000] constraint violation is fixed',
            '3. Orders can be placed successfully',
            '4. Test mobile app checkout now!'
        ] : [
            '1. Fix remaining checkout issues',
            '2. Check database constraints',
            '3. Verify API functionality'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'checkout_final_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
