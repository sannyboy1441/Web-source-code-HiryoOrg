<?php
// Test the new API V3
header('Content-Type: text/plain');

echo "Testing API V3...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Find an order to test with
    $order_stmt = $conn->prepare("SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number FROM orders o LEFT JOIN users u ON o.user_id = u.user_id WHERE o.status NOT IN ('Completed', 'Cancelled') ORDER BY o.order_id DESC LIMIT 1");
    $order_stmt->execute();
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "No active orders found for testing!\n";
        echo "Let's test with a completed order instead...\n\n";
        
        $order_stmt = $conn->prepare("SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number FROM orders o LEFT JOIN users u ON o.user_id = u.user_id WHERE o.status = 'Completed' ORDER BY o.order_id DESC LIMIT 1");
        $order_stmt->execute();
        $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo "No orders found at all!\n";
            exit;
        }
    }
    
    echo "Test order found:\n";
    echo "- Order ID: {$order['order_id']}\n";
    echo "- Status: {$order['status']}\n";
    echo "- Customer: {$order['firstName']} {$order['lastName']}\n";
    echo "- Total: {$order['total_amount']}\n\n";
    
    // Test the API call
    echo "=== TESTING API V3 ===\n";
    
    // Set up POST data
    $_POST = [];
    $_POST['order_id'] = $order['order_id'];
    $_POST['status'] = 'Completed';
    $_GET['action'] = 'update_order_status';
    
    echo "Making API call with: order_id={$order['order_id']}, status=Completed\n";
    
    // Capture the API response
    ob_start();
    
    // Include the API file
    include 'orders_api_v3.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Check what happened to the order
    echo "=== CHECKING RESULTS ===\n";
    
    // Check if order still exists in orders table
    $check_order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $check_order_stmt->execute([$order['order_id']]);
    $order_still_exists = $check_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_still_exists) {
        echo "❌ Test order still exists in orders table:\n";
        echo "- Status: {$order_still_exists['status']}\n";
        echo "- Total: {$order_still_exists['total_amount']}\n";
    } else {
        echo "✅ Test order removed from orders table\n";
    }
    
    // Check if order exists in transactions table
    $check_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $check_trans_stmt->execute([$order['order_id']]);
    $order_in_transactions = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_in_transactions) {
        echo "✅ Test order successfully transferred to transactions table:\n";
        echo "- Transaction ID: {$order_in_transactions['transaction_id']}\n";
        echo "- Customer: {$order_in_transactions['customer_name']}\n";
        echo "- Amount: {$order_in_transactions['amount']}\n";
        echo "- Created: {$order_in_transactions['created_at']}\n";
    } else {
        echo "❌ Test order NOT found in transactions table - TRANSFER FAILED!\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if (!$order_still_exists && $order_in_transactions) {
        echo "🎉 SUCCESS: API V3 is working perfectly!\n";
        echo "✅ Test order removed from orders table\n";
        echo "✅ Test order transferred to transactions table\n";
        echo "✅ Order completion process is fully functional\n";
    } else {
        echo "❌ FAILURE: API V3 still has issues!\n";
        echo "❌ Order completion process needs further debugging\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
