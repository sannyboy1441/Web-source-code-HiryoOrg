<?php
/**
 * Test Sales Overview
 * This script tests if the sales overview chart data is working correctly
 */

header('Content-Type: application/json');

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check if transactions table has data
    $stmt = $conn->prepare("SELECT COUNT(*) as count, SUM(amount) as total_revenue FROM transactions");
    $stmt->execute();
    $transactionStats = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $testResults['tests']['transactions_data'] = [
        'status' => $transactionStats['count'] > 0 ? 'PASS' : 'WARNING',
        'message' => $transactionStats['count'] > 0 ? 'Transactions table has data' : 'Transactions table is empty',
        'transaction_count' => (int)$transactionStats['count'],
        'total_revenue' => (float)$transactionStats['total_revenue']
    ];
    
    // Test 2: Test 12 month sales data API
    $apiUrl12 = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/dashboard_api.php?action=get_sales_data&period=12';
    
    $response12 = @file_get_contents($apiUrl12, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $apiResult12 = $response12 ? json_decode($response12, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['12_month_sales_api'] = [
        'status' => $apiResult12['success'] ? 'PASS' : 'FAIL',
        'message' => $apiResult12['success'] ? '12 month sales API working' : '12 month sales API failed: ' . ($apiResult12['message'] ?? 'Unknown error'),
        'api_url' => $apiUrl12,
        'data_points' => $apiResult12['success'] ? count($apiResult12['data']) : 0,
        'sample_data' => $apiResult12['success'] && !empty($apiResult12['data']) ? array_slice($apiResult12['data'], 0, 3) : []
    ];
    
    // Test 3: Test 6 month sales data API
    $apiUrl6 = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/dashboard_api.php?action=get_sales_data&period=6';
    
    $response6 = @file_get_contents($apiUrl6, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $apiResult6 = $response6 ? json_decode($response6, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['6_month_sales_api'] = [
        'status' => $apiResult6['success'] ? 'PASS' : 'FAIL',
        'message' => $apiResult6['success'] ? '6 month sales API working' : '6 month sales API failed: ' . ($apiResult6['message'] ?? 'Unknown error'),
        'api_url' => $apiUrl6,
        'data_points' => $apiResult6['success'] ? count($apiResult6['data']) : 0,
        'sample_data' => $apiResult6['success'] && !empty($apiResult6['data']) ? array_slice($apiResult6['data'], 0, 3) : []
    ];
    
    // Test 4: Test 24 month sales data API
    $apiUrl24 = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/dashboard_api.php?action=get_sales_data&period=24';
    
    $response24 = @file_get_contents($apiUrl24, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $apiResult24 = $response24 ? json_decode($response24, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['24_month_sales_api'] = [
        'status' => $apiResult24['success'] ? 'PASS' : 'FAIL',
        'message' => $apiResult24['success'] ? '24 month sales API working' : '24 month sales API failed: ' . ($apiResult24['message'] ?? 'Unknown error'),
        'api_url' => $apiUrl24,
        'data_points' => $apiResult24['success'] ? count($apiResult24['data']) : 0,
        'sample_data' => $apiResult24['success'] && !empty($apiResult24['data']) ? array_slice($apiResult24['data'], 0, 3) : []
    ];
    
    // Test 5: Verify data structure
    $dataStructureValid = false;
    if ($apiResult12['success'] && !empty($apiResult12['data'])) {
        $samplePoint = $apiResult12['data'][0];
        $dataStructureValid = isset($samplePoint['date']) && 
                             isset($samplePoint['orders_count']) && 
                             isset($samplePoint['daily_revenue']);
    }
    
    $testResults['tests']['data_structure'] = [
        'status' => $dataStructureValid ? 'PASS' : 'FAIL',
        'message' => $dataStructureValid ? 'Data structure is correct (date, orders_count, daily_revenue)' : 'Data structure is incorrect or missing fields',
        'expected_fields' => ['date', 'orders_count', 'daily_revenue'],
        'actual_fields' => !empty($apiResult12['data']) ? array_keys($apiResult12['data'][0]) : []
    ];
    
    // Test 6: Check for recent transactions
    $stmt = $conn->prepare("SELECT DATE(created_at) as date, COUNT(*) as count, SUM(amount) as revenue FROM transactions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY date DESC LIMIT 5");
    $stmt->execute();
    $recentTransactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['recent_transactions'] = [
        'status' => count($recentTransactions) > 0 ? 'PASS' : 'WARNING',
        'message' => count($recentTransactions) > 0 ? 'Recent transactions found' : 'No transactions in last 30 days',
        'recent_days_with_data' => count($recentTransactions),
        'sample' => $recentTransactions
    ];
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    $warningCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
        if ($test['status'] === 'WARNING') $warningCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'warnings' => $warningCount,
        'status' => $failCount === 0 ? ($warningCount > 0 ? 'PASSED WITH WARNINGS ⚠️' : 'ALL TESTS PASSED ✅') : 'SOME TESTS FAILED ❌',
        'sales_overview_status' => $failCount === 0 ? 'Sales overview is working and connected to real data' : 'Sales overview has issues',
        'recommendations' => $failCount === 0 ? [
            '1. Sales overview API is working correctly',
            '2. All period options (6, 12, 24 months) are functional',
            '3. Data structure matches JavaScript expectations',
            '4. Chart should display real transaction data'
        ] : [
            '1. Check database connection',
            '2. Verify transactions table has data',
            '3. Check API endpoints',
            '4. Review browser console for JavaScript errors'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'sales_overview_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
