<?php
/**
 * SIMPLIFIED Transactions API - Works with any database schema
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../datab_try.php';

// --- Main API Router ---
try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }

    $action = $_REQUEST['action'] ?? '';

    switch ($action) {
        case 'get_all_transactions':
            handleGetAllTransactionsSimple($conn);
            break;
            
        case 'get_user_transactions':
            handleGetUserTransactionsSimple($conn);
            break;
            
        case 'get_completed_order_details':
            handleGetCompletedOrderDetailsSimple($conn);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid or missing action.']);
            break;
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}

/**
 * SIMPLE: Get all transactions - works with any schema
 */
function handleGetAllTransactionsSimple($conn) {
    try {
        // First check if transactions table exists
        $checkTableStmt = $conn->prepare("SHOW TABLES LIKE 'transactions'");
        $checkTableStmt->execute();
        $tableExists = $checkTableStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tableExists) {
            echo json_encode([
                'success' => true, 
                'transactions' => [],
                'message' => 'No completed transactions yet. Transactions will appear here when orders are completed.'
            ]);
            return;
        }
        
        // Get the actual structure of the transactions table
        $describeStmt = $conn->prepare("DESCRIBE transactions");
        $describeStmt->execute();
        $columns = $describeStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Build a simple query with only existing columns
        $selectFields = ['t.order_id', 't.user_id'];
        
        // Always add user fields for proper name display
        $selectFields[] = 'u.firstName';
        $selectFields[] = 'u.lastName';
        $selectFields[] = 'u.username';
        $selectFields[] = 'u.email';
        $selectFields[] = 'u.contact_number';
        $selectFields[] = 'u.address';
        
        // Add fields only if they exist
        foreach ($columns as $column) {
            $columnName = $column['Field'];
            switch ($columnName) {
                case 'transaction_id':
                    $selectFields[] = 't.transaction_id';
                    break;
                case 'total_amount':
                case 'amount':
                    $selectFields[] = 't.' . $columnName . ' as amount';
                    break;
                case 'payment_method':
                    $selectFields[] = 't.payment_method';
                    break;
                case 'completion_date':
                case 'created_at':
                    $selectFields[] = 't.' . $columnName . ' as created_at';
                    break;
                case 'customer_name':
                    $selectFields[] = 't.customer_name as user_name';
                    break;
                case 'customer_email':
                    $selectFields[] = 't.customer_email as user_email';
                    break;
                case 'customer_contact':
                    $selectFields[] = 't.customer_contact';
                    break;
                case 'delivery_method':
                    $selectFields[] = 't.delivery_method';
                    break;
                case 'shipping_address':
                    $selectFields[] = 't.shipping_address';
                    break;
                case 'subtotal':
                    $selectFields[] = 't.subtotal';
                    break;
                case 'delivery_fee':
                    $selectFields[] = 't.delivery_fee';
                    break;
                case 'total_amount':
                    $selectFields[] = 't.total_amount as amount';
                    break;
                case 'amount':
                    $selectFields[] = 't.amount';
                    break;
                case 'items':
                    $selectFields[] = 't.items';
                    break;
            }
        }
        
        // Always add status
        $selectFields[] = "'Completed' as order_status";
        
        // Build a simple query first
        $simpleQuery = "SELECT * FROM transactions ORDER BY order_id DESC";
        $stmt = $conn->prepare($simpleQuery);
        $stmt->execute();
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("Transactions API - Query executed, found " . count($transactions) . " transactions");

        // Post-process the data to ensure we have all needed fields
        foreach ($transactions as &$transaction) {
            // Use customer_name from transactions table
            if (!empty($transaction['customer_name'])) {
                $transaction['user_name'] = $transaction['customer_name'];
            } else {
                $transaction['user_name'] = 'Unknown Customer';
            }
            
            // Ensure we have a user_email
            if (!empty($transaction['customer_email'])) {
                $transaction['user_email'] = $transaction['customer_email'];
            } else {
                $transaction['user_email'] = 'unknown@email.com';
            }
            
            // Ensure we have an amount
            if (!empty($transaction['amount'])) {
                $transaction['amount'] = $transaction['amount'];
            } elseif (!empty($transaction['total_amount'])) {
                $transaction['amount'] = $transaction['total_amount'];
            } else {
                $transaction['amount'] = 0;
            }
            
            // Add status
            $transaction['order_status'] = 'Completed';
            
            // Ensure we have a payment_method
            if (empty($transaction['payment_method'])) {
                $transaction['payment_method'] = 'COD';
            }
            
            // Ensure we have a delivery_method
            if (empty($transaction['delivery_method'])) {
                $transaction['delivery_method'] = 'Delivery';
            }
            
            // Ensure we have a delivery_fee
            if (empty($transaction['delivery_fee'])) {
                $transaction['delivery_fee'] = 0;
            }
            
            // Ensure we have a subtotal
            if (empty($transaction['subtotal'])) {
                $transaction['subtotal'] = 0;
            }
        }

        echo json_encode([
            'success' => true, 
            'transactions' => $transactions,
            'message' => count($transactions) === 0 ? 'No completed transactions found. Transactions will appear here when orders are completed.' : null
        ]);
        
    } catch (PDOException $e) {
        error_log("Transactions API Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    } catch (Exception $e) {
        error_log("Transactions API Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

/**
 * SIMPLE: Get user transactions for mobile app
 */
function handleGetUserTransactionsSimple($conn) {
    $userId = (int)($_REQUEST['user_id'] ?? 0);
    if ($userId <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid user ID is required.']);
        return;
    }
    
    try {
        // Use the same logic as getAllTransactions but filter by user_id
        $checkTableStmt = $conn->prepare("SHOW TABLES LIKE 'transactions'");
        $checkTableStmt->execute();
        $tableExists = $checkTableStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$tableExists) {
            echo json_encode(['success' => true, 'transactions' => []]);
            return;
        }
        
        // Simple query that works with any schema
        $query = "
            SELECT 
                t.*,
                u.firstName,
                u.lastName,
                u.username,
                u.email,
                u.contact_number,
                u.address,
                'Completed' as order_status
            FROM transactions t
            LEFT JOIN users u ON t.user_id = u.user_id
            WHERE t.user_id = ?
            ORDER BY t.order_id DESC
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$userId]);
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Post-process the data
        foreach ($transactions as &$transaction) {
            // Build full name
            $firstName = $transaction['firstName'] ?? '';
            $lastName = $transaction['lastName'] ?? '';
            $username = $transaction['username'] ?? '';
            
            if (!empty($firstName) && !empty($lastName)) {
                $transaction['customer_name'] = $firstName . ' ' . $lastName;
            } elseif (!empty($firstName)) {
                $transaction['customer_name'] = $firstName;
            } elseif (!empty($username)) {
                $transaction['customer_name'] = $username;
            } else {
                $transaction['customer_name'] = 'Unknown Customer';
            }
            
            // Set email
            $transaction['customer_email'] = $transaction['email'] ?? 'unknown@email.com';
            
            // Set contact
            $transaction['customer_contact'] = $transaction['contact_number'] ?? '';
            
            // Set amount (try different possible column names)
            $transaction['amount'] = $transaction['total_amount'] ?? $transaction['amount'] ?? 0;
            
            // Set payment method
            $transaction['payment_method'] = $transaction['payment_method'] ?? 'COD';
            
            // Set delivery method
            $transaction['delivery_method'] = $transaction['delivery_method'] ?? 'Delivery';
            
            // Set delivery fee
            $transaction['delivery_fee'] = $transaction['delivery_fee'] ?? 0;
            
            // Set subtotal
            $transaction['subtotal'] = $transaction['subtotal'] ?? 0;
        }
        
        echo json_encode(['success' => true, 'transactions' => $transactions]);
        
    } catch (Exception $e) {
        error_log("Get user transactions error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to get user transactions: ' . $e->getMessage()]);
    }
}

/**
 * SIMPLE: Get completed order details for modal
 */
function handleGetCompletedOrderDetailsSimple($conn) {
    $order_id = (int)($_REQUEST['order_id'] ?? 0);
    
    if ($order_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Valid order ID is required']);
        return;
    }
    
    try {
        // Simple query that works with any schema
        $query = "
            SELECT 
                t.*,
                u.firstName,
                u.lastName,
                u.username,
                u.email,
                u.contact_number,
                u.address,
                'Completed' as order_status
            FROM transactions t
            LEFT JOIN users u ON t.user_id = u.user_id
            WHERE t.order_id = ?
        ";
        
        $stmt = $conn->prepare($query);
        $stmt->execute([$order_id]);
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$transaction) {
            echo json_encode(['success' => false, 'message' => 'Completed order not found']);
            return;
        }
        
        // Post-process the data
        // Build full name
        $firstName = $transaction['firstName'] ?? '';
        $lastName = $transaction['lastName'] ?? '';
        $username = $transaction['username'] ?? '';
        
        if (!empty($firstName) && !empty($lastName)) {
            $transaction['customer_name'] = $firstName . ' ' . $lastName;
        } elseif (!empty($firstName)) {
            $transaction['customer_name'] = $firstName;
        } elseif (!empty($username)) {
            $transaction['customer_name'] = $username;
        } else {
            $transaction['customer_name'] = 'Unknown Customer';
        }
        
        // Set email
        $transaction['customer_email'] = $transaction['email'] ?? 'unknown@email.com';
        
        // Set contact
        $transaction['customer_contact'] = $transaction['contact_number'] ?? '';
        
        // Set amount (try different possible column names)
        $transaction['amount'] = $transaction['total_amount'] ?? $transaction['amount'] ?? 0;
        
        // Set payment method
        $transaction['payment_method'] = $transaction['payment_method'] ?? 'COD';
        
        // Set delivery method
        $transaction['delivery_method'] = $transaction['delivery_method'] ?? 'Delivery';
        
        // Set delivery fee
        $transaction['delivery_fee'] = $transaction['delivery_fee'] ?? 0;
        
        // Set subtotal
        $transaction['subtotal'] = $transaction['subtotal'] ?? 0;
        
        // Parse items JSON
        $items = [];
        if (!empty($transaction['items']) && $transaction['items'] !== 'NULL') {
            $items = json_decode($transaction['items'], true) ?: [];
        }
        
        // If no items in transactions table, try to get from order_items
        if (empty($items)) {
            // First check what columns exist in order_items table
            $checkOrderItemsStmt = $conn->prepare("SHOW TABLES LIKE 'order_items'");
            $checkOrderItemsStmt->execute();
            $orderItemsExists = $checkOrderItemsStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($orderItemsExists) {
                // Get order_items table structure
                $describeOrderItemsStmt = $conn->prepare("DESCRIBE order_items");
                $describeOrderItemsStmt->execute();
                $orderItemsColumns = $describeOrderItemsStmt->fetchAll(PDO::FETCH_COLUMN);
                
                // Build query based on available columns
                $selectFields = ['oi.quantity'];
                
                // Add price field - get from products table if not in order_items
                if (in_array('price', $orderItemsColumns)) {
                    $selectFields[] = 'oi.price';
                } else {
                    // Get price from products table instead
                    $selectFields[] = 'p.price';
                }
                
                // Add product name
                $selectFields[] = 'p.product_name as name';
                $selectFields[] = 'p.product_name as product_name';
                
                $itemsQuery = "
                    SELECT " . implode(', ', $selectFields) . "
                    FROM order_items oi
                    LEFT JOIN products p ON oi.product_id = p.product_id
                    WHERE oi.order_id = ?
                ";
                
                $itemsStmt = $conn->prepare($itemsQuery);
                $itemsStmt->execute([$order_id]);
                $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
            }
        }
        
        // Add items to transaction data
        $transaction['items'] = $items;
        
        echo json_encode(['success' => true, 'order' => $transaction]);
        
    } catch (Exception $e) {
        error_log("Get completed order details error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to get order details: ' . $e->getMessage()]);
    }
}

?>
