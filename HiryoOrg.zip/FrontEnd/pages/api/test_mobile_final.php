<?php
/**
 * Test Mobile Final
 * This script tests the complete mobile API setup
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Test the correct mobile API URL
    $correctApiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_all_products';
    
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 10
        ]
    ]);
    
    $response = @file_get_contents($correctApiUrl, false, $context);
    $productsResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['correct_api_url_test'] = [
        'status' => $productsResult['success'] ? 'PASS' : 'FAIL',
        'message' => $productsResult['success'] ? 'Correct API URL working' : 'Correct API URL failed: ' . ($productsResult['message'] ?? 'Unknown error'),
        'api_url' => $correctApiUrl,
        'products_count' => isset($productsResult['products']) ? count($productsResult['products']) : 0,
        'response_format' => [
            'has_success' => isset($productsResult['success']),
            'has_products' => isset($productsResult['products']),
            'has_message' => isset($productsResult['message']),
            'has_count' => isset($productsResult['count']),
            'has_total_count' => isset($productsResult['total_count'])
        ]
    ];
    
    // Test 2: Test the wrong URL (for comparison)
    $wrongApiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/FrontEnd/pages/api/products_api.php?action=get_all_products';
    
    $wrongResponse = @file_get_contents($wrongApiUrl, false, $context);
    $wrongResult = $wrongResponse ? json_decode($wrongResponse, true) : ['success' => false, 'message' => 'No response from wrong URL'];
    
    $testResults['tests']['wrong_api_url_test'] = [
        'status' => $wrongResult['success'] ? 'WARNING' : 'PASS',
        'message' => $wrongResult['success'] ? 'Wrong URL unexpectedly working' : 'Wrong URL correctly failing (as expected)',
        'wrong_api_url' => $wrongApiUrl,
        'wrong_url_works' => $wrongResult['success']
    ];
    
    // Test 3: Check if all required fields are present
    if ($productsResult['success']) {
        $requiredFields = ['success', 'products', 'message', 'count', 'total_count'];
        $actualFields = array_keys($productsResult);
        $missingFields = array_diff($requiredFields, $actualFields);
        
        $testResults['tests']['required_fields_test'] = [
            'status' => empty($missingFields) ? 'PASS' : 'FAIL',
            'message' => empty($missingFields) ? 'All required fields present' : 'Missing fields: ' . implode(', ', $missingFields),
            'required_fields' => $requiredFields,
            'actual_fields' => $actualFields,
            'missing_fields' => array_values($missingFields)
        ];
    }
    
    // Test 4: Check product data integrity
    if ($productsResult['success'] && isset($productsResult['products']) && count($productsResult['products']) > 0) {
        $sampleProduct = $productsResult['products'][0];
        $dataIssues = [];
        
        // Check required product fields
        $requiredProductFields = ['product_id', 'product_name', 'category', 'price', 'stock_quantity', 'status'];
        foreach ($requiredProductFields as $field) {
            if (!isset($sampleProduct[$field])) {
                $dataIssues[] = "Missing field: $field";
            }
        }
        
        // Check data types
        if (isset($sampleProduct['product_id']) && !is_numeric($sampleProduct['product_id'])) {
            $dataIssues[] = 'product_id is not numeric';
        }
        
        if (isset($sampleProduct['price']) && !is_numeric($sampleProduct['price'])) {
            $dataIssues[] = 'price is not numeric';
        }
        
        $testResults['tests']['product_data_integrity'] = [
            'status' => empty($dataIssues) ? 'PASS' : 'FAIL',
            'message' => empty($dataIssues) ? 'Product data integrity OK' : 'Data issues: ' . implode(', ', $dataIssues),
            'data_issues' => $dataIssues,
            'sample_product' => $sampleProduct
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    $warningCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
        if ($test['status'] === 'WARNING') $warningCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'warnings' => $warningCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'mobile_app_should_work' => $failCount === 0 ? 'YES - Mobile app should now work!' : 'NO - Still has issues',
        'correct_api_url' => $correctApiUrl,
        'mobile_app_config' => [
            'old_url' => 'https://hiryoorganics.swuitapp.com/FrontEnd/pages/api/',
            'new_url' => 'https://hiryoorganics.swuitapp.com/HiryoOrg/FrontEnd/pages/api/',
            'issue_fixed' => 'Added missing /HiryoOrg/ path'
        ],
        'recommendations' => $failCount === 0 ? [
            '1. Mobile app should now load products successfully',
            '2. The 404 error should be resolved',
            '3. All API fields are correctly formatted'
        ] : [
            '1. Fix remaining API issues',
            '2. Check mobile app configuration',
            '3. Verify database connection'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'mobile_final_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
