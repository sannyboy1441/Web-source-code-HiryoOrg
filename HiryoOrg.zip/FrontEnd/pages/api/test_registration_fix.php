<?php
/**
 * Test Registration Fix
 * This script tests the registration functionality
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check if API files exist
    $apiFiles = [
        'users_api.php' => __DIR__ . '/users_api.php',
        'login.php' => __DIR__ . '/login.php'
    ];
    
    foreach ($apiFiles as $filename => $path) {
        $testResults['tests']["api_file_$filename"] = [
            'status' => file_exists($path) ? 'PASS' : 'FAIL',
            'message' => file_exists($path) ? "API file exists: $filename" : "Missing API file: $filename",
            'file_path' => $path
        ];
    }
    
    // Test 2: Test registration API with GET request (workaround)
    $registrationUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/users_api.php';
    $registrationData = [
        'action' => 'add_user',
        'firstName' => 'Test',
        'lastName' => 'User',
        'email' => 'testuser' . time() . '@example.com',
        'contact_number' => '09123456789',
        'username' => 'testuser' . time(),
        'address' => 'Test Address',
        'password' => 'password123',
        'role' => 'customer'
    ];
    
    $getUrl = $registrationUrl . '?' . http_build_query($registrationData);
    
    $response = @file_get_contents($getUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $registrationResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['registration_api'] = [
        'status' => $registrationResult['success'] ? 'PASS' : 'FAIL',
        'message' => $registrationResult['success'] ? 'Registration API working!' : 'Registration failed: ' . ($registrationResult['message'] ?? 'Unknown error'),
        'api_url' => $getUrl,
        'response' => $registrationResult,
        'workaround_method' => 'GET request (due to server POST issue)'
    ];
    
    // Test 3: Test login API with GET request (workaround)
    $loginUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/login.php';
    $loginData = [
        'email' => 'testuser',
        'password' => 'password123'
    ];
    
    $loginGetUrl = $loginUrl . '?' . http_build_query($loginData);
    
    $loginResponse = @file_get_contents($loginGetUrl, false, stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 15
        ]
    ]));
    
    $loginResult = $loginResponse ? json_decode($loginResponse, true) : ['success' => false, 'message' => 'No response from API'];
    
    $testResults['tests']['login_api'] = [
        'status' => $loginResult['success'] ? 'PASS' : 'FAIL',
        'message' => $loginResult['success'] ? 'Login API working!' : 'Login failed: ' . ($loginResult['message'] ?? 'Unknown error'),
        'api_url' => $loginGetUrl,
        'response' => $loginResult,
        'workaround_method' => 'GET request (due to server POST issue)'
    ];
    
    // Test 4: Verify database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if ($conn) {
        $stmt = $conn->prepare("SELECT user_id, username, email FROM users WHERE username = 'testuser' LIMIT 1");
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['database_connection'] = [
            'status' => $user ? 'PASS' : 'FAIL',
            'message' => $user ? 'Database connection working and test user found' : 'Database connection working but test user not found',
            'user_data' => $user
        ];
    } else {
        $testResults['tests']['database_connection'] = [
            'status' => 'FAIL',
            'message' => 'Database connection failed'
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'registration_should_work' => $failCount === 0 ? 'YES - Registration should work now!' : 'NO - Still has issues',
        'fixes_applied' => [
            '1. Fixed API URLs (changed from local IP to Hostinger)',
            '2. Updated Register.java to use Hostinger URLs',
            '3. Applied GET workaround for server POST issue',
            '4. Updated users_api.php to handle GET requests',
            '5. Updated login.php to handle GET requests',
            '6. Increased connection timeouts to 15 seconds'
        ],
        'recommendations' => $failCount === 0 ? [
            '1. Mobile app registration should work now',
            '2. Auto-login after registration should work',
            '3. No more network connection errors',
            '4. Test mobile app registration!'
        ] : [
            '1. Fix remaining API issues',
            '2. Check database connections',
            '3. Verify file permissions'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'registration_fix_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
