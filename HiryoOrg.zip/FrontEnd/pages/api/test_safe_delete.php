<?php
/**
 * Test Safe Delete
 * This script finds products that can be safely deleted (no orders referencing them)
 */

header('Content-Type: application/json');

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Find products that are NOT referenced in order_items
    $stmt = $conn->prepare("
        SELECT p.product_id, p.product_name, p.category, p.price, p.status
        FROM products p
        LEFT JOIN order_items oi ON p.product_id = oi.product_id
        WHERE oi.product_id IS NULL
        ORDER BY p.product_id DESC
        LIMIT 10
    ");
    $stmt->execute();
    $safeProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['safe_to_delete_products'] = [
        'status' => 'INFO',
        'message' => 'Products that can be safely deleted (no orders referencing them)',
        'count' => count($safeProducts),
        'products' => $safeProducts
    ];
    
    // Test 2: Find products that ARE referenced in order_items
    $stmt = $conn->prepare("
        SELECT DISTINCT p.product_id, p.product_name, COUNT(oi.id) as order_count
        FROM products p
        INNER JOIN order_items oi ON p.product_id = oi.product_id
        GROUP BY p.product_id, p.product_name
        ORDER BY order_count DESC
        LIMIT 10
    ");
    $stmt->execute();
    $referencedProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $testResults['tests']['referenced_products'] = [
        'status' => 'INFO',
        'message' => 'Products that CANNOT be deleted (have orders referencing them)',
        'count' => count($referencedProducts),
        'products' => $referencedProducts
    ];
    
    // Test 3: Test deleting a safe product (if any exist)
    if (count($safeProducts) > 0) {
        $testProduct = $safeProducts[0]; // Get the first safe product
        
        // Test the delete API
        $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php';
        $deleteData = http_build_query([
            'action' => 'delete_product',
            'product_id' => $testProduct['product_id']
        ]);
        
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/x-www-form-urlencoded',
                'content' => $deleteData,
                'timeout' => 10
            ]
        ]);
        
        $response = @file_get_contents($apiUrl, false, $context);
        $deleteResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'No response from API'];
        
        $testResults['tests']['test_safe_delete'] = [
            'status' => $deleteResult['success'] ? 'PASS' : 'FAIL',
            'message' => $deleteResult['success'] ? 'Successfully deleted safe product' : 'Failed to delete safe product',
            'product_id' => $testProduct['product_id'],
            'product_name' => $testProduct['product_name'],
            'api_response' => $deleteResult,
            'raw_response' => $response
        ];
        
        // Test 4: Verify product is actually deleted
        if ($deleteResult['success']) {
            $verifyStmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
            $verifyStmt->execute([$testProduct['product_id']]);
            $productStillExists = $verifyStmt->fetch(PDO::FETCH_ASSOC);
            
            $testResults['tests']['verify_safe_delete'] = [
                'status' => !$productStillExists ? 'PASS' : 'FAIL',
                'message' => !$productStillExists ? 'Safe product successfully deleted from database' : 'Safe product still exists in database',
                'product_still_exists' => $productStillExists ? true : false
            ];
        }
    } else {
        $testResults['tests']['test_safe_delete'] = [
            'status' => 'INFO',
            'message' => 'No products available for safe deletion testing'
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'recommendations' => [
            '1. Only delete products with 0 orders referencing them',
            '2. Products with orders cannot be deleted due to foreign key constraints',
            '3. Consider using soft delete (status change) for products with orders',
            '4. Or implement cascade delete to remove orders when deleting products'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'safe_delete_test',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
