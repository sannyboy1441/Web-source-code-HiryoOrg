<?php
/**
 * Test Hard Delete Functionality
 * This script tests that products are actually deleted from the database
 */

header('Content-Type: application/json');

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Count products before test
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products");
    $stmt->execute();
    $productsBefore = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    $testResults['tests']['products_before'] = [
        'status' => 'INFO',
        'message' => 'Products count before test',
        'count' => $productsBefore
    ];
    
    // Test 2: Add a test product to delete
    $testProductName = 'DELETE TEST PRODUCT ' . time();
    $insertStmt = $conn->prepare("
        INSERT INTO products (product_name, category, price, stock_quantity, description, status, created_at, updated_at)
        VALUES (?, 'Test', 99.99, 5, 'This product will be deleted', 'Active', NOW(), NOW())
    ");
    $insertResult = $insertStmt->execute([$testProductName]);
    
    if ($insertResult) {
        $testProductId = $conn->lastInsertId();
        
        $testResults['tests']['add_test_product'] = [
            'status' => 'PASS',
            'message' => 'Test product added successfully',
            'product_id' => $testProductId,
            'product_name' => $testProductName
        ];
        
        // Test 3: Verify product exists in database
        $checkStmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
        $checkStmt->execute([$testProductId]);
        $productExists = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['verify_product_exists'] = [
            'status' => $productExists ? 'PASS' : 'FAIL',
            'message' => $productExists ? 'Product exists in database' : 'Product not found in database',
            'product_data' => $productExists
        ];
        
        // Test 4: Test the delete API
        $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php';
        $deleteData = http_build_query([
            'action' => 'delete_product',
            'product_id' => $testProductId
        ]);
        
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/x-www-form-urlencoded',
                'content' => $deleteData,
                'timeout' => 10
            ]
        ]);
        
        $response = @file_get_contents($apiUrl, false, $context);
        $deleteResult = $response ? json_decode($response, true) : ['success' => false, 'message' => 'Delete API call failed'];
        
        $testResults['tests']['delete_api_test'] = [
            'status' => $deleteResult['success'] ? 'PASS' : 'FAIL',
            'message' => $deleteResult['success'] ? 'Delete API call successful' : 'Delete API call failed: ' . ($deleteResult['message'] ?? 'Unknown error'),
            'api_response' => $deleteResult
        ];
        
        // Test 5: Verify product is actually deleted from database
        $verifyStmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
        $verifyStmt->execute([$testProductId]);
        $productStillExists = $verifyStmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['verify_product_deleted'] = [
            'status' => !$productStillExists ? 'PASS' : 'FAIL',
            'message' => !$productStillExists ? 'Product successfully deleted from database' : 'Product still exists in database (soft delete)',
            'product_still_exists' => $productStillExists ? true : false
        ];
        
    } else {
        $testResults['tests']['add_test_product'] = [
            'status' => 'FAIL',
            'message' => 'Failed to add test product'
        ];
    }
    
    // Test 6: Count products after test
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products");
    $stmt->execute();
    $productsAfter = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    $testResults['tests']['products_after'] = [
        'status' => 'INFO',
        'message' => 'Products count after test',
        'count' => $productsAfter,
        'difference' => $productsAfter - $productsBefore
    ];
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'hard_delete_working' => isset($testResults['tests']['verify_product_deleted']) && $testResults['tests']['verify_product_deleted']['status'] === 'PASS',
        'recommendation' => 'Hard delete is now working - products are permanently removed from database'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'hard_delete_functionality',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
