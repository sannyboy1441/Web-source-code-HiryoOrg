<?php
// Test order completion LIVE on server
header('Content-Type: text/plain');

echo "=== LIVE ORDER COMPLETION TEST ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Find any order that can be completed
    $order_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders WHERE status IN ('Delivered', 'Shipped', 'Processing') LIMIT 1");
    $order_stmt->execute();
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "❌ No orders found that can be completed!\n";
        echo "Available orders:\n";
        $all_orders_stmt = $conn->prepare("SELECT order_id, status FROM orders ORDER BY order_id DESC LIMIT 5");
        $all_orders_stmt->execute();
        $all_orders = $all_orders_stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($all_orders as $o) {
            echo "   - Order #{$o['order_id']}: {$o['status']}\n";
        }
        exit;
    }
    
    $test_order_id = $order['order_id'];
    echo "✅ Found order #$test_order_id (Status: {$order['status']}) to test with\n\n";
    
    // Test the API call directly
    echo "=== TESTING API CALL ===\n";
    
    // Set up POST data
    $_POST = [];
    $_POST['order_id'] = $test_order_id;
    $_POST['status'] = 'Completed';
    $_GET = [];
    $_GET['action'] = 'update_order_status';
    
    echo "Making API call: order_id=$test_order_id, status=Completed\n";
    
    // Capture the API response
    ob_start();
    
    // Include the API file
    include 'orders_api_fixed.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Check if order was transferred
    echo "=== CHECKING RESULTS ===\n";
    
    // Check if order still exists in orders table
    $check_order_stmt = $conn->prepare("SELECT order_id, status FROM orders WHERE order_id = ?");
    $check_order_stmt->execute([$test_order_id]);
    $order_after = $check_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_after) {
        echo "❌ Order #$test_order_id still exists in orders table: {$order_after['status']}\n";
    } else {
        echo "✅ Order #$test_order_id removed from orders table\n";
    }
    
    // Check if order exists in transactions table
    $check_trans_stmt = $conn->prepare("SELECT transaction_id, customer_name, amount FROM transactions WHERE order_id = ?");
    $check_trans_stmt->execute([$test_order_id]);
    $transaction = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($transaction) {
        echo "✅ Order #$test_order_id transferred to transactions table:\n";
        echo "   - Transaction ID: {$transaction['transaction_id']}\n";
        echo "   - Customer: {$transaction['customer_name']}\n";
        echo "   - Amount: {$transaction['amount']}\n";
    } else {
        echo "❌ Order #$test_order_id NOT found in transactions table\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if (!$order_after && $transaction) {
        echo "🎉 SUCCESS: Order completion worked!\n";
    } else {
        echo "❌ FAILURE: Order completion did not work properly\n";
        echo "API Response was: $api_response\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
