<?php
// Fixed order completion API with better error handling
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Prevent multiple executions
if (defined('ORDERS_API_FIXED_V3_EXECUTED')) {
    exit(json_encode(['success' => false, 'message' => 'API already executed']));
}
define('ORDERS_API_FIXED_V3_EXECUTED', true);

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../datab_try.php';

try {
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $action = $_POST['action'] ?? $_GET['action'] ?? '';
    
    switch ($action) {
        case 'get_all_orders_for_admin':
            handleGetAllOrdersForAdmin($conn);
            break;
            
        case 'get_order_details':
            handleGetOrderDetails($conn);
            break;
            
        case 'update_order_status':
            handleUpdateOrderStatus($conn);
            break;
            
        case 'place_order':
            handlePlaceOrder($conn);
            break;
            
        case 'get_user_orders':
            handleGetUserOrders($conn);
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action specified']);
            break;
    }
    
} catch (Exception $e) {
    error_log("Orders API Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error occurred: ' . $e->getMessage()]);
}

function handleGetAllOrdersForAdmin($conn) {
    try {
        // Only get active orders (not completed or cancelled)
        $stmt = $conn->prepare("
            SELECT 
                o.order_id,
                o.user_id,
                o.status,
                o.delivery_method,
                o.payment_method,
                o.shipping_address,
                o.subtotal,
                o.delivery_fee,
                o.total_amount,
                o.order_date,
                CONCAT(COALESCE(u.firstName, ''), ' ', COALESCE(u.lastName, '')) as customer_name,
                u.email as customer_email,
                u.contact_number as customer_contact
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.user_id
            WHERE o.status NOT IN ('Completed', 'Cancelled')
            ORDER BY o.order_date DESC
        ");
        
        $stmt->execute();
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Process orders to ensure customer names are properly formatted
        foreach ($orders as &$order) {
            $order['customer_name'] = trim($order['customer_name']) ?: 'Unknown Customer';
        }
        
        echo json_encode(['success' => true, 'orders' => $orders]);
        
    } catch (Exception $e) {
        error_log("Error in handleGetAllOrdersForAdmin: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to fetch orders: ' . $e->getMessage()]);
    }
}

function handleGetOrderDetails($conn) {
    try {
        $order_id = (int)($_GET['order_id'] ?? 0);
        
        if ($order_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Valid order ID required']);
            return;
        }
        
        // Get order details
        $order_stmt = $conn->prepare("
            SELECT 
                o.*,
                u.firstName,
                u.lastName,
                u.email,
                u.contact_number,
                u.address
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.user_id
            WHERE o.order_id = ?
        ");
        $order_stmt->execute([$order_id]);
        $order = $order_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo json_encode(['success' => false, 'message' => 'Order not found']);
            return;
        }
        
        // Get order items
        $items_stmt = $conn->prepare("
            SELECT 
                oi.*,
                p.product_name
            FROM order_items oi
            LEFT JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = ?
        ");
        $items_stmt->execute([$order_id]);
        $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $order['items'] = $items;
        
        echo json_encode(['success' => true, 'order' => $order]);
        
    } catch (Exception $e) {
        error_log("Error in handleGetOrderDetails: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to get order details: ' . $e->getMessage()]);
    }
}

function handleUpdateOrderStatus($conn) {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $status = $_POST['status'] ?? '';

    if ($order_id <= 0 || empty($status)) {
        echo json_encode(['success' => false, 'message' => 'Valid order ID and status are required']);
        return;
    }

    try {
        if (strtolower($status) === 'completed' || strtolower($status) === 'cancelled') {
            // CRITICAL FIX: Insert into transactions FIRST, then delete from orders
            
            // Step 1: Get order details
            $order_stmt = $conn->prepare("
                SELECT o.*, u.firstName, u.lastName, u.email, u.contact_number, u.address
                FROM orders o
                LEFT JOIN users u ON o.user_id = u.user_id
                WHERE o.order_id = ?
            ");
            $order_stmt->execute([$order_id]);
            $order = $order_stmt->fetch(PDO::FETCH_ASSOC);

            if (!$order) {
                throw new Exception("Order #$order_id not found for transfer");
            }

            // Step 2: Get order items
            $items_stmt = $conn->prepare("
                SELECT oi.*, p.product_name
                FROM order_items oi
                LEFT JOIN products p ON oi.product_id = p.product_id
                WHERE oi.order_id = ?
            ");
            $items_stmt->execute([$order_id]);
            $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

            // Step 3: Insert into transactions table FIRST with better error handling
            $trans_stmt = $conn->prepare("
                INSERT INTO transactions (
                    order_id, user_id, customer_name, customer_email, customer_contact,
                    delivery_method, payment_method, shipping_address, subtotal,
                    delivery_fee, amount, created_at, items
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
            ");

            $customer_name = trim(($order['firstName'] ?? '') . ' ' . ($order['lastName'] ?? ''));
            $items_json = json_encode($items);

            // Execute with error checking
            $trans_result = $trans_stmt->execute([
                $order_id,
                $order['user_id'],
                $customer_name,
                $order['email'],
                $order['contact_number'],
                $order['delivery_method'],
                $order['payment_method'],
                $order['shipping_address'],
                $order['subtotal'],
                $order['delivery_fee'],
                $order['total_amount'],
                $items_json
            ]);

            // Check for execution errors
            if (!$trans_result) {
                $error_info = $trans_stmt->errorInfo();
                throw new Exception("Failed to insert order #$order_id into transactions table: " . $error_info[2]);
            }

            // Verify the insert actually worked by checking if the record exists
            $verify_stmt = $conn->prepare("SELECT transaction_id FROM transactions WHERE order_id = ?");
            $verify_stmt->execute([$order_id]);
            $transaction_id = $verify_stmt->fetchColumn();

            if (!$transaction_id) {
                throw new Exception("Order #$order_id was not actually inserted into transactions table");
            }

            // Step 4: Only after successful insert and verification, delete order items
            $delete_items_stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
            $delete_items_stmt->execute([$order_id]);

            // Step 5: Finally, delete from orders table
            $delete_stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
            $delete_stmt->execute([$order_id]);

            // Final verification
            $final_verify_stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ?");
            $final_verify_stmt->execute([$order_id]);
            $still_exists = $final_verify_stmt->fetch();

            if ($still_exists) {
                throw new Exception("Order #$order_id still exists in orders table after deletion");
            }

        } else {
            // For non-completion status updates, just update the status
            $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
            $result = $stmt->execute([$status, $order_id]);

            if (!$result) {
                throw new Exception('Failed to update order status');
            }
        }

        echo json_encode(['success' => true, 'message' => 'Order status updated successfully']);

    } catch (Exception $e) {
        error_log("Error in handleUpdateOrderStatus: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Server error occurred: ' . $e->getMessage()]);
    }
}

function handlePlaceOrder($conn) {
    try {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $items_json = $_POST['items'] ?? '[]';
        $delivery_method = $_POST['delivery_method'] ?? 'Delivery';
        $payment_method = $_POST['payment_method'] ?? 'Cash';
        $shipping_address = $_POST['shipping_address'] ?? '';
        $subtotal = (float)($_POST['subtotal'] ?? 0);
        $delivery_fee = (float)($_POST['delivery_fee'] ?? 0);
        $total_amount = (float)($_POST['total_amount'] ?? 0);

        if ($user_id <= 0 || $total_amount <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid order data']);
            return;
        }

        // Insert order
        $order_stmt = $conn->prepare("
            INSERT INTO orders (user_id, delivery_method, payment_method, shipping_address, subtotal, delivery_fee, total_amount, status, order_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $order_result = $order_stmt->execute([
            $user_id, $delivery_method, $payment_method, $shipping_address, 
            $subtotal, $delivery_fee, $total_amount
        ]);

        if (!$order_result) {
            throw new Exception('Failed to create order');
        }

        $order_id = $conn->lastInsertId();

        // Insert order items
        $items = json_decode($items_json, true);
        if (is_array($items)) {
            foreach ($items as $item) {
                $item_stmt = $conn->prepare("
                    INSERT INTO order_items (order_id, product_id, quantity, price)
                    VALUES (?, ?, ?, ?)
                ");
                
                $item_stmt->execute([
                    $order_id,
                    $item['product_id'] ?? $item['id'] ?? 0,
                    $item['quantity'] ?? 1,
                    $item['price'] ?? 0
                ]);
            }
        }

        echo json_encode([
            'success' => true, 
            'message' => 'Order placed successfully',
            'order_id' => $order_id
        ]);

    } catch (Exception $e) {
        error_log("Error in handlePlaceOrder: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to place order: ' . $e->getMessage()]);
    }
}

function handleGetUserOrders($conn) {
    try {
        $user_id = (int)($_GET['user_id'] ?? 0);
        
        if ($user_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Valid user ID required']);
            return;
        }

        $stmt = $conn->prepare("
            SELECT 
                o.order_id,
                o.status,
                o.delivery_method,
                o.total_amount,
                o.order_date,
                o.delivery_fee,
                o.subtotal
            FROM orders o
            WHERE o.user_id = ?
            ORDER BY o.order_date DESC
        ");
        
        $stmt->execute([$user_id]);
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'orders' => $orders]);
        
    } catch (Exception $e) {
        error_log("Error in handleGetUserOrders: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to fetch user orders: ' . $e->getMessage()]);
    }
}

// Ensure script exits after processing
exit();
?>
