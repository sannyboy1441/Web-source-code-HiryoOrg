<?php
/**
 * Test Products API directly
 */

header('Content-Type: application/json');

try {
    // Include database connection
    include_once '../datab_try.php';
    
    if (!function_exists('getDBConnection')) {
        throw new Exception('getDBConnection function not found');
    }
    
    $conn = getDBConnection();
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Test the exact action the script is calling
    $_GET['action'] = 'get_products_for_admin';
    
    // Include the products API
    ob_start();
    include 'products_api.php';
    $output = ob_get_clean();
    
    echo json_encode([
        'test_result' => 'success',
        'api_output' => $output,
        'output_length' => strlen($output),
        'is_json' => json_decode($output) !== null,
        'parsed_json' => json_decode($output, true)
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'test_result' => 'failed',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
