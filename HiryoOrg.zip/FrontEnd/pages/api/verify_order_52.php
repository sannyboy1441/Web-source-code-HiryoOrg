<?php
// Verify if Order #52 was transferred correctly
header('Content-Type: text/plain');

echo "=== VERIFYING ORDER #52 TRANSFER ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    $order_id = 52;
    
    // Check if Order #52 exists in orders table
    echo "=== CHECKING ORDERS TABLE ===\n";
    $order_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders WHERE order_id = ?");
    $order_stmt->execute([$order_id]);
    $order_exists = $order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order_exists) {
        echo "❌ Order #{$order_id} still exists in orders table:\n";
        echo "   - Status: {$order_exists['status']}\n";
        echo "   - Amount: {$order_exists['total_amount']}\n";
    } else {
        echo "✅ Order #{$order_id} NOT found in orders table (successfully removed)\n";
    }
    
    // Check if Order #52 exists in transactions table
    echo "\n=== CHECKING TRANSACTIONS TABLE ===\n";
    $trans_stmt = $conn->prepare("SELECT transaction_id, order_id, amount, customer_name FROM transactions WHERE order_id = ?");
    $trans_stmt->execute([$order_id]);
    $trans_exists = $trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($trans_exists) {
        echo "✅ Order #{$order_id} found in transactions table:\n";
        echo "   - Transaction ID: {$trans_exists['transaction_id']}\n";
        echo "   - Amount: {$trans_exists['amount']}\n";
        echo "   - Customer: {$trans_exists['customer_name']}\n";
    } else {
        echo "❌ Order #{$order_id} NOT found in transactions table!\n";
    }
    
    // Show current counts
    echo "\n=== CURRENT COUNTS ===\n";
    $orders_count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders");
    $orders_count_stmt->execute();
    $orders_count = $orders_count_stmt->fetch(PDO::FETCH_ASSOC);
    
    $trans_count_stmt = $conn->prepare("SELECT COUNT(*) as count FROM transactions");
    $trans_count_stmt->execute();
    $trans_count = $trans_count_stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "Orders in orders table: {$orders_count['count']}\n";
    echo "Transactions in transactions table: {$trans_count['count']}\n";
    
    // Show recent transactions
    echo "\n=== RECENT TRANSACTIONS ===\n";
    $recent_stmt = $conn->prepare("SELECT transaction_id, order_id, amount, customer_name FROM transactions ORDER BY transaction_id DESC LIMIT 3");
    $recent_stmt->execute();
    $recent_trans = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($recent_trans as $trans) {
        echo "Transaction #{$trans['transaction_id']}: Order #{$trans['order_id']}, Amount: {$trans['amount']}, Customer: {$trans['customer_name']}\n";
    }
    
    echo "\n=== FINAL RESULT ===\n";
    if (!$order_exists && $trans_exists) {
        echo "🎉 SUCCESS: Order #{$order_id} was successfully transferred!\n";
        echo "✅ Order removed from orders table\n";
        echo "✅ Order added to transactions table\n";
    } elseif ($order_exists && !$trans_exists) {
        echo "❌ FAILURE: Order #{$order_id} was NOT transferred properly\n";
        echo "❌ Order still in orders table\n";
        echo "❌ Order NOT in transactions table\n";
    } elseif (!$order_exists && !$trans_exists) {
        echo "❌ FAILURE: Order #{$order_id} was deleted but NOT transferred\n";
        echo "❌ Order removed from orders table\n";
        echo "❌ Order NOT in transactions table\n";
    } else {
        echo "⚠️ UNKNOWN: Order #{$order_id} exists in both tables (shouldn't happen)\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>
