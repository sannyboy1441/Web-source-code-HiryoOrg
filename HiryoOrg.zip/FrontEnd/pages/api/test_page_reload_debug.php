<?php
/**
 * Test Page Reload Debug
 * This script helps debug why products disappear on page reload
 */

header('Content-Type: application/json');

try {
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Check if the API is returning data correctly
    $apiUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_products_for_admin';
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 5
        ]
    ]);
    
    $response = @file_get_contents($apiUrl, false, $context);
    
    if ($response === false) {
        $testResults['tests']['api_check'] = [
            'status' => 'FAIL',
            'message' => 'API request failed',
            'url' => $apiUrl
        ];
    } else {
        $data = json_decode($response, true);
        
        $testResults['tests']['api_check'] = [
            'status' => $data && isset($data['success']) && $data['success'] ? 'PASS' : 'FAIL',
            'message' => $data && isset($data['success']) && $data['success'] ? 'API working correctly' : 'API error: ' . ($data['message'] ?? 'Unknown error'),
            'products_count' => isset($data['products']) ? count($data['products']) : 0,
            'url' => $apiUrl,
            'has_products' => isset($data['products']) && count($data['products']) > 0,
            'sample_products' => isset($data['products']) ? array_slice($data['products'], 0, 3) : []
        ];
        
        // Test 2: Check for any products with empty status
        if (isset($data['products'])) {
            $emptyStatusProducts = array_filter($data['products'], function($product) {
                return empty($product['status']) || $product['status'] === '';
            });
            
            $testResults['tests']['status_check'] = [
                'status' => count($emptyStatusProducts) === 0 ? 'PASS' : 'FAIL',
                'message' => count($emptyStatusProducts) === 0 ? 'All products have valid status' : 'Found ' . count($emptyStatusProducts) . ' products with empty status',
                'empty_status_count' => count($emptyStatusProducts),
                'empty_status_products' => array_values($emptyStatusProducts)
            ];
        }
        
        // Test 3: Check if there are any JavaScript errors by testing the actual page
        $pageUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/products.php';
        $pageContext = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => 'Accept: text/html',
                'timeout' => 5
            ]
        ]);
        
        $pageResponse = @file_get_contents($pageUrl, false, $pageContext);
        
        $testResults['tests']['page_check'] = [
            'status' => $pageResponse !== false ? 'PASS' : 'FAIL',
            'message' => $pageResponse !== false ? 'Products page accessible' : 'Products page not accessible',
            'page_url' => $pageUrl,
            'page_size' => $pageResponse ? strlen($pageResponse) : 0
        ];
    }
    
    // Test 4: Check if there might be a browser caching issue
    $cacheBustUrl = $apiUrl . '&_t=' . time();
    $cacheResponse = @file_get_contents($cacheBustUrl, false, $context);
    
    if ($cacheResponse !== false) {
        $cacheData = json_decode($cacheResponse, true);
        $testResults['tests']['cache_bust_check'] = [
            'status' => 'INFO',
            'message' => 'Cache-busted API test',
            'products_count' => isset($cacheData['products']) ? count($cacheData['products']) : 0,
            'cache_bust_url' => $cacheBustUrl
        ];
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'recommendations' => [
            '1. Clear browser cache (Ctrl+F5)',
            '2. Check browser console for JavaScript errors',
            '3. Verify products page loads correctly',
            '4. Test with different browser or incognito mode'
        ]
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'page_reload_debug',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
