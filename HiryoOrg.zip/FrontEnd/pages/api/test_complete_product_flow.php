<?php
/**
 * Test Complete Product Flow
 * This script tests the entire product lifecycle: add, display, update, delete
 */

header('Content-Type: application/json');

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    $testResults = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tests' => []
    ];
    
    // Test 1: Get initial products count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM products WHERE status = 'Active'");
    $stmt->execute();
    $initialCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
    $testResults['tests']['initial_products'] = [
        'status' => 'INFO',
        'message' => 'Initial products count',
        'count' => $initialCount
    ];
    
    // Test 2: Add a test product
    $testProductName = 'Flow Test Product ' . time();
    $testData = [
        'action' => 'add_product',
        'product_name' => $testProductName,
        'category' => 'Test',
        'price' => '199.99',
        'stock_quantity' => '5',
        'description' => 'Testing complete product flow',
        'product_sku' => 'FLOW-TEST-' . time(),
        'weight_value' => '2.5',
        'weight_unit' => 'kg'
    ];
    
    $_POST = $testData;
    ob_start();
    include 'products_api.php';
    $output = ob_get_clean();
    $addResult = json_decode($output, true);
    
    $testResults['tests']['add_product'] = [
        'status' => $addResult['success'] ? 'PASS' : 'FAIL',
        'message' => $addResult['success'] ? 'Product added successfully' : 'Failed to add product',
        'response' => $addResult,
        'product_id' => $addResult['success'] && isset($addResult['product']) ? $addResult['product']['product_id'] : null
    ];
    
    $productId = null;
    if ($addResult['success'] && isset($addResult['product']['product_id'])) {
        $productId = $addResult['product']['product_id'];
    }
    
    // Test 3: Verify product exists in database
    if ($productId) {
        $stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
        $stmt->execute([$productId]);
        $dbProduct = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $testResults['tests']['verify_database'] = [
            'status' => $dbProduct ? 'PASS' : 'FAIL',
            'message' => $dbProduct ? 'Product exists in database' : 'Product not found in database',
            'product_data' => $dbProduct
        ];
    }
    
    // Test 4: Get products for admin (what the web interface uses)
    $productsUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/HiryoOrg/FrontEnd/pages/api/products_api.php?action=get_products_for_admin';
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => 'Accept: application/json',
            'timeout' => 5
        ]
    ]);
    
    $response = @file_get_contents($productsUrl, false, $context);
    
    if ($response === false) {
        $testResults['tests']['get_products_admin'] = [
            'status' => 'FAIL',
            'message' => 'Failed to call get_products_for_admin API',
            'url' => $productsUrl
        ];
    } else {
        $adminProducts = json_decode($response, true);
        $foundTestProduct = false;
        
        if ($adminProducts['success'] && isset($adminProducts['products'])) {
            foreach ($adminProducts['products'] as $product) {
                if ($product['product_name'] === $testProductName) {
                    $foundTestProduct = true;
                    break;
                }
            }
        }
        
        $testResults['tests']['get_products_admin'] = [
            'status' => $adminProducts['success'] ? 'PASS' : 'FAIL',
            'message' => $adminProducts['success'] ? 'Get products for admin API working' : 'Get products for admin API failed',
            'products_count' => isset($adminProducts['products']) ? count($adminProducts['products']) : 0,
            'test_product_found' => $foundTestProduct,
            'response' => $adminProducts
        ];
    }
    
    // Test 5: Update the test product
    if ($productId) {
        $updateData = [
            'action' => 'update_product',
            'product_id' => $productId,
            'product_name' => $testProductName . ' - UPDATED',
            'price' => '299.99',
            'stock_quantity' => '10'
        ];
        
        $_POST = $updateData;
        ob_start();
        include 'products_api.php';
        $output = ob_get_clean();
        $updateResult = json_decode($output, true);
        
        $testResults['tests']['update_product'] = [
            'status' => $updateResult['success'] ? 'PASS' : 'FAIL',
            'message' => $updateResult['success'] ? 'Product updated successfully' : 'Failed to update product',
            'response' => $updateResult
        ];
    }
    
    // Test 6: Delete the test product (soft delete)
    if ($productId) {
        $deleteData = [
            'action' => 'delete_product',
            'product_id' => $productId
        ];
        
        $_POST = $deleteData;
        ob_start();
        include 'products_api.php';
        $output = ob_get_clean();
        $deleteResult = json_decode($output, true);
        
        $testResults['tests']['delete_product'] = [
            'status' => $deleteResult['success'] ? 'PASS' : 'FAIL',
            'message' => $deleteResult['success'] ? 'Product deleted successfully' : 'Failed to delete product',
            'response' => $deleteResult
        ];
        
        // Verify soft delete (status changed to 'Deleted')
        if ($deleteResult['success']) {
            $stmt = $conn->prepare("SELECT status FROM products WHERE product_id = ?");
            $stmt->execute([$productId]);
            $status = $stmt->fetch(PDO::FETCH_ASSOC)['status'] ?? 'Unknown';
            
            $testResults['tests']['verify_soft_delete'] = [
                'status' => $status === 'Deleted' ? 'PASS' : 'FAIL',
                'message' => $status === 'Deleted' ? 'Product soft deleted correctly' : 'Product not soft deleted correctly',
                'actual_status' => $status
            ];
        }
    }
    
    // Summary
    $passCount = 0;
    $failCount = 0;
    foreach ($testResults['tests'] as $test) {
        if ($test['status'] === 'PASS') $passCount++;
        if ($test['status'] === 'FAIL') $failCount++;
    }
    
    $testResults['summary'] = [
        'total_tests' => count($testResults['tests']),
        'passed' => $passCount,
        'failed' => $failCount,
        'status' => $failCount === 0 ? 'ALL TESTS PASSED ✅' : 'SOME TESTS FAILED ❌',
        'complete_flow_working' => $passCount >= 4, // At least add, verify, get, and delete should work
        'table_update_issue' => 'If database operations work but table doesn\'t update, the issue is in JavaScript rendering'
    ];
    
    echo json_encode($testResults, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'test' => 'complete_product_flow',
        'status' => '❌ ERROR',
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ]);
}
?>
