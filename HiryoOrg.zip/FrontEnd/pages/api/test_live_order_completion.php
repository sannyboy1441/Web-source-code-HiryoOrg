<?php
// Test live order completion process
header('Content-Type: text/plain');

echo "Testing Live Order Completion Process...\n\n";

try {
    // Include database connection
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "Database connection failed!\n";
        exit;
    }
    
    echo "Database connected successfully!\n\n";
    
    // Find an order with "Delivered" status
    echo "Looking for delivered orders...\n";
    $delivered_stmt = $conn->prepare("SELECT order_id, status, total_amount, order_date FROM orders WHERE status = 'Delivered' ORDER BY order_id DESC LIMIT 5");
    $delivered_stmt->execute();
    $delivered_orders = $delivered_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($delivered_orders)) {
        echo "No delivered orders found. Looking for any non-completed orders...\n";
        $any_stmt = $conn->prepare("SELECT order_id, status, total_amount, order_date FROM orders WHERE status NOT IN ('Completed', 'Cancelled') ORDER BY order_id DESC LIMIT 5");
        $any_stmt->execute();
        $delivered_orders = $any_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    if (empty($delivered_orders)) {
        echo "No orders available for testing!\n";
        exit;
    }
    
    echo "Available orders for testing:\n";
    foreach ($delivered_orders as $order) {
        echo "- Order #{$order['order_id']}: Status = {$order['status']}, Total = {$order['total_amount']}, Date = {$order['order_date']}\n";
    }
    echo "\n";
    
    // Use the first order for testing
    $test_order = $delivered_orders[0];
    $order_id = $test_order['order_id'];
    
    echo "Testing with Order #$order_id (Status: {$test_order['status']})...\n\n";
    
    // Step 1: Check initial state
    echo "=== STEP 1: Initial State ===\n";
    $initial_order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $initial_order_stmt->execute([$order_id]);
    $initial_order = $initial_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($initial_order) {
        echo "Order exists in orders table:\n";
        echo "- Status: {$initial_order['status']}\n";
        echo "- Total: {$initial_order['total_amount']}\n";
        echo "- Customer ID: {$initial_order['user_id']}\n";
    } else {
        echo "Order not found in orders table!\n";
        exit;
    }
    
    // Check if order exists in transactions
    $initial_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $initial_trans_stmt->execute([$order_id]);
    $initial_trans = $initial_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($initial_trans) {
        echo "Order already exists in transactions table!\n";
        exit;
    } else {
        echo "Order not found in transactions table (good for testing).\n";
    }
    echo "\n";
    
    // Step 2: Simulate the API call exactly as the web admin does
    echo "=== STEP 2: Simulating API Call ===\n";
    
    // Set up the POST data exactly as the web admin does
    $_POST = [];
    $_POST['order_id'] = $order_id;
    $_POST['status'] = 'Completed';
    
    echo "Making API call with: order_id=$order_id, status=Completed\n";
    
    // Capture output from the API
    ob_start();
    
    // Simulate the exact API call
    $_GET['action'] = 'update_order_status';
    include 'orders_api_v2.php';
    
    $api_response = ob_get_clean();
    
    echo "API Response: $api_response\n\n";
    
    // Step 3: Check final state
    echo "=== STEP 3: Final State ===\n";
    
    // Check if order still exists in orders table
    $final_order_stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
    $final_order_stmt->execute([$order_id]);
    $final_order = $final_order_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($final_order) {
        echo "❌ Order still exists in orders table:\n";
        echo "- Status: {$final_order['status']}\n";
        echo "- Total: {$final_order['total_amount']}\n";
    } else {
        echo "✅ Order removed from orders table\n";
    }
    
    // Check if order exists in transactions table
    $final_trans_stmt = $conn->prepare("SELECT * FROM transactions WHERE order_id = ?");
    $final_trans_stmt->execute([$order_id]);
    $final_trans = $final_trans_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($final_trans) {
        echo "✅ Order successfully transferred to transactions table:\n";
        echo "- Transaction ID: {$final_trans['transaction_id']}\n";
        echo "- Customer: {$final_trans['customer_name']}\n";
        echo "- Amount: {$final_trans['amount']}\n";
        echo "- Created: {$final_trans['created_at']}\n";
    } else {
        echo "❌ Order NOT found in transactions table - TRANSFER FAILED!\n";
    }
    
    echo "\n=== SUMMARY ===\n";
    if (!$final_order && $final_trans) {
        echo "🎉 SUCCESS: Order completion process worked perfectly!\n";
        echo "- Order removed from orders table ✅\n";
        echo "- Order transferred to transactions table ✅\n";
    } elseif ($final_order && !$final_trans) {
        echo "❌ FAILURE: Order completion process failed completely!\n";
        echo "- Order still in orders table ❌\n";
        echo "- Order not in transactions table ❌\n";
    } elseif (!$final_order && !$final_trans) {
        echo "⚠️  CRITICAL FAILURE: Order was deleted but not transferred!\n";
        echo "- Order removed from orders table ✅\n";
        echo "- Order NOT transferred to transactions table ❌\n";
        echo "- DATA LOST! This is exactly the problem you're experiencing.\n";
    } else {
        echo "🤔 UNEXPECTED: Order exists in both tables!\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
