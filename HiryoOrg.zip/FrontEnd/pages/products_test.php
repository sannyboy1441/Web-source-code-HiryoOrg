<?php include '../php/session_admin.php'; ?>
<link rel="stylesheet" href="../styles/components/shared.css">
<link rel="stylesheet" href="../styles/products_optimized.css">

<section class="page" id="products">
    <!-- Page Header -->
    <div class="page-header green">
        <div class="header-content">
            <div class="header-title">
                <h1>Admin Panel</h1>
            </div>
        </div>
    </div>

    <!-- Search and Filter Section -->
    <div class="filter-section">
        <div class="filter-container">
            <!-- Search Bar -->
            <div class="search-container">
                <div class="search-input-group">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="productSearch" class="search-input" placeholder="Search products...">
                    <button class="clear-search-btn" onclick="clearProductSearch()">✕</button>
                </div>
            </div>
            
            <!-- Filter Controls -->
            <div class="filter-controls">
                <div class="filter-group">
                    <label for="productCategoryFilter">Category:</label>
                    <select id="productCategoryFilter" class="filter-select">
                        <option value="">All Categories</option>
                        <option value="Fertilizer">🌱 Fertilizer</option>
                        <option value="Soil">🌍 Soil</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="productStatusFilter">Status:</label>
                    <select id="productStatusFilter" class="filter-select">
                        <option value="">All Status</option>
                        <option value="Active">✅ Active</option>
                        <option value="Inactive">❌ Inactive</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="productStockFilter">Stock:</label>
                    <select id="productStockFilter" class="filter-select">
                        <option value="">All Stock</option>
                        <option value="in-stock">📦 In Stock</option>
                        <option value="low-stock">⚠️ Low Stock</option>
                        <option value="out-of-stock">🚫 Out of Stock</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="productSort">Sort By:</label>
                    <select id="productSort" class="filter-select">
                        <option value="name-asc">Name A-Z</option>
                        <option value="name-desc">Name Z-A</option>
                        <option value="price-asc">Price Low-High</option>
                        <option value="price-desc">Price High-Low</option>
                        <option value="stock-asc">Stock Low-High</option>
                        <option value="stock-desc">Stock High-Low</option>
                    </select>
                </div>
                
                <button class="btn secondary" onclick="clearProductFilters()">
                    <span class="btn-icon">🔄</span>
                    Clear Filters
                </button>
            </div>
        </div>
    </div>

    <!-- Products Table Section -->
    <div class="enhanced-table">
        <div class="table-header">
            <div class="header-content">
                <h3 class="table-title">Products Management</h3>
                <div class="header-actions">
                    <button class="btn brand" onclick="showAddProductModal()">
                        <span class="btn-icon">➕</span>
                        Add Product
                    </button>
                    <button class="btn secondary" onclick="refreshProducts()">
                        <span class="btn-icon">🔄</span>
                        Refresh
                    </button>
                </div>
            </div>
        </div>
        
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th class="image-column">Image</th>
                        <th class="name-column">Product Name</th>
                        <th class="category-column">Category</th>
                        <th class="price-column">Price</th>
                        <th class="stock-column">Stock</th>
                        <th class="status-column">Status</th>
                        <th class="actions-column">Actions</th>
                    </tr>
                </thead>
                <tbody id="productRows">
                    <tr>
                        <td colspan="7" class="loading-row">
                            <div class="loading-spinner">
                                <span class="spinner">⏳</span>
                                Loading products...
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</section>

<!-- Add Product Modal -->
<div id="productModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="productModalTitle">Add New Product</h2>
            <span class="close" onclick="closeProductModal()">&times;</span>
        </div>
        
        <form id="productForm">
            <div style="padding: 24px;">
                <div class="form-row">
                    <div class="form-group">
                        <label for="productName">Product Name *</label>
                        <input type="text" id="productName" name="product_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="productCategory">Category *</label>
                        <select id="productCategory" name="category" required>
                            <option value="">Select Category</option>
                            <option value="Fertilizer">🌱 Fertilizer</option>
                            <option value="Soil">🌍 Soil</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="productPrice">Price *</label>
                        <input type="number" id="productPrice" name="price" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="productStock">Stock Quantity *</label>
                        <input type="number" id="productStock" name="stock_quantity" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="productDescription">Description</label>
                    <textarea id="productDescription" name="description" rows="3"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="productImage">Product Image</label>
                    <input type="file" id="productImage" name="product_image" accept="image/*">
                </div>
            </div>
            
            <div class="modal-actions">
                <button type="button" class="btn secondary" onclick="closeProductModal()">Cancel</button>
                <button type="submit" class="btn brand">Add Product</button>
            </div>
        </form>
    </div>
</div>
