<?php
// Test the fixed order completion process
header('Content-Type: text/plain');

echo "=== TESTING FIXED ORDER COMPLETION PROCESS ===\n\n";

try {
    require_once '../datab_try.php';
    $conn = getDBConnection();
    
    if (!$conn) {
        echo "❌ Database connection failed!\n";
        exit;
    }
    
    echo "✅ Database connected successfully!\n\n";
    
    // Find a pending order for testing
    echo "=== FINDING PENDING ORDER FOR TESTING ===\n";
    $pending_stmt = $conn->prepare("SELECT order_id, status, total_amount FROM orders WHERE status = 'Pending' ORDER BY order_id DESC LIMIT 1");
    $pending_stmt->execute();
    $pending_order = $pending_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$pending_order) {
        echo "❌ No pending orders found for testing!\n";
        exit;
    }
    
    $test_order_id = $pending_order['order_id'];
    echo "✅ Found Order #{$test_order_id} for testing (Status: {$pending_order['status']}, Amount: {$pending_order['total_amount']})\n\n";
    
    // Test the fixed API by calling it directly
    echo "=== TESTING FIXED API DIRECTLY ===\n";
    
    // Simulate POST data for the API
    $_POST['action'] = 'update_order_status';
    $_POST['order_id'] = $test_order_id;
    $_POST['status'] = 'Completed';
    
    // Capture the API output
    ob_start();
    
    // Include the fixed API
    include 'orders_api_fixed_v2.php';
    
    $api_output = ob_get_clean();
    
    echo "API Response: " . $api_output . "\n\n";
    
    // Parse the response
    $response = json_decode($api_output, true);
    
    if ($response && $response['success']) {
        echo "✅ API returned success!\n";
        
        // Verify the transfer
        echo "\n=== VERIFYING TRANSFER ===\n";
        
        // Check if order exists in orders table
        $check_order_stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ?");
        $check_order_stmt->execute([$test_order_id]);
        $order_exists = $check_order_stmt->fetch();
        
        if ($order_exists) {
            echo "❌ Order #{$test_order_id} still exists in orders table!\n";
        } else {
            echo "✅ Order #{$test_order_id} successfully removed from orders table\n";
        }
        
        // Check if order exists in transactions table
        $check_trans_stmt = $conn->prepare("SELECT transaction_id, order_id FROM transactions WHERE order_id = ?");
        $check_trans_stmt->execute([$test_order_id]);
        $trans_exists = $check_trans_stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($trans_exists) {
            echo "✅ Order #{$test_order_id} successfully transferred to transactions table (Transaction ID: {$trans_exists['transaction_id']})\n";
        } else {
            echo "❌ Order #{$test_order_id} NOT found in transactions table!\n";
        }
        
        echo "\n=== FINAL RESULT ===\n";
        if (!$order_exists && $trans_exists) {
            echo "🎉 SUCCESS: Fixed order completion process works perfectly!\n";
            echo "✅ Order was transferred to transactions table\n";
            echo "✅ Order was removed from orders table\n";
            echo "✅ No data loss occurred\n";
        } else {
            echo "❌ FAILURE: Order completion process still has issues\n";
        }
        
    } else {
        echo "❌ API returned failure: " . ($response['message'] ?? 'Unknown error') . "\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}
?>